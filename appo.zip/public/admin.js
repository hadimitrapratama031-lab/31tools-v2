const SERVER_URL = ''; // kosong = pakai origin yang sama (admin.html di-serve dari backend ini juga)

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str || '';
  return div.innerHTML;
}

async function api(path, options = {}) {
  const token = localStorage.getItem('adminToken');
  const res = await fetch(SERVER_URL + path, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {})
    }
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Terjadi kesalahan.');
  return data;
}

// ══════════════════════════════════════════════════════════════════════════
// LOGIN
// ══════════════════════════════════════════════════════════════════════════
document.getElementById('btnAdminLogin').addEventListener('click', doLogin);
document.getElementById('adminPassword').addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });

async function doLogin() {
  const password = document.getElementById('adminPassword').value;
  const errEl = document.getElementById('loginError');
  errEl.textContent = '';
  try {
    const data = await api('/api/admin/login', { method: 'POST', body: JSON.stringify({ password }) });
    localStorage.setItem('adminToken', data.token);
    showShell();
  } catch (e) {
    errEl.textContent = e.message;
  }
}

document.getElementById('btnAdminLogout').addEventListener('click', () => {
  localStorage.removeItem('adminToken');
  location.reload();
});

function showShell() {
  document.getElementById('loginWrap').style.display = 'none';
  document.getElementById('shell').style.display = 'flex';
  loadPage('games');
}

if (localStorage.getItem('adminToken')) showShell();

// ══════════════════════════════════════════════════════════════════════════
// NAVIGASI
// ══════════════════════════════════════════════════════════════════════════
const PAGE_TITLE = { games: 'Game', bypasses: 'Bypass', users: 'Users', history: 'Histori' };
let currentPage = 'games';

document.querySelectorAll('.nav-item').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    loadPage(btn.dataset.page);
  });
});

function loadPage(page) {
  currentPage = page;
  document.getElementById('pageTitle').textContent = PAGE_TITLE[page];
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById('page' + page.charAt(0).toUpperCase() + page.slice(1)).classList.add('active');

  const addBtn = document.getElementById('btnAddItem');
  addBtn.style.display = (page === 'games' || page === 'bypasses') ? 'inline-block' : 'none';

  if (page === 'games') renderTable('games');
  else if (page === 'bypasses') renderTable('bypasses');
  else if (page === 'users') renderUsers();
  else if (page === 'history') renderHistory();
}

document.getElementById('btnAddItem').addEventListener('click', () => openItemModal(currentPage, null));

// ══════════════════════════════════════════════════════════════════════════
// TABEL GAME & BYPASS (sama polanya)
// ══════════════════════════════════════════════════════════════════════════
async function renderTable(type) {
  const table = document.getElementById(type === 'games' ? 'tableGames' : 'tableBypasses');
  table.innerHTML = `<tr><td class="empty-row">Memuat...</td></tr>`;
  try {
    const rows = await api(`/api/admin/${type}`);
    if (!rows.length) {
      table.innerHTML = `<tr><td class="empty-row">Belum ada data. Klik "+ Tambah" buat nambahin.</td></tr>`;
      return;
    }
    table.innerHTML = `
      <tr><th>Cover</th><th>Nama</th><th>Role</th><th></th></tr>
      ${rows.map(item => `
        <tr>
          <td>${item.imageUrl ? `<img class="cell-img" src="${item.imageUrl}">` : `<div class="cell-img"></div>`}</td>
          <td><b>${escapeHtml(item.name)}</b><br><span style="color:var(--text-faint);font-size:12px;">${escapeHtml(item.description || '')}</span></td>
          <td><span class="tag ${item.role}">${item.role}</span></td>
          <td class="row-actions">
            <button onclick='openItemModal("${type}", ${JSON.stringify(item).replace(/'/g, "&apos;")})'>Edit</button>
            <button class="danger" onclick="deleteItem('${type}','${item._id}')">Hapus</button>
          </td>
        </tr>
      `).join('')}
    `;
  } catch (e) {
    table.innerHTML = `<tr><td class="empty-row">Gagal memuat: ${escapeHtml(e.message)}</td></tr>`;
  }
}

async function deleteItem(type, id) {
  if (!confirm('Yakin mau hapus item ini?')) return;
  try {
    await api(`/api/admin/${type}/${id}`, { method: 'DELETE' });
    renderTable(type);
  } catch (e) {
    alert('Gagal menghapus: ' + e.message);
  }
}
window.deleteItem = deleteItem;

// ── Modal tambah/edit ──
let editingContext = null; // { type, id } atau null kalau lagi nambah baru

function openItemModal(type, item) {
  editingContext = item ? { type, id: item._id } : { type, id: null };
  document.getElementById('itemModalTitle').textContent = item ? `Edit ${type === 'games' ? 'Game' : 'Bypass'}` : `Tambah ${type === 'games' ? 'Game' : 'Bypass'}`;
  document.getElementById('itemName').value = item?.name || '';
  document.getElementById('itemDescription').value = item?.description || '';
  document.getElementById('itemRole').value = item?.role || 'public';
  document.getElementById('itemImageUrl').value = item?.imageUrl || '';
  document.getElementById('coverResults').innerHTML = '';
  document.getElementById('itemModalBackdrop').style.display = 'flex';
}
window.openItemModal = openItemModal;

document.getElementById('btnCancelItem').addEventListener('click', () => {
  document.getElementById('itemModalBackdrop').style.display = 'none';
});

document.getElementById('btnSaveItem').addEventListener('click', async () => {
  const body = {
    name: document.getElementById('itemName').value.trim(),
    description: document.getElementById('itemDescription').value.trim(),
    role: document.getElementById('itemRole').value,
    imageUrl: document.getElementById('itemImageUrl').value.trim() || null
  };
  if (!body.name) return alert('Nama wajib diisi.');

  try {
    const { type, id } = editingContext;
    if (id) await api(`/api/admin/${type}/${id}`, { method: 'PUT', body: JSON.stringify(body) });
    else await api(`/api/admin/${type}`, { method: 'POST', body: JSON.stringify(body) });
    document.getElementById('itemModalBackdrop').style.display = 'none';
    renderTable(type);
  } catch (e) {
    alert('Gagal menyimpan: ' + e.message);
  }
});

// ── Cari cover art (SteamGridDB) ──
document.getElementById('btnSearchCover').addEventListener('click', async () => {
  const q = document.getElementById('itemName').value.trim();
  if (!q) return alert('Isi nama game dulu buat dicari cover-nya.');
  const resultsEl = document.getElementById('coverResults');
  resultsEl.innerHTML = 'Mencari...';
  try {
    const data = await api(`/api/admin/steamgriddb-search?q=${encodeURIComponent(q)}`);
    if (!data.results.length) { resultsEl.innerHTML = '<span style="font-size:12px;color:var(--text-faint);">Tidak ada hasil.</span>'; return; }
    resultsEl.innerHTML = data.results.map(r => `<img src="${r.thumb}" data-full="${r.url}">`).join('');
    resultsEl.querySelectorAll('img').forEach(img => {
      img.addEventListener('click', () => { document.getElementById('itemImageUrl').value = img.dataset.full; });
    });
  } catch (e) {
    resultsEl.innerHTML = `<span style="font-size:12px;color:#ff6b81;">${escapeHtml(e.message)}</span>`;
  }
});

// ══════════════════════════════════════════════════════════════════════════
// USERS (atur role)
// ══════════════════════════════════════════════════════════════════════════
async function renderUsers() {
  const table = document.getElementById('tableUsers');
  table.innerHTML = `<tr><td class="empty-row">Memuat...</td></tr>`;
  try {
    const rows = await api('/api/admin/users');
    if (!rows.length) { table.innerHTML = `<tr><td class="empty-row">Belum ada user yang login.</td></tr>`; return; }
    table.innerHTML = `
      <tr><th>User</th><th>Discord ID</th><th>Role</th></tr>
      ${rows.map(u => `
        <tr>
          <td style="display:flex;align-items:center;gap:10px;"><img class="cell-img" style="width:30px;height:30px;border-radius:8px;" src="${u.avatarUrl}"><b>${escapeHtml(u.username)}</b></td>
          <td style="color:var(--text-faint);">${u.discordId}</td>
          <td>
            <select class="role-select" onchange="changeUserRole('${u.discordId}', this.value)">
              <option value="public" ${u.role === 'public' ? 'selected' : ''}>Public</option>
              <option value="gold" ${u.role === 'gold' ? 'selected' : ''}>Gold</option>
              <option value="platinum" ${u.role === 'platinum' ? 'selected' : ''}>Platinum</option>
            </select>
          </td>
        </tr>
      `).join('')}
    `;
  } catch (e) {
    table.innerHTML = `<tr><td class="empty-row">Gagal memuat: ${escapeHtml(e.message)}</td></tr>`;
  }
}

async function changeUserRole(discordId, role) {
  try {
    await api(`/api/admin/users/${discordId}/role`, { method: 'PUT', body: JSON.stringify({ role }) });
  } catch (e) {
    alert('Gagal mengubah role: ' + e.message);
    renderUsers();
  }
}
window.changeUserRole = changeUserRole;

// ══════════════════════════════════════════════════════════════════════════
// HISTORI (semua user)
// ══════════════════════════════════════════════════════════════════════════
async function renderHistory() {
  const table = document.getElementById('tableHistory');
  table.innerHTML = `<tr><td class="empty-row">Memuat...</td></tr>`;
  try {
    const rows = await api('/api/admin/history');
    if (!rows.length) { table.innerHTML = `<tr><td class="empty-row">Belum ada histori.</td></tr>`; return; }
    table.innerHTML = `
      <tr><th>User</th><th>Item</th><th>Tipe</th><th>Waktu</th></tr>
      ${rows.map(h => `
        <tr>
          <td>${escapeHtml(h.username)}</td>
          <td>${escapeHtml(h.itemName)}</td>
          <td><span class="tag">${h.itemType}</span></td>
          <td style="color:var(--text-faint);">${new Date(h.createdAt).toLocaleString('id-ID')}</td>
        </tr>
      `).join('')}
    `;
  } catch (e) {
    table.innerHTML = `<tr><td class="empty-row">Gagal memuat: ${escapeHtml(e.message)}</td></tr>`;
  }
}
