// ══════════════════════════════════════════════════════════════════════════
// NOVA LAUNCHER — RENDERER (app.js)
// ══════════════════════════════════════════════════════════════════════════
const SERVER_URL = 'https://31tools-v2-production.up.railway.app';

// ── HELPER ──
function getOrCreateDeviceId() {
  let id = localStorage.getItem('deviceId');
  if (!id) {
    id = 'dev_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 10);
    localStorage.setItem('deviceId', id);
  }
  return id;
}

async function api(path, options = {}) {
  const token = localStorage.getItem('token');
  const res = await fetch(SERVER_URL + path, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {})
    }
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Terjadi kesalahan.');
  return data;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str || '';
  return div.innerHTML;
}

function timeAgo(dateStr) {
  const diffSec = Math.floor((Date.now() - new Date(dateStr).getTime()) / 1000);
  if (diffSec < 60) return 'Baru saja';
  if (diffSec < 3600) return Math.floor(diffSec / 60) + ' menit lalu';
  if (diffSec < 86400) return Math.floor(diffSec / 3600) + ' jam lalu';
  return Math.floor(diffSec / 86400) + ' hari lalu';
}

// ── TITLEBAR (minimize / fullscreen / close) ──
function wireTitlebar() {
  document.getElementById('btnMinimize')?.addEventListener('click', () => window.electronAPI?.minimize());
  document.getElementById('btnMaximize')?.addEventListener('click', () => window.electronAPI?.maximize());
  document.getElementById('btnClose')?.addEventListener('click', () => window.electronAPI?.close());
}

// ── AMBIL REFERENSI ELEMEN ──
const els = {};
function grabElements() {
  els.app          = document.querySelector('.app');
  els.profileImg   = document.querySelector('.sidebar .profile img');
  els.profileName  = document.querySelector('.sidebar .profile .name');
  els.profileRole  = document.querySelector('.sidebar .profile .role');
  els.navLinks     = Array.from(document.querySelectorAll('nav.menu a[data-page]'));
  els.gamesNavLink = document.querySelector('nav.menu a[data-page="games"]');
  els.bypassesNavLink = document.querySelector('nav.menu a[data-page="bypasses"]');
  els.logoutLink   = document.getElementById('navLogout');
  els.topbarH2     = document.querySelector('.topbar h2');
  els.searchInput  = document.querySelector('.search input');

  els.dashSaleGrid   = document.getElementById('dashSaleGrid');
  els.dashNewGrid    = document.getElementById('dashNewGrid');
  els.gamesOnlyGrid  = document.getElementById('gamesOnlyGrid');
  els.bypassesGrid   = document.getElementById('bypassesGrid');
  els.historiListPage = document.getElementById('historiListPage');
  els.gamesRoleFilter = document.getElementById('gamesRoleFilter');
  els.bypassesRoleFilter = document.getElementById('bypassesRoleFilter');
}

// ── FILTER ROLE DI HALAMAN GAMES ──
let activeGamesRoleFilter = 'all';

function applyGamesRoleFilter() {
  const filtered = activeGamesRoleFilter === 'all'
    ? allGames
    : allGames.filter(g => g.role === activeGamesRoleFilter);
  renderGrid(els.gamesOnlyGrid, filtered);
}

function wireGamesRoleFilter() {
  if (!els.gamesRoleFilter) return;
  els.gamesRoleFilter.addEventListener('click', (e) => {
    const btn = e.target.closest('.role-filter-tab');
    if (!btn) return;
    els.gamesRoleFilter.querySelectorAll('.role-filter-tab').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    activeGamesRoleFilter = btn.dataset.role;
    applyGamesRoleFilter();
  });
}

// ── FILTER ROLE DI HALAMAN BYPASS ──
let activeBypassesRoleFilter = 'all';

function applyBypassesRoleFilter() {
  const filtered = activeBypassesRoleFilter === 'all'
    ? allBypasses
    : allBypasses.filter(b => b.role === activeBypassesRoleFilter);
  renderBypassGrid(els.bypassesGrid, filtered);
}

function wireBypassesRoleFilter() {
  if (!els.bypassesRoleFilter) return;
  els.bypassesRoleFilter.addEventListener('click', (e) => {
    const btn = e.target.closest('.role-filter-tab');
    if (!btn) return;
    els.bypassesRoleFilter.querySelectorAll('.role-filter-tab').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    activeBypassesRoleFilter = btn.dataset.role;
    applyBypassesRoleFilter();
  });
}

// ── NAVIGASI ANTAR HALAMAN ──
const PAGE_IDS = {
  dashboard: 'pageDashboard',
  games: 'pageGames',
  bypasses: 'pageBypasses',
  store: 'pageStore',
  histori: 'pageHistori',
  setting: 'pageSetting'
};

function showPage(pageName) {
  Object.values(PAGE_IDS).forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
  });
  const target = document.getElementById(PAGE_IDS[pageName]);
  if (target) target.style.display = '';

  els.navLinks.forEach(a => a.classList.toggle('active', a.dataset.page === pageName));

  if (pageName === 'games') applyGamesRoleFilter();
  if (pageName === 'bypasses') applyBypassesRoleFilter();
  if (pageName === 'histori') { loadHistori(); }
}

function wireNavigation() {
  els.navLinks.forEach(a => {
    a.addEventListener('click', (e) => {
      e.preventDefault();
      showPage(a.dataset.page);
    });
  });
  if (els.logoutLink) {
    els.logoutLink.addEventListener('click', (e) => {
      e.preventDefault();
      localStorage.removeItem('token');
      location.reload();
    });
  }
}

// ── LOGIN OVERLAY (dibuat lewat JS, tema disamakan) ──
let loginStatusEl, pollTimer = null;

function buildLoginOverlay() {
  const overlay = document.createElement('div');
  overlay.id = 'nvLoginOverlay';
  Object.assign(overlay.style, {
    position: 'fixed', inset: '0', zIndex: '9999',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    background: 'radial-gradient(circle at 15% 10%, #7a3fae 0%, transparent 45%),radial-gradient(circle at 90% 0%, #c4409a 0%, transparent 40%),radial-gradient(circle at 100% 100%, #4a2f8f 0%, transparent 45%),linear-gradient(135deg, #2b1c4e 0%, #3a2166 40%, #5c2a7a 70%, #7a3a8f 100%)',
    fontFamily: "'Manrope', sans-serif"
  });

  const card = document.createElement('div');
  Object.assign(card.style, {
    width: '360px', maxWidth: '90vw', padding: '38px 32px', textAlign: 'center',
    borderRadius: '22px', background: 'rgba(18,12,32,0.55)',
    border: '1px solid rgba(255,255,255,0.08)', backdropFilter: 'blur(30px)',
    boxShadow: '0 40px 80px rgba(10,5,25,0.45)'
  });

  card.innerHTML = `
    <div style="font-size:42px;margin-bottom:10px;">🎮</div>
    <h2 id="nvLoginAppName" style="font-family:'Poppins',sans-serif;color:#f3eefc;margin:0 0 8px;font-size:20px;">GameDash</h2>
    <p style="color:#b6a9d1;font-size:13px;line-height:1.6;margin:0 0 24px;">
      Login pakai Discord untuk masuk. Akun kamu akan otomatis terdeteksi
      setelah verifikasi berhasil.
    </p>
    <button id="nvBtnLoginDiscord" style="width:100%;border:none;padding:13px;border-radius:12px;
      background:linear-gradient(90deg,#5865F2,#7c5cff);color:#fff;font-weight:700;font-size:14px;
      cursor:pointer;box-shadow:0 10px 25px rgba(92,102,255,0.4);display:flex;align-items:center;
      justify-content:center;gap:8px;">
      💬 Login dengan Discord
    </button>
    <div id="nvLoginStatus" style="margin-top:16px;font-size:12.5px;color:#8f8ab0;min-height:16px;"></div>
  `;

  overlay.appendChild(card);
  document.body.appendChild(overlay);
  loginStatusEl = card.querySelector('#nvLoginStatus');
  card.querySelector('#nvBtnLoginDiscord').addEventListener('click', startLogin);
  return overlay;
}

function showLogin() {
  if (els.app) els.app.style.display = 'none';
  if (!document.getElementById('nvLoginOverlay')) buildLoginOverlay();
}

function hideLogin() {
  const overlay = document.getElementById('nvLoginOverlay');
  if (overlay) overlay.remove();
  if (els.app) els.app.style.display = '';
}

function startLogin() {
  const deviceId = getOrCreateDeviceId();
  const openExternal = window.electronAPI?.openExternal || (url => window.open(url, '_blank'));
  openExternal(`${SERVER_URL}/auth/discord?state=${encodeURIComponent(deviceId)}`);
  if (loginStatusEl) loginStatusEl.textContent = 'Menunggu login di browser...';
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = setInterval(async () => {
    try {
      const res = await fetch(`${SERVER_URL}/auth/poll?state=${encodeURIComponent(deviceId)}`);
      const data = await res.json();
      if (data.ready) {
        clearInterval(pollTimer);
        localStorage.setItem('token', data.token);
        hideLogin();
        enterApp(data.user);
      }
    } catch (e) {}
  }, 2000);
}

async function tryAutoLogin() {
  const token = localStorage.getItem('token');
  if (!token) { showLogin(); return; }
  try {
    const user = await api('/api/me'); // akun otomatis "terdeteksi" kalau token masih valid
    hideLogin();
    enterApp(user);
  } catch (e) {
    localStorage.removeItem('token');
    showLogin();
  }
}

// ── MASUK APP ──
let currentUser = null;
let allGames = [];
let allBypasses = [];

function enterApp(user) {
  currentUser = user;

  if (els.profileImg) els.profileImg.src = user.avatarUrl;
  if (els.profileName) els.profileName.textContent = user.username;
  if (els.profileRole) els.profileRole.textContent = user.role;

  if (els.topbarH2) els.topbarH2.textContent = `Have a good time ${user.username}!`;

  showPage('dashboard'); // halaman utama selalu yang pertama muncul
  loadGames();
  loadBypasses();
}

const ROLE_BADGE_ICON = { public: '🌐', gold: '🥇', platinum: '💎' };
function roleBadgeHtml(role, inline = false) {
  const icon = ROLE_BADGE_ICON[role] || '🌐';
  const cls = inline ? 'role-pill-inline' : 'role-pill';
  return `<span class="${cls} ${role}">${icon} ${escapeHtml(role)}</span>`;
}

// ── RENDER KARTU GAME ──
function renderGameCard(item) {
  const art = item.imageUrl
    ? `background-image:url('${item.imageUrl}');background-size:cover;background-position:center;`
    : '';
  return `
    <div class="game-card">
      <div class="game-art" style="${art}">
        ${roleBadgeHtml(item.role)}
      </div>
      <div class="game-info">
        <h4 title="${escapeHtml(item.name)}">${escapeHtml(item.name)}</h4>
        <div class="game-meta">
          ${roleBadgeHtml(item.role, true)}
          <button class="dl-btn" data-id="${item._id}" data-name="${escapeHtml(item.name)}">Download</button>
        </div>
      </div>
    </div>`;
}

function renderGrid(container, games) {
  if (!container) return;
  container.innerHTML = games.length
    ? games.map(renderGameCard).join('')
    : `<div style="color:#8577a3;font-size:13px;padding:10px 4px;">Belum ada game yang tersedia untuk paket kamu.</div>`;
  container.querySelectorAll('.dl-btn').forEach(btn => {
    btn.addEventListener('click', () => handleInstall('game', btn.dataset.id, btn.dataset.name));
  });
}

// ── RENDER KARTU BYPASS ──
function renderBypassCard(item) {
  const art = item.imageUrl
    ? `background-image:url('${item.imageUrl}');background-size:cover;background-position:center;`
    : '';
  return `
    <div class="game-card">
      <div class="game-art" style="${art}">
        ${roleBadgeHtml(item.role)}
      </div>
      <div class="game-info">
        <h4 title="${escapeHtml(item.name)}">${escapeHtml(item.name)}</h4>
        <div class="game-meta">
          ${roleBadgeHtml(item.role, true)}
          <button class="dl-btn" data-id="${item._id}" data-name="${escapeHtml(item.name)}" data-link="${escapeHtml(item.link || '')}">
            ${item.link ? 'Buka Link' : 'Pakai'}
          </button>
        </div>
      </div>
    </div>`;
}

function renderBypassGrid(container, bypasses) {
  if (!container) return;
  container.innerHTML = bypasses.length
    ? bypasses.map(renderBypassCard).join('')
    : `<div style="color:#8577a3;font-size:13px;padding:10px 4px;">Belum ada bypass yang tersedia untuk paket kamu.</div>`;
  container.querySelectorAll('.dl-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      handleInstall('bypass', btn.dataset.id, btn.dataset.name);
      const link = btn.dataset.link;
      if (link) {
        const openExternal = window.electronAPI?.openExternal || (url => window.open(url, '_blank'));
        openExternal(link);
      }
    });
  });
}

async function loadBypasses() {
  try {
    const bypasses = await api('/api/bypasses'); // list bypass 100% ikut role & isi database server
    allBypasses = bypasses;

    if (els.bypassesNavLink) {
      const badge = els.bypassesNavLink.querySelector('.badge');
      if (badge) badge.textContent = bypasses.length;
    }

    // Kalau lagi buka halaman Bypass, refresh juga isinya (tetap ikut filter role yang lagi aktif)
    if (document.getElementById(PAGE_IDS.bypasses)?.style.display !== 'none') {
      applyBypassesRoleFilter();
    }
  } catch (e) {
    const msg = `<div style="color:#ff6b81;font-size:13px;">Gagal memuat bypass: ${escapeHtml(e.message)}</div>`;
    if (els.bypassesGrid) els.bypassesGrid.innerHTML = msg;
  }
}

async function loadGames() {
  try {
    const games = await api('/api/games'); // list game 100% ikut role & isi database server
    allGames = games;

    if (els.gamesNavLink) {
      const badge = els.gamesNavLink.querySelector('.badge');
      if (badge) badge.textContent = games.length;
    }

    renderGrid(els.dashNewGrid, games);
    renderGrid(els.dashSaleGrid, [...games].reverse());

    // Kalau lagi buka halaman Games, refresh juga isinya (tetap ikut filter role yang lagi aktif)
    if (document.getElementById(PAGE_IDS.games)?.style.display !== 'none') {
      applyGamesRoleFilter();
    }
  } catch (e) {
    const msg = `<div style="color:#ff6b81;font-size:13px;">Gagal memuat game: ${escapeHtml(e.message)}</div>`;
    if (els.dashNewGrid) els.dashNewGrid.innerHTML = msg;
  }
}

// ── SEARCH ──
function wireSearch() {
  if (!els.searchInput) return;
  els.searchInput.addEventListener('input', () => {
    const q = els.searchInput.value.trim().toLowerCase();
    const filtered = q ? allGames.filter(g => g.name.toLowerCase().includes(q)) : allGames;
    renderGrid(els.dashNewGrid, filtered);
    if (document.getElementById(PAGE_IDS.games)?.style.display !== 'none') {
      const roleFiltered = activeGamesRoleFilter === 'all' ? filtered : filtered.filter(g => g.role === activeGamesRoleFilter);
      renderGrid(els.gamesOnlyGrid, roleFiltered);
    }
    if (document.getElementById(PAGE_IDS.bypasses)?.style.display !== 'none') {
      const filteredBypasses = q ? allBypasses.filter(b => b.name.toLowerCase().includes(q)) : allBypasses;
      const roleFilteredBypasses = activeBypassesRoleFilter === 'all' ? filteredBypasses : filteredBypasses.filter(b => b.role === activeBypassesRoleFilter);
      renderBypassGrid(els.bypassesGrid, roleFilteredBypasses);
    }
  });
}

// ── INSTALL -> catat ke histori ──
async function handleInstall(itemType, itemId, itemName) {
  // Tampilkan status loading
  showInstallStatus(itemName, 'Memulai...');

  try {
    // 1. Ambil download URL dari server
    const data = await api(`/api/${itemType === 'game' ? 'games' : 'bypasses'}/${itemId}/download`);
    if (!data.url) throw new Error('Server tidak memberikan URL download');

    // 2. Deteksi Steam
    const steamPath = await window.electronAPI.getSteamPath();
    if (!steamPath) throw new Error('Steam tidak ditemukan. Pastikan Steam sudah terinstall.');

    let result;

    if (itemType === 'game') {
      // ── INJECT GAME: .lua → stplug-in, .manifest → depotcache ──
      showInstallStatus(itemName, 'Mengunduh file inject...');
      result = await window.electronAPI.injectGame({
        steamPath,
        zipUrl: data.url
      });

      if (!result.success) {
        if (result.cancelled) { hideInstallStatus(); return; }
        throw new Error(result.error || 'Inject gagal');
      }

      // Simpan extractedFiles ke histori (untuk uninstall nanti)
      await api('/api/history', {
        method: 'POST',
        body: JSON.stringify({
          itemType,
          itemId,
          extractedFiles: result.extractedFiles || [],
          steamPath
        })
      });

      showInstallStatus(itemName, '✅ Inject berhasil! Restart Steam agar perubahan aktif.', true);

    } else {
      // ── BYPASS: auto-detect folder game via appId, extract langsung ke sana ──
      const appId = data.steamAppId || data.appId;
      if (!appId) throw new Error('App ID tidak ditemukan di data bypass ini. Hubungi admin.');

      showInstallStatus(itemName, `Mencari folder game (App ID: ${appId})...`);

      result = await window.electronAPI.installBypass({
        steamPath,
        appId: String(appId),
        zipUrl: data.url
      });

      if (!result.success) {
        if (result.cancelled) { hideInstallStatus(); return; }
        throw new Error(result.error || 'Install bypass gagal');
      }

      // Simpan ke histori
      await api('/api/history', {
        method: 'POST',
        body: JSON.stringify({
          itemType,
          itemId,
          extractedFiles: result.extractedFiles || [],
          folderPath: result.folderPath || null
        })
      });

      showInstallStatus(itemName, `✅ Bypass berhasil! Diekstrak ke: ${result.folderPath}`, true);
    }

    // Refresh histori
    loadHistori();

  } catch (e) {
    showInstallStatus(itemName, '❌ ' + e.message, true, true);
  }
}

// ── Status install UI helper ──
let _installStatusTimer = null;
function showInstallStatus(name, msg, autoClose = false, isError = false) {
  let el = document.getElementById('installStatusBanner');
  if (!el) {
    el = document.createElement('div');
    el.id = 'installStatusBanner';
    el.style.cssText = `
      position:fixed; bottom:20px; left:50%; transform:translateX(-50%);
      background:#1e1a2e; border:1px solid #3d3560; border-radius:12px;
      padding:14px 20px; font-size:13px; color:#e8e0ff; z-index:9999;
      box-shadow:0 8px 30px rgba(0,0,0,0.5); max-width:480px; text-align:center;
      transition:opacity .3s;
    `;
    document.body.appendChild(el);
  }
  el.style.opacity = '1';
  el.style.borderColor = isError ? '#ff6b81' : '#7c6ef7';
  el.style.color = isError ? '#ff6b81' : '#e8e0ff';
  el.innerHTML = `<b>${escapeHtml(name)}</b><br><span style="color:${isError?'#ff6b81':'#a78bfa'}">${escapeHtml(msg)}</span>`;

  if (_installStatusTimer) clearTimeout(_installStatusTimer);
  if (autoClose) {
    _installStatusTimer = setTimeout(() => hideInstallStatus(), isError ? 5000 : 3500);
  }
}

function hideInstallStatus() {
  const el = document.getElementById('installStatusBanner');
  if (el) { el.style.opacity = '0'; setTimeout(() => el.remove(), 300); }
}

// ── HALAMAN HISTORI ──
async function loadHistori() {
  if (!els.historiListPage) return;
  els.historiListPage.innerHTML = `<div style="color:#8577a3;font-size:13px;">Memuat histori...</div>`;
  try {
    const rows = await api('/api/history');
    renderHistoriPage(rows);
  } catch (e) {
    els.historiListPage.innerHTML = `<div style="color:#ff6b81;font-size:13px;">Gagal memuat histori: ${escapeHtml(e.message)}</div>`;
  }
}

function renderHistoriPage(rows) {
  if (!els.historiListPage) return;
  els.historiListPage.innerHTML = rows.length ? rows.map(h => `
    <div class="histori-row">
      <div class="hicon">${h.itemType === 'game' ? '🎮' : '🛡️'}</div>
      <div class="hinfo">
        <div class="hname">${escapeHtml(h.itemName)}</div>
        <div class="htime">${timeAgo(h.createdAt)}</div>
      </div>
      <button class="huninstall" data-id="${h._id}">Uninstall</button>
    </div>
  `).join('') : `<div style="color:#8577a3;font-size:13px;">Belum ada histori.</div>`;

  els.historiListPage.querySelectorAll('.huninstall').forEach(btn => {
    btn.addEventListener('click', async () => {
      try {
        await api('/api/history/' + btn.dataset.id, { method: 'DELETE' });
        loadHistori();
      } catch (e) {
        alert('Gagal uninstall: ' + e.message);
      }
    });
  });
}

// ── CONFIG ──
async function loadConfig() {
  try {
    const res = await fetch(SERVER_URL + '/api/config');
    const cfg = await res.json();
    document.title = cfg.appName;
    const nameEl = document.getElementById('nvLoginAppName');
    if (nameEl) nameEl.textContent = cfg.appName;
    const tbTitle = document.querySelector('.titlebar-title');
    if (tbTitle) tbTitle.textContent = cfg.appName;
  } catch (e) {}
}

// ── START ──
document.addEventListener('DOMContentLoaded', () => {
  grabElements();
  wireTitlebar();
  wireNavigation();
  wireSearch();
  wireGamesRoleFilter();
  wireBypassesRoleFilter();
  loadConfig();
  tryAutoLogin();
});