// ══════════════════════════════════════════════════════════════════════════
// NOVA LAUNCHER — BACKEND
// Project baru dari 0. Struktur sengaja dipisah rapi per bagian (cari header
// "════" di bawah buat lompat ke bagian yang kamu mau).
// ══════════════════════════════════════════════════════════════════════════
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const axios = require('axios');
const jwt = require('jsonwebtoken');
const { nanoid } = require('nanoid');
const { MongoClient, ObjectId } = require('mongodb');
const path = require('path');
const http = require('http');
const WebSocket = require('ws');

const app = express();
app.use(cors());

// ══════════════════════════════════════════════════════════════════════════
// ── DISCORD INTERACTIONS ENDPOINT (slash command) ──
// PENTING: route ini WAJIB didaftarkan SEBELUM `app.use(express.json())` di bawah,
// dan pakai express.raw() (bukan express.json()) khusus untuk path ini. Alasannya:
// verifikasi signature Ed25519 dari Discord butuh RAW BYTES persis seperti yang
// dikirim Discord — kalau body-nya sudah kepalang di-parse jadi objek JS lalu
// di-stringify ulang, hasilnya BISA beda urutan/spasi dari body asli, dan
// signature-nya jadi tidak pernah valid walau secara isi datanya "sama".
//
// Ini juga yang menjawab error "interactions_endpoint_url could not be verified"
// di Discord Developer Portal — sebelumnya endpoint ini belum ada sama sekali,
// jadi request PING verifikasi dari Discord cuma dapat 404.
// ══════════════════════════════════════════════════════════════════════════
const nacl = require('tweetnacl');
const DISCORD_PUBLIC_KEY = process.env.DISCORD_PUBLIC_KEY;

app.post('/api/discord/interactions', express.raw({ type: 'application/json' }), (req, res) => {
  const signature = req.get('X-Signature-Ed25519');
  const timestamp = req.get('X-Signature-Timestamp');
  const rawBody = req.body; // Buffer mentah (bukan objek), karena route ini pakai express.raw()

  if (!DISCORD_PUBLIC_KEY) {
    console.error('[Discord Interactions] DISCORD_PUBLIC_KEY belum diset di .env — cek di Developer Portal > General Information > Public Key');
    return res.status(500).send('DISCORD_PUBLIC_KEY belum dikonfigurasi di server');
  }
  if (!signature || !timestamp || !Buffer.isBuffer(rawBody)) {
    return res.status(401).send('invalid request signature');
  }

  let isValid = false;
  try {
    isValid = nacl.sign.detached.verify(
      Buffer.concat([Buffer.from(timestamp, 'utf8'), rawBody]),
      Buffer.from(signature, 'hex'),
      Buffer.from(DISCORD_PUBLIC_KEY, 'hex')
    );
  } catch (e) {
    isValid = false; // signature/public key format salah -> anggap tidak valid, jangan crash
  }

  if (!isValid) {
    return res.status(401).send('invalid request signature');
  }

  const interaction = JSON.parse(rawBody.toString('utf8'));

  // Type 1 = PING. Ini yang dikirim Discord saat kamu klik "Save Changes" di
  // Developer Portal untuk verifikasi URL-nya — WAJIB dibalas persis { type: 1 }
  // dalam beberapa detik, kalau tidak validasinya gagal terus.
  if (interaction.type === 1) {
    return res.json({ type: 1 });
  }

  // Type 2 = Application Command (slash command). Belum ada command spesifik yang
  // di-set di sini — cukup ACK dulu biar tidak error di sisi Discord, nanti tinggal
  // tambah pengecekan `interaction.data.name` buat masing-masing command yang kamu mau.
  if (interaction.type === 2) {
    return res.json({
      type: 4,
      data: { content: `⚙️ Command \`/${interaction.data?.name}\` diterima, tapi belum ada aksi yang diprogram untuk command ini.` }
    });
  }

  // Type lain (component/autocomplete/modal) — ACK generik dulu
  res.json({ type: 1 });
});

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public'))); // admin.html, admin.js, dll

const PORT = process.env.PORT || 3000;
const SERVER_URL = process.env.SERVER_URL || `http://localhost:${PORT}`;
const JWT_SECRET = process.env.JWT_SECRET;
const APP_NAME = process.env.APP_NAME || 'Nova Launcher';

// hubcapmanifest.com — dipakai admin panel buat auto-isi info game (nama/foto/ukuran/link)
// pas nambah Game, cukup dari App ID Steam-nya.
const HUBCAP_BASE_URL = (process.env.HUBCAP_BASE_URL || 'https://hubcapmanifest.com').replace(/\/+$/, '');

// Rotasi API key HubCap — dukung sampai 4 key sekaligus (opsional, isi kalau ada lebih dari 1).
// Kalau salah satu key kena rate limit (429) atau ditolak (401/403), otomatis pindah ke key berikutnya.
let HUBCAP_API_KEYS = [
  process.env.HUBCAP_API_KEY,
  process.env.HUBCAP_API_KEY_2,
  process.env.HUBCAP_API_KEY_3,
  process.env.HUBCAP_API_KEY_4,
].filter(Boolean);
const HUBCAP_API_KEY = HUBCAP_API_KEYS[0] || ''; // dipertahankan untuk kompatibilitas kode lama

// Ryuu Generator (generator.ryuu.lol) — dipakai kalau bypass pakai link Ryuu. Ambil dari
// generator.ryuu.lol/api > "Your Auth Key" (butuh akun Ryuu, gratis/premium tergantung kuota).
const RYUU_API_KEY = process.env.RYUU_API_KEY || '';

let hubcapKeyIndex = 0;
const HUBCAP_COOLDOWN_MS = 60 * 1000; // 1 menit cooldown per key yang kena limit
const hubcapKeyCooldown = {}; // { index: timestampMs kapan boleh dipakai lagi }

function getHubcapApiKey() {
  const total = HUBCAP_API_KEYS.length;
  if (total === 0) return '';
  for (let i = 0; i < total; i++) {
    const idx = (hubcapKeyIndex + i) % total;
    const cooldownUntil = hubcapKeyCooldown[idx] || 0;
    if (Date.now() >= cooldownUntil) { hubcapKeyIndex = idx; return HUBCAP_API_KEYS[idx]; }
  }
  return HUBCAP_API_KEYS[0]; // semua lagi cooldown, tetap coba key pertama sebagai fallback
}
function markHubcapKeyLimited() {
  if (HUBCAP_API_KEYS.length === 0) return;
  hubcapKeyCooldown[hubcapKeyIndex] = Date.now() + HUBCAP_COOLDOWN_MS;
  hubcapKeyIndex = (hubcapKeyIndex + 1) % HUBCAP_API_KEYS.length;
}

// ── PROXY STREAM dari HubCap → client ──
// PENTING: server yang men-download dari HubCap (pakai axios + Bearer key), lalu
// meneruskan (pipe) hasilnya langsung ke client — BUKAN client yang fetch langsung
// ke hubcapmanifest.com. Ini krusial karena:
//  1. API key HubCap tidak pernah terekspos ke Electron app / localStorage.
//  2. axios di server jauh lebih reliable menghadapi redirect/header hubcap
//     dibanding raw https.get di proses Electron.
//  3. Dukung rotasi otomatis ke key lain kalau satu key kena rate limit.
// Endpoint yang dipakai WAJIB /api/v1/manifest/{appId} (ZIP berisi .lua + .manifest),
// BUKAN /api/v1/lua/{appId} (cuma file .lua mentah, bakal gagal validasi ZIP di client).
async function streamHubcapManifest(appId, res, filenameHint) {
  if (HUBCAP_API_KEYS.length === 0) {
    return res.status(500).json({ error: 'HUBCAP_API_KEY belum diisi di server (.env). Hubungi admin.' });
  }
  const url = `${HUBCAP_BASE_URL}/api/v1/manifest/${appId}`;
  let hubcapRes = null;
  let lastError = null;

  for (let attempt = 0; attempt < HUBCAP_API_KEYS.length; attempt++) {
    const apiKey = getHubcapApiKey();
    try {
      hubcapRes = await axios.get(url, {
        headers: { Authorization: `Bearer ${apiKey}` },
        responseType: 'stream',
        timeout: 0, // file bisa besar, jangan timeout
        maxRedirects: 10
      });
      break; // sukses
    } catch (e) {
      lastError = e;
      if (e.response) {
        const s = e.response.status;
        if (s === 429 || s === 401 || s === 403) {
          markHubcapKeyLimited();
          if (attempt < HUBCAP_API_KEYS.length - 1) continue; // coba key berikutnya
        }
      }
      break; // error lain, atau sudah habis semua key
    }
  }

  if (!hubcapRes) {
    if (lastError?.response) {
      const s = lastError.response.status;
      if (s === 429) return res.status(429).json({ error: 'Semua API key HubCap sedang rate limited, coba lagi sebentar lagi.' });
      if (s === 401 || s === 403) return res.status(401).json({ error: 'API Key HubCap tidak valid/ditolak. Hubungi admin.' });
      if (s === 404) return res.status(404).json({ error: `Manifest untuk App ID ${appId} tidak ditemukan di HubCap.` });
    }
    return res.status(500).json({ error: 'Gagal terhubung ke HubCap: ' + (lastError?.message || 'unknown error') });
  }

  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', `attachment; filename="${(filenameHint || 'file').replace(/[^a-z0-9]/gi, '_')}.zip"`);
  if (hubcapRes.headers['content-length']) res.setHeader('Content-Length', hubcapRes.headers['content-length']);
  hubcapRes.data.pipe(res);
}

// Urutan level role — dipakai buat cek "role X boleh akses item level berapa"
// 'admin' sengaja ditaruh paling atas (level tertinggi) — otomatis bisa akses
// semua game/bypass apapun paketnya, DAN dipakai buat gerbang masuk admin panel
// (lihat requireAdmin di bawah).
const ROLE_LEVEL = { public: 0, gold: 1, platinum: 2, admin: 3 };

if (!JWT_SECRET) console.warn('⚠️  JWT_SECRET belum diisi di .env — token login TIDAK AMAN.');

let db;

// ══════════════════════════════════════════════════════════════════════════
// MASA AKTIF & LIMIT DOWNLOAD — berlaku buat semua role KECUALI admin (unlimited).
//   • public   : tanpa masa aktif (permanen). Limit download 3x/hari utk Game DAN
//                3x/hari utk Bypass — dua counter TERPISAH.
//   • gold     : masa aktif diatur admin (tanggal expired). Limit download 4x/hari
//                utk Game DAN 4x/hari utk Bypass — dua counter terpisah.
//   • platinum : masa aktif diatur admin. Limit download UNLIMITED (Game & Bypass).
//   • admin    : unlimited semua, tidak ada masa aktif sama sekali.
// ══════════════════════════════════════════════════════════════════════════
const DOWNLOAD_LIMITS = {
  public:   { game: 3, bypass: 3 },
  gold:     { game: 4, bypass: 4 },
  platinum: { game: Infinity, bypass: Infinity },
  admin:    { game: Infinity, bypass: Infinity }
};

// Tanggal hari ini di zona WIB (Asia/Jakarta), format YYYY-MM-DD. Dipakai buat reset
// counter limit download tiap ganti hari — sengaja BUKAN tanggal UTC server (Railway
// dkk biasanya UTC), biar "sehari" yang dimaksud sesuai jam Indonesia.
function todayDateStrJakarta() {
  return new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Jakarta' }); // 'en-CA' -> 'YYYY-MM-DD'
}

// Cek apakah masa aktif user (Gold/Platinum) sudah lewat. Public & Admin tidak
// punya masa aktif sama sekali jadi selalu false.
function isActivePeriodExpired(user) {
  if (user.role !== 'gold' && user.role !== 'platinum') return false;
  if (!user.activeUntil) return false; // belum diset admin = belum ada batas waktu
  return new Date(user.activeUntil).getTime() <= Date.now();
}

// Kalau masa aktif sudah lewat, otomatis turunkan role user ke 'public' (DB + sinkron
// ke Discord + catat log histori — sama seperti "Set Paket" manual admin), lalu
// kembalikan versi user yang sudah ter-update. Dipanggil di setiap request yang butuh
// login supaya efeknya langsung kena di request berikutnya, tanpa perlu aksi admin apapun.
async function applyExpiryIfNeeded(user) {
  if (!isActivePeriodExpired(user)) return user;

  const oldRole = user.role;
  const discordId = user.discordId;
  const username = user.username || discordId;

  await db.collection('users').updateOne(
    { discordId },
    { $set: { role: 'public', roleUpdatedAt: new Date(), activeUntil: null } }
  );

  // Best-effort: sinkron Discord + log. Jangan sampai gagalnya nge-block request user.
  try {
    const discordSync = await roleSync.syncAppRoleToDiscord(discordId, 'public');
    await roleSync.logRoleChange({
      discordId, username, oldRole, newRole: 'public',
      source: 'expired', discordSync,
      note: 'Masa aktif habis, otomatis diturunkan ke Public.'
    });
  } catch (e) {
    console.warn('[Masa Aktif] Gagal sinkron/log saat auto-downgrade:', e.message);
  }

  const updated = await db.collection('users').findOne({ discordId });

  notifyUser(discordId, {
    type: 'period_expired',
    title: 'Masa Aktif Berakhir',
    message: `Masa aktif paket ${oldRole.toUpperCase()} kamu telah berakhir dan otomatis diturunkan ke Public.`,
    fields: [
      field('👤 Username', username, true),
      field('🆔 Discord ID', discordId, true),
      field('📦 Paket Sebelumnya', oldRole.toUpperCase(), true),
      field('📦 Paket Sekarang', 'PUBLIC', true)
    ],
    dm: true, webhook: true
  }).catch(() => {});
  pushAccountUpdate(discordId).catch(() => {});

  return updated || user;
}

// Cek + konsumsi kuota download harian. type = 'game' | 'bypass'.
// - Kalau limit-nya Infinity (platinum & admin) -> langsung ok, TIDAK nulis apapun ke DB.
// - Kalau counter hari ini sudah >= limit -> ok:false + pesan buat ditampilin ke user.
// - Kalau masih ada sisa -> counter ditambah 1 & disimpan ke DB, return ok:true.
async function consumeDownloadQuota(user, type) {
  const limits = DOWNLOAD_LIMITS[user.role] || DOWNLOAD_LIMITS.public;
  const limit = limits[type];
  if (limit === Infinity) return { ok: true, limit: null, used: null, remaining: null };

  const today = todayDateStrJakarta();
  const prevUsage = (user.downloadUsage && user.downloadUsage.date === today)
    ? user.downloadUsage
    : { date: today, game: 0, bypass: 0 };

  const used = prevUsage[type] || 0;
  if (used >= limit) {
    return {
      ok: false, limit, used,
      message: `Limit download harian untuk ${type === 'game' ? 'Game' : 'Bypass'} (${limit}x/hari) sudah tercapai. Coba lagi besok atau upgrade paket kamu.`
    };
  }

  const newUsage = { ...prevUsage, [type]: used + 1 };
  await db.collection('users').updateOne(
    { discordId: user.discordId },
    { $set: { downloadUsage: newUsage } }
  );

  const remaining = limit - newUsage[type];
  const label = type === 'game' ? 'Game' : 'Bypass';
  if (remaining === 0) {
    notifyUser(user.discordId, {
      type: 'quota_empty',
      title: `Limit Download ${label} Habis`,
      message: `Limit download harian kamu untuk ${label} (${limit}x/hari) sudah habis. Reset otomatis besok jam 00:00 WIB.`,
      fields: [
        field('👤 Username', user.username, true),
        field('🆔 Discord ID', user.discordId, true),
        field('📦 Tipe', label, true),
        field('🔢 Limit Harian', `${limit}x/hari`, true),
        field('📉 Sisa Limit', '0x', true)
      ],
      dm: true, webhook: true
    }).catch(() => {});
  } else if (remaining === 1 && limit > 1) {
    notifyUser(user.discordId, {
      type: 'quota_low',
      title: `Limit Download ${label} Hampir Habis`,
      message: `Sisa limit download ${label} kamu tinggal ${remaining}x hari ini.`,
      fields: [
        field('👤 Username', user.username, true),
        field('🆔 Discord ID', user.discordId, true),
        field('📦 Tipe', label, true),
        field('🔢 Limit Harian', `${limit}x/hari`, true),
        field('📉 Sisa Limit', `${remaining}x`, true)
      ],
      dm: true, webhook: true
    }).catch(() => {});
  }
  pushAccountUpdate(user.discordId).catch(() => {});

  return { ok: true, limit, used: newUsage[type], remaining };
}

// Ringkasan masa aktif & limit download user — dipakai di /api/me (app) & Manajemen
// Users (admin panel) biar kelihatan jelas tanpa perlu itung manual di frontend.
function accountStatusSummary(user) {
  const limits = DOWNLOAD_LIMITS[user.role] || DOWNLOAD_LIMITS.public;
  const today = todayDateStrJakarta();
  const usage = (user.downloadUsage && user.downloadUsage.date === today)
    ? user.downloadUsage
    : { date: today, game: 0, bypass: 0 };

  const mk = (type) => {
    const limit = limits[type];
    if (limit === Infinity) return { limit: null, used: 0, remaining: null, unlimited: true };
    const used = usage[type] || 0;
    return { limit, used, remaining: Math.max(0, limit - used), unlimited: false };
  };

  const hasActivePeriod = (user.role === 'gold' || user.role === 'platinum');
  return {
    activeUntil: hasActivePeriod ? (user.activeUntil || null) : null,
    hasActivePeriod,
    hasExpiry: hasActivePeriod && !!user.activeUntil,
    isExpired: isActivePeriodExpired(user),
    download: { game: mk('game'), bypass: mk('bypass') }
  };
}

// ══════════════════════════════════════════════════════════════════════════
// VERIFY ROLE — sinkron role App ⇄ Discord + webhook notif (lihat discordRoleSync.js)
// ══════════════════════════════════════════════════════════════════════════
// ══════════════════════════════════════════════════════════════════════════
// REALTIME — WebSocket hub
// Tanpa Socket.IO (biar client-side gak perlu bundling apa-apa, browser Chromium
// di Electron sudah punya `WebSocket` bawaan). Auth pakai JWT yang sama dengan
// REST (?token=... di query string pas connect). Satu discordId bisa punya lebih
// dari satu koneksi (multi-device), makanya disimpan sebagai Set per discordId.
// ══════════════════════════════════════════════════════════════════════════
const wsClients = new Map(); // discordId -> Set<WebSocket>

function wsRegister(discordId, ws) {
  if (!wsClients.has(discordId)) wsClients.set(discordId, new Set());
  wsClients.get(discordId).add(ws);
}
function wsUnregister(discordId, ws) {
  const set = wsClients.get(discordId);
  if (!set) return;
  set.delete(ws);
  if (set.size === 0) wsClients.delete(discordId);
}
// Kirim event realtime ke SEMUA koneksi aktif milik satu user (semua device/instance
// aplikasi yang sedang login). Kalau user lagi offline, ya cuma kesimpen di DB
// (untuk notifikasi) — pas dia buka app lagi otomatis kelihatan dari /api/notifications.
function wsSendToUser(discordId, event, data) {
  const set = wsClients.get(discordId);
  if (!set || set.size === 0) return false;
  const payload = JSON.stringify({ event, data });
  let sent = false;
  for (const ws of set) {
    if (ws.readyState === WebSocket.OPEN) { ws.send(payload); sent = true; }
  }
  return sent;
}
// Broadcast ke SEMUA user yang sedang terkoneksi (dipakai buat pengumuman admin).
function wsBroadcastAll(event, data) {
  const payload = JSON.stringify({ event, data });
  for (const set of wsClients.values()) {
    for (const ws of set) {
      if (ws.readyState === WebSocket.OPEN) ws.send(payload);
    }
  }
}

// ══════════════════════════════════════════════════════════════════════════
// REALTIME — Admin Dashboard hub (terpisah dari wsClients di atas, karena admin
// bisa login pakai password bersama yang TIDAK terikat discordId sama sekali).
// Dipakai supaya Dashboard admin (stat card, grafik, activity feed) otomatis
// ter-update tanpa refresh, begitu ada aktivitas baru yang tercatat di
// activityLogs (lihat logActivity di bawah).
// ══════════════════════════════════════════════════════════════════════════
const adminWsClients = new Set();
function wsRegisterAdmin(ws) { adminWsClients.add(ws); }
function wsUnregisterAdmin(ws) { adminWsClients.delete(ws); }
function broadcastAdmin(event, data) {
  const payload = JSON.stringify({ event, data });
  for (const ws of adminWsClients) {
    if (ws.readyState === WebSocket.OPEN) ws.send(payload);
  }
}

// Ikon default per jenis aktivitas — SATU-SATUNYA sumber kebenaran urutan/jenis
// aktivitas yang muncul di panel "Aktivitas Terbaru" & dipakai juga buat hitung
// grafik login (type: 'login').
const ACTIVITY_ICON = {
  login: '🔑',
  logout: '🚪',
  install: '⬇️',
  download_failed: '⚠️',
  purchase: '💳',
  renewal: '🔄',
  request_game: '🎯',
  admin_add_game: '➕',
  admin_edit_game: '✏️',
  admin_delete_game: '🗑️',
  admin_add_bypass: '➕',
  admin_edit_bypass: '✏️',
  admin_delete_bypass: '🗑️',
  admin_reset_quota: '♻️',
  announcement: '📢',
  system_error: '🚨'
};

// Catat satu entri aktivitas ke koleksi `activityLogs` (dipakai buat panel
// "Aktivitas Terbaru" DAN grafik "Login 7 Hari Terakhir" di Dashboard admin).
// Best-effort — kalau gagal simpan (mis. DB belum siap), jangan sampai
// menghambat/gagalkan proses utama yang memanggilnya.
async function logActivity({ type, username, discordId, description, meta = {} }) {
  const doc = {
    type,
    icon: ACTIVITY_ICON[type] || 'ℹ️',
    username: username || null,
    discordId: discordId || null,
    description: description || '',
    meta,
    createdAt: new Date()
  };
  try {
    if (!db) return doc;
    const result = await db.collection('activityLogs').insertOne(doc);
    doc._id = result.insertedId;
  } catch (e) {
    console.warn('[Activity] Gagal simpan activity log:', e.message);
  }
  // Push realtime ke semua admin yang lagi buka Dashboard — dashboard tinggal
  // prepend item ini ke Activity Feed & re-fetch angka statistik yang relevan,
  // TANPA perlu refresh halaman/login ulang/restart server.
  broadcastAdmin('activity', doc);
  return doc;
}

// Kirim ulang status akun (role, masa aktif, limit download) ke user secara realtime.
// Dipanggil setiap kali ada perubahan di server yang mempengaruhi data itu, supaya
// client TIDAK PERLU refresh/restart/login ulang untuk lihat perubahannya.
async function pushAccountUpdate(discordId) {
  try {
    const user = await db.collection('users').findOne({ discordId });
    if (!user) return;
    wsSendToUser(discordId, 'account:update', publicUser(user));
  } catch (e) {
    console.warn('[Realtime] Gagal push account:update:', e.message);
  }
}

// ══════════════════════════════════════════════════════════════════════════
// NOTIFIKASI — In-App + Discord DM + Discord Webhook
// ══════════════════════════════════════════════════════════════════════════
// Kirim webhook notifikasi ke channel Discord SESUAI KATEGORINYA (lihat
// webhookManager.js + WEBHOOK_CATEGORY_BY_NOTIF_TYPE di atas). Setiap kategori
// (Download Berhasil, Limit Habis, Pengumuman, dst) punya webhook URL sendiri
// yang diatur dari Admin Web > Webhook Settings — best-effort, tidak pernah
// melempar error ke pemanggil kalau webhook-nya belum diatur/gagal kirim.
const { buildEmbed, field, fmtDurationMs, fmtDateTimeWIB } = require('./notifTemplates');
// Logo aplikasi (opsional, isi di .env) — dipakai sebagai thumbnail fallback
// pada notifikasi yang tidak punya gambar sendiri (mis. paket/pengumuman/error),
// sesuai poin "Jika gambar tidak tersedia, gunakan thumbnail/logo aplikasi sebagai fallback".
const APP_LOGO_URL = process.env.APP_LOGO_URL || null;

async function sendDiscordWebhook(notifType, embed) {
  const category = WEBHOOK_CATEGORY_BY_NOTIF_TYPE[notifType] || 'announcement';
  return webhookManager.sendCategoryWebhook(category, { embed });
}

// Status (warna+emoji 🟢🟡🔴🔵) & label tiap jenis notifikasi in-app. SATU-SATUNYA
// sumber kebenaran dipakai buat bikin embed (lewat notifTemplates.buildEmbed) —
// DM & Webhook jadi selalu konsisten tampilannya untuk jenis notifikasi yang sama.
const NOTIF_META = {
  download_success: { status: 'success', label: 'Download Berhasil' },
  download_failed:  { status: 'error',   label: 'Download Gagal' },
  quota_low:        { status: 'warning', label: 'Limit Download Hampir Habis' },
  quota_empty:      { status: 'error',   label: 'Limit Download Habis' },
  period_low:       { status: 'warning', label: 'Paket Hampir Berakhir' },
  period_expired:   { status: 'error',   label: 'Paket Berakhir' },
  purchase:         { status: 'success', label: 'Pembelian Paket' },
  renewal:          { status: 'info',    label: 'Perpanjangan Paket' },
  announcement:     { status: 'info',    label: 'Pengumuman Admin' },
  login:            { status: 'info',    label: 'Login Akun' },
  system_error:     { status: 'error',   label: 'Error Sistem' }
};

// Fungsi utama pengiriman notifikasi. Selalu simpan ke DB (in-app, muncul di lonceng
// notifikasi walau user lagi offline) + push realtime via WebSocket kalau user online.
// Discord DM & Webhook sifatnya best-effort tambahan, dikontrol per-jenis notifikasi
// lewat opsi { dm, webhook } (default: dm untuk yang penting, webhook selalu untuk visibilitas admin).
//
// `fields`    : array field() tambahan yang RELEVAN untuk jenis notifikasi ini
//               (mis. nama game, ukuran, sisa limit, dll) — lihat notifTemplates.js.
// `thumbnail` : URL gambar kecil (icon paket/logo app/icon warning).
// `image`     : URL gambar besar/cover (dipakai untuk event terkait game).
async function notifyUser(discordId, { type, title, message, fields = [], thumbnail, image, meta = {}, dm = true, webhook = false }) {
  const doc = {
    discordId, type, title, message, meta,
    read: false,
    createdAt: new Date()
  };
  let inserted = null;
  try {
    const result = await db.collection('notifications').insertOne(doc);
    inserted = { ...doc, _id: result.insertedId };
  } catch (e) {
    console.warn('[Notif] Gagal simpan ke DB:', e.message);
    inserted = doc;
  }

  // In-app realtime push
  wsSendToUser(discordId, 'notification', inserted);
  // Kirim juga jumlah unread terbaru biar badge lonceng update tanpa query tambahan
  try {
    const unread = await db.collection('notifications').countDocuments({ discordId, read: false });
    wsSendToUser(discordId, 'notification:unread-count', { unread });
  } catch {}

  const typeMeta = NOTIF_META[type] || { status: 'info', label: title };
  const embed = buildEmbed({
    status: typeMeta.status,
    title,
    description: message,
    fields,
    thumbnail: thumbnail || APP_LOGO_URL || undefined,
    image,
    appName: APP_NAME,
    footerNote: typeMeta.label
  });

  if (dm) {
    sendDiscordDM(discordId, { embeds: [embed] }).catch(() => {});
  }
  if (webhook) {
    sendDiscordWebhook(type, embed).catch(() => {});
  }

  return inserted;
}

// Broadcast pengumuman admin ke SEMUA user (in-app selalu; DM & webhook opsional,
// dikontrol dari form admin biar tidak spam kalau pengumumannya kecil-kecilan saja).
async function notifyAllUsers({ title, message, dm = false, webhook = true }) {
  const users = await db.collection('users').find({}, { projection: { discordId: 1 } }).toArray();
  const results = await Promise.allSettled(
    users.map(u => notifyUser(u.discordId, { type: 'announcement', title, message, dm, webhook: false }))
  );
  if (webhook) {
    const embed = buildEmbed({
      status: 'info',
      title,
      description: message,
      fields: [field('🎯 Target', `Semua User (${users.length})`, true)],
      thumbnail: APP_LOGO_URL || undefined,
      appName: APP_NAME,
      footerNote: NOTIF_META.announcement.label
    });
    await sendDiscordWebhook('announcement', embed).catch(() => {});
  }
  return results.length;
}

const roleSync = require('./discordRoleSync')({ getDb: () => db, ROLE_LEVEL });

// Webhook Discord PER KATEGORI notifikasi (lihat webhookManager.js) — menggantikan
// webhook tunggal DISCORD_NOTIF_WEBHOOK_URL lama. Diatur dari Admin Web > Webhook
// Settings, disimpan di DB, berlaku realtime tanpa restart.
const webhookManager = require('./webhookManager')({ getDb: () => db });

// Pemetaan jenis notifikasi in-app (`type` di notifyUser) -> kategori webhook.
// Dipakai supaya satu fungsi notifyUser tetap bisa dipanggil dari mana saja,
// tapi webhook-nya otomatis nyampur ke channel Discord yang benar sesuai kategori.
const WEBHOOK_CATEGORY_BY_NOTIF_TYPE = {
  download_success: 'download_success',
  download_failed:  'download_failed',
  quota_low:         'quota_low',
  quota_empty:       'quota_empty',
  period_low:        'period_low',
  period_expired:    'period_expired',
  purchase:          'purchase',
  renewal:           'renewal',
  announcement:      'announcement',
  login:             'login',
  system_error:      'system_error'
};

// ══════════════════════════════════════════════════════════════════════════
// DATABASE
// ══════════════════════════════════════════════════════════════════════════
async function connectDB() {
  if (!process.env.MONGODB_URI) {
    console.error('❌ MONGODB_URI belum diisi di .env');
    return;
  }
  try {
    const client = new MongoClient(process.env.MONGODB_URI);
    await client.connect();
    // Ambil nama DB dari URI kalau ada, fallback ke 'nova'
    const dbName = process.env.MONGODB_URI.split('/').pop()?.split('?')[0] || 'test';
    db = client.db(dbName || 'test');
    console.log(`✅ MongoDB tersambung (db: ${db.databaseName})`);

    await db.collection('users').createIndex({ discordId: 1 }, { unique: true });
    await db.collection('games').createIndex({ role: 1 });
    await db.collection('bypasses').createIndex({ role: 1 });
    await db.collection('history').createIndex({ userId: 1, createdAt: -1 });
    await db.collection('pendingLogins').createIndex({ createdAt: 1 }, { expireAfterSeconds: 600 });
    await db.collection('roleSyncLogs').createIndex({ createdAt: -1 });
    await db.collection('roleSyncLogs').createIndex({ discordId: 1 });
    await db.collection('notifications').createIndex({ discordId: 1, createdAt: -1 });
    await db.collection('notifications').createIndex({ discordId: 1, read: 1 });
    await db.collection('activityLogs').createIndex({ createdAt: -1 });
    await db.collection('activityLogs').createIndex({ type: 1, createdAt: -1 });
  } catch (e) {
    console.error('❌ Gagal konek MongoDB:', e.message);
    // TIDAK process.exit() — server tetap jalan supaya endpoint /health dan interactions tetap bisa diakses
  }
}

// ══════════════════════════════════════════════════════════════════════════
// AUTH MIDDLEWARE
// ══════════════════════════════════════════════════════════════════════════

// Dipakai di route APP (Game/Bypass/Histori) — wajib login via Discord
async function requireUser(req, res, next) {
  if (!db) return res.status(503).json({ error: 'Database belum siap, coba lagi sebentar.' });
  try {
    const authHeader = req.headers.authorization || '';
    const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Belum login.' });

    let payload;
    let tokenExpired = false;
    try {
      payload = jwt.verify(token, JWT_SECRET);
    } catch (e) {
      if (e.name === 'TokenExpiredError') {
        payload = jwt.decode(token); // decode tanpa verifikasi waktu
        tokenExpired = true;
      } else {
        return res.status(401).json({ error: 'Token tidak valid.' });
      }
    }

    if (!payload?.discordId) return res.status(401).json({ error: 'Token tidak bisa dibaca.' });

    let user = await db.collection('users').findOne({ discordId: payload.discordId });
    if (!user) return res.status(401).json({ error: 'Akun tidak ditemukan.' });

    // Kalau masa aktif Gold/Platinum-nya sudah lewat, otomatis turunkan ke Public
    // SEBELUM request lanjut diproses, biar limit/akses yang berlaku langsung yang baru.
    user = await applyExpiryIfNeeded(user);

    // Token expired tapi user masih ada → issue token baru via header
    if (tokenExpired) {
      const newToken = jwt.sign({ discordId: user.discordId }, JWT_SECRET, { expiresIn: '90d' });
      res.setHeader('X-New-Token', newToken);
    }

    req.user = user;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Token tidak valid.' });
  }
}

// Dipakai di route ADMIN WEB. Ada 2 cara sah buat lolos jadi admin:
//   1) LOGIN PASSWORD LAMA — token JWT { role: 'admin' } dari /api/admin/login
//      (satu password bersama dari .env, tanpa terikat akun Discord manapun).
//   2) LOGIN DISCORD — token JWT biasa { discordId } (sama seperti token app),
//      DIIZINKAN masuk admin panel KALAU DAN HANYA KALAU role user itu di
//      database saat ini adalah 'admin'. Role 'admin' ini sendiri diisi lewat
//      "Set Paket" admin panel ATAU otomatis mengikuti role Discord user kalau
//      role Discord itu sudah di-mapping ke tier 'admin' di halaman Verify Role
//      (persis seperti mapping Gold/Platinum, lihat discordRoleSync.js).
// Konsekuensinya: cabut role Discord "Admin" seseorang (atau ubah paketnya di
// panel jadi bukan admin) = akses admin panel orang itu otomatis ikut hilang
// di request berikutnya, karena role selalu dicek ulang ke DB, bukan disimpan
// permanen di dalam token.
async function requireAdmin(req, res, next) {
  if (!JWT_SECRET) return res.status(500).json({ error: 'JWT_SECRET belum diset.' });
  try {
    const authHeader = req.headers.authorization || '';
    const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Belum login admin.' });

    let payload;
    try {
      payload = jwt.verify(token, JWT_SECRET);
    } catch (e) {
      return res.status(401).json({ error: 'Token admin tidak valid.' });
    }

    // 1) Token admin lama (password bersama) — tidak terikat discordId sama sekali.
    if (payload.role === 'admin' && !payload.discordId) {
      req.admin = { via: 'password' };
      return next();
    }

    // 2) Token akun Discord — cek role user itu di DB sekarang juga.
    if (payload.discordId) {
      if (!db) return res.status(503).json({ error: 'Database belum siap, coba lagi sebentar.' });
      const user = await db.collection('users').findOne({ discordId: payload.discordId });
      if (user && user.role === 'admin') {
        req.user = user;
        req.admin = { via: 'discord', discordId: user.discordId, username: user.username, avatarUrl: user.avatarUrl };
        return next();
      }
    }

    return res.status(403).json({ error: 'Akun ini tidak punya akses admin.' });
  } catch (e) {
    return res.status(401).json({ error: 'Token admin tidak valid.' });
  }
}

// ══════════════════════════════════════════════════════════════════════════
// LOGIN — DISCORD OAUTH (wajib member server dulu baru bisa login)
// ══════════════════════════════════════════════════════════════════════════
// Alur singkatnya:
//  1. App buka browser ke /auth/discord?state=<deviceId>
//  2. User login & izinkan lewat Discord
//  3. Discord redirect balik ke /auth/discord/callback
//  4. Server cek: user ini anggota server Discord kita apa belum (pakai bot token)
//     - Belum join  -> tampilkan halaman "join dulu" + link invite
//     - Sudah join  -> simpan/​update user di DB, siapkan token login, tampilkan
//       halaman "berhasil, kembali ke app"
//  5. App terus nanya ke /auth/poll?state=<deviceId> setiap 2 detik sampai
//     token-nya siap, lalu app tersebut menyimpan token itu buat request selanjutnya.

app.get('/auth/discord', (req, res) => {
  const state = req.query.state;
  if (!state) return res.status(400).send('Parameter state wajib ada.');
  const params = new URLSearchParams({
    client_id: process.env.DISCORD_CLIENT_ID,
    redirect_uri: process.env.DISCORD_REDIRECT_URI,
    response_type: 'code',
    scope: 'identify',
    state
  });
  res.redirect(`https://discord.com/oauth2/authorize?${params.toString()}`);
});

app.get('/auth/discord/callback', async (req, res) => {
  const { code, state, error: discordError } = req.query;

  // User menekan "Cancel"/menolak izin di halaman Discord — sebelumnya ini cuma
  // dapat pesan generik "Request tidak lengkap" yang membingungkan, padahal bukan error.
  if (discordError) {
    return res.send(renderInfoPage({
      emoji: '🚫',
      title: 'Login Dibatalkan',
      message: 'Kamu membatalkan proses login di Discord. Kembali ke aplikasi dan coba lagi kalau berubah pikiran.',
      buttonText: 'Coba Login Lagi',
      buttonHref: state ? `${SERVER_URL}/auth/discord?state=${encodeURIComponent(state)}` : undefined
    }));
  }

  if (!code || !state) return res.status(400).send('Request tidak lengkap.');

  if (!db) {
    return res.status(503).send(renderInfoPage({
      emoji: '⏳',
      title: 'Server Belum Siap',
      message: 'Database masih terhubung, coba lagi dalam beberapa detik.',
      buttonText: 'Coba Lagi',
      buttonHref: `${SERVER_URL}/auth/discord?state=${encodeURIComponent(state)}`
    }));
  }

  try {
    // 1) Tukar "code" dari Discord jadi access token
    const tokenRes = await axios.post('https://discord.com/api/oauth2/token',
      new URLSearchParams({
        client_id: process.env.DISCORD_CLIENT_ID,
        client_secret: process.env.DISCORD_CLIENT_SECRET,
        grant_type: 'authorization_code',
        code,
        redirect_uri: process.env.DISCORD_REDIRECT_URI
      }), { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } });

    const accessToken = tokenRes.data.access_token;

    // 2) Ambil profil Discord user itu
    const profileRes = await axios.get('https://discord.com/api/users/@me', {
      headers: { Authorization: `Bearer ${accessToken}` }
    });
    const discordUser = profileRes.data; // { id, username, avatar, global_name, ... }

    // 3) WAJIB cek apakah dia anggota server Discord kita (pakai BOT token, bukan token user).
    // PENTING: bedakan "benar-benar BUKAN member" (Discord balikin 404 dengan jelas) dari
    // error lain (bot token salah/kadaluarsa, guild ID salah, bot belum di-invite ke server,
    // Discord API lagi down, dll). Sebelumnya SEMUA jenis error di sini dianggap sama seperti
    // "belum join server", jadi user yang SUDAH jadi member pun bisa salah diarahkan ke
    // halaman "Join Discord Server Dulu" hanya karena verifikasinya gagal karena sebab lain —
    // inilah salah satu penyebab login "kelihatan tidak berfungsi" padahal akunnya valid.
    const guildId = process.env.DISCORD_GUILD_ID;
    let isMember = false;
    let memberCheckFailed = false;
    try {
      await axios.get(`https://discord.com/api/guilds/${guildId}/members/${discordUser.id}`, {
        headers: { Authorization: `Bot ${process.env.DISCORD_BOT_TOKEN}` }
      });
      isMember = true;
    } catch (e) {
      const status = e.response?.status;
      if (status === 404) {
        isMember = false; // benar-benar dikonfirmasi Discord: user ini bukan member
      } else {
        // Bukan 404 (401/403/429/network/dll) — verifikasi TIDAK BISA dipastikan, jangan
        // asumsikan "bukan member". Log detailnya biar gampang ditelusuri dari sisi admin.
        memberCheckFailed = true;
        console.error('[Auth] Gagal verifikasi member Discord:', status, e.response?.data || e.message);
      }
    }

    if (memberCheckFailed) {
      return res.status(502).send(renderInfoPage({
        emoji: '⚠️',
        title: 'Verifikasi Gagal Sementara',
        message: 'Server tidak bisa memastikan status member Discord kamu saat ini (kemungkinan gangguan sementara). Akun kamu TIDAK ditolak — coba login lagi dalam beberapa saat.',
        buttonText: 'Coba Login Lagi',
        buttonHref: `${SERVER_URL}/auth/discord?state=${encodeURIComponent(state)}`
      }));
    }

    if (!isMember) {
      return res.send(renderInfoPage({
        emoji: '👋',
        title: 'Join Discord Server Dulu Yuk',
        message: `Kamu belum jadi anggota server Discord kami. Join dulu, abis itu klik tombol di bawah buat login ulang.`,
        buttonText: 'Buka Invite Discord',
        buttonHref: process.env.DISCORD_INVITE_URL,
        secondaryText: 'Sudah join?',
        secondaryButtonText: 'Login Lagi',
        secondaryHref: `${SERVER_URL}/auth/discord?state=${encodeURIComponent(state)}`
      }));
    }

    // 4) Simpan / perbarui user di database. Role default 'public' kalau baru pertama kali.
    const now = new Date();
    const avatarUrl = discordUser.avatar
      ? `https://cdn.discordapp.com/avatars/${discordUser.id}/${discordUser.avatar}.png`
      : `https://cdn.discordapp.com/embed/avatars/${Number(discordUser.discriminator || 0) % 5}.png`;

    await db.collection('users').updateOne(
      { discordId: discordUser.id },
      {
        $set: {
          username: discordUser.global_name || discordUser.username,
          avatarUrl,
          lastLoginAt: now
        },
        $setOnInsert: {
          discordId: discordUser.id,
          role: 'public',
          createdAt: now
        }
      },
      { upsert: true }
    );

    const user = await db.collection('users').findOne({ discordId: discordUser.id });
    const isNewAccount = user.createdAt && new Date(user.createdAt).getTime() === now.getTime();

    // Catat aktivitas login (dipakai Dashboard admin: "Login hari ini", grafik
    // "Login 7 Hari Terakhir", dan Activity Feed) — best-effort, tidak pernah
    // menghambat proses login user kalau gagal simpan.
    logActivity({
      type: 'login',
      username: user.username,
      discordId: user.discordId,
      description: `${user.username} login${isNewAccount ? ' (akun baru)' : ''}.`
    }).catch(() => {});

    // Webhook kategori "Login Akun" (opsional, default OFF supaya tidak spam kalau
    // trafik tinggi) — best-effort, tidak pernah menghambat proses login user.
    webhookManager.sendCategoryWebhook('login', {
      embed: buildEmbed({
        status: 'info',
        title: isNewAccount ? 'Akun Baru Login Pertama Kali' : 'Login Akun',
        description: `${user.username} berhasil login lewat Discord OAuth.`,
        fields: [
          field('👤 Username', user.username, true),
          field('🆔 Discord ID', user.discordId, true),
          field('📦 Paket', (user.role || 'public').toUpperCase(), true)
        ],
        thumbnail: avatarUrl,
        appName: APP_NAME,
        footerNote: 'Login Akun'
      })
    }).catch(() => {});

    // 5) Buat token login (JWT), simpan sementara di 'pendingLogins' biar bisa diambil app lewat /auth/poll
    const loginToken = jwt.sign({ discordId: user.discordId }, JWT_SECRET, { expiresIn: '90d' });
    await db.collection('pendingLogins').updateOne(
      { state },
      { $set: { state, token: loginToken, createdAt: new Date() } },
      { upsert: true }
    );

    return res.send(renderInfoPage({
      emoji: '✅',
      title: 'Login Berhasil!',
      message: `Selamat datang, ${user.username}. Kamu bisa kembali ke aplikasi sekarang — halaman ini boleh ditutup. Lain kali buka app, kamu tinggal tekan "Masuk Sekarang" tanpa perlu login Discord ulang.`,
    }));
  } catch (e) {
    console.error('Discord OAuth error:', e.response?.data || e.message);
    return res.status(500).send(renderInfoPage({
      emoji: '⚠️',
      title: 'Gagal Login',
      message: 'Ada masalah pas nyoba login lewat Discord. Coba lagi dari aplikasinya.',
      buttonText: 'Coba Login Lagi',
      buttonHref: state ? `${SERVER_URL}/auth/discord?state=${encodeURIComponent(state)}` : undefined
    }));
  }
});

// App polling ke sini buat cek apakah login di browser udah kelar
app.get('/auth/poll', async (req, res) => {
  const { state } = req.query;
  if (!state) return res.status(400).json({ error: 'state wajib ada.' });

  const pending = await db.collection('pendingLogins').findOne({ state });
  if (!pending || !pending.token) return res.json({ ready: false });

  // Sekali dipakai langsung dihapus, biar gak bisa dipakai ulang oleh siapapun yang tau state-nya
  await db.collection('pendingLogins').deleteOne({ state });

  const payload = jwt.verify(pending.token, JWT_SECRET);
  const user = await db.collection('users').findOne({ discordId: payload.discordId });

  res.json({
    ready: true,
    token: pending.token,
    user: publicUser(user)
  });
});

function publicUser(u) {
  return {
    discordId: u.discordId,
    username: u.username,
    avatarUrl: u.avatarUrl,
    role: u.role,
    createdAt: u.createdAt || null,
    roleUpdatedAt: u.roleUpdatedAt || null,
    accountStatus: accountStatusSummary(u)
  };
}

// ── Refresh token — perpanjang sesi tanpa login Discord ulang ──
// Dipanggil app saat dapat 401. Token lama (bahkan yang expired) di-decode,
// discordId diambil, user dicek di DB, lalu token baru 90d di-issue.
app.post('/auth/refresh', async (req, res) => {
  try {
    const authHeader = req.headers.authorization || '';
    const oldToken = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
    if (!oldToken) return res.status(401).json({ error: 'Token tidak ada.' });

    let payload;
    try {
      // Coba verify normal dulu (token belum expired)
      payload = jwt.verify(oldToken, JWT_SECRET);
    } catch(e) {
      // Kalau expired, decode tanpa validasi waktu untuk ambil discordId
      payload = jwt.decode(oldToken);
    }
    if (!payload?.discordId) return res.status(401).json({ error: 'Token tidak bisa dibaca.' });

    if (!db) return res.status(503).json({ error: 'Database belum siap.' });
    const user = await db.collection('users').findOne({ discordId: payload.discordId });
    if (!user) return res.status(401).json({ error: 'Akun tidak ditemukan. Silakan login ulang.' });

    const newToken = jwt.sign({ discordId: user.discordId }, JWT_SECRET, { expiresIn: '90d' });
    res.json({ token: newToken, user: publicUser(user) });
  } catch(e) {
    res.status(500).json({ error: e.message });
  }
});

function renderInfoPage({ emoji, title, message, buttonText, buttonHref, secondaryText, secondaryButtonText, secondaryHref }) {
  return `<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${APP_NAME}</title>
  <style>
    *{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',system-ui,sans-serif;}
    body{min-height:100vh;display:flex;align-items:center;justify-content:center;
      background:radial-gradient(circle at 30% 20%, #2b1656 0%, #0b0714 55%, #050308 100%);color:#f2f0f8;}
    .card{max-width:420px;padding:44px 36px;text-align:center;border-radius:24px;
      background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);backdrop-filter:blur(18px);}
    .emoji{font-size:46px;margin-bottom:14px;}
    h1{font-size:22px;margin-bottom:12px;}
    p{color:#c3bfe0;font-size:14px;line-height:1.6;margin-bottom:22px;}
    a.btn{display:inline-block;padding:13px 26px;border-radius:12px;font-weight:600;font-size:14px;
      text-decoration:none;background:linear-gradient(135deg,#7b5cff,#e64bb8);color:#fff;margin:6px;}
    .secondary{margin-top:18px;font-size:12.5px;color:#8f8ab0;}
  </style></head><body>
    <div class="card">
      <div class="emoji">${emoji}</div>
      <h1>${title}</h1>
      <p>${message}</p>
      ${(buttonText && buttonHref) ? `<a class="btn" href="${buttonHref}" target="_blank" rel="noopener">${buttonText}</a>` : ''}
      ${secondaryButtonText ? `<div class="secondary">${secondaryText}<br><a class="btn" style="margin-top:8px;" href="${secondaryHref}">${secondaryButtonText}</a></div>` : ''}
    </div>
  </body></html>`;
}

// ══════════════════════════════════════════════════════════════════════════
// APP — GAME
// ══════════════════════════════════════════════════════════════════════════
app.get('/api/games', requireUser, async (req, res) => {
  try {
    // SEBELUMNYA: filter hanya game yang role-nya <= role user, jadi game
    // yang butuh paket lebih tinggi TIDAK KELIHATAN SAMA SEKALI.
    // SEKARANG: semua game tetap ditampilkan (biar user tahu game itu ada &
    // termotivasi upgrade), tapi akses/download tetap dicek & diblokir server
    // di /api/games/:id/download dan /api/games/:id/stream seperti biasa.
    const games = await db.collection('games')
      .find({})
      .sort({ createdAt: -1 })
      .toArray();
    // PENTING: JANGAN kirim manifestUrl/zipUrl mentah ke client — link asli hanya
    // boleh diketahui server (dipakai proxy di /stream). Kalau field ini bocor ke
    // client, Electron app bisa (sengaja/tidak) langsung shell.openExternal() ke
    // link asli alih-alih lewat proxy stream yang sudah dicek role & di-log.
    res.json(games.map(g => ({
      _id: g._id, name: g.name, description: g.description || '',
      imageUrl: g.imageUrl || '', role: g.role || 'public',
      sizeLabel: g.sizeLabel || '', appId: g.appId || null,
      isOnline: g.isOnline !== false, createdAt: g.createdAt || null,
    })));
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ══════════════════════════════════════════════════════════════════════════
// HALAMAN DETAIL — data ASLI dari Steam Store API berdasarkan App ID
// (BUKAN data fiksi/hardcode). Dipakai app client buat nampilin halaman
// detail game/bypass gaya Steam: cover, release date, metacritic, developer,
// publisher, tag, dan System Requirements (Minimum/Recommended).
// ══════════════════════════════════════════════════════════════════════════
const _steamDetailsCache = new Map(); // appId -> { data, expiresAt }
const STEAM_DETAILS_CACHE_MS = 15 * 60 * 1000; // 15 menit, biar gak spam Steam API tiap buka halaman

// Ubah HTML requirements dari Steam ("<ul class='bb_ul'><li><strong>OS:</strong> ...</li>...")
// jadi array {label, value} yang bersih buat dirender di UI.
function parseSteamRequirements(html) {
  if (!html) return [];
  const items = [];
  const liMatches = html.match(/<li>.*?<\/li>/gis) || [];
  for (const li of liMatches) {
    const inner = li.replace(/^<li>|<\/li>$/gi, '');
    const strongMatch = inner.match(/<strong>(.*?)<\/strong>\s*:?\s*(.*)/is);
    const stripTags = s => s.replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&nbsp;/g, ' ').trim();
    if (strongMatch) {
      const label = stripTags(strongMatch[1]).replace(/:+\s*$/, ''); // buang ':' bawaan Steam biar gak dobel pas dirender
      const value = stripTags(strongMatch[2]);
      if (label || value) items.push({ label, value });
    } else {
      const value = stripTags(inner);
      if (value) items.push({ label: '', value });
    }
  }
  return items;
}

async function fetchSteamDetailsForAppId(appId) {
  const cached = _steamDetailsCache.get(appId);
  if (cached && cached.expiresAt > Date.now()) return cached.data;

  const steamRes = await axios.get('https://store.steampowered.com/api/appdetails', {
    params: { appids: appId, l: 'english' },
    timeout: 12000
  });
  const entry = steamRes.data?.[appId];
  if (!entry?.success || !entry.data) return null;
  const d = entry.data;

  const result = {
    appId,
    name: d.name || null,
    headerImage: d.header_image || null,
    shortDescription: d.short_description || '',
    genres: (d.genres || []).map(g => g.description).filter(Boolean),
    categories: (d.categories || []).map(c => c.description).filter(Boolean),
    releaseDate: d.release_date?.date || null,
    comingSoon: !!d.release_date?.coming_soon,
    metacritic: (typeof d.metacritic?.score === 'number') ? d.metacritic.score : null,
    developers: d.developers || [],
    publishers: d.publishers || [],
    requirementsMin: parseSteamRequirements(d.pc_requirements?.minimum),
    requirementsRec: parseSteamRequirements(d.pc_requirements?.recommended),
    storeUrl: `https://store.steampowered.com/app/${appId}/`
  };

  _steamDetailsCache.set(appId, { data: result, expiresAt: Date.now() + STEAM_DETAILS_CACHE_MS });
  return result;
}

app.get('/api/games/:id/steam-details', requireUser, async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.id)) return res.status(400).json({ error: 'ID tidak valid.' });
    const game = await db.collection('games').findOne({ _id: new ObjectId(req.params.id) });
    if (!game) return res.status(404).json({ error: 'Game tidak ditemukan.' });
    if (!game.appId) return res.status(404).json({ error: 'App ID Steam belum diisi admin untuk game ini.' });

    const details = await fetchSteamDetailsForAppId(game.appId);
    if (!details) return res.status(404).json({ error: `Detail Steam untuk App ID ${game.appId} tidak ditemukan.` });
    res.json(details);
  } catch (e) {
    res.status(500).json({ error: 'Gagal mengambil detail dari Steam: ' + e.message });
  }
});

app.get('/api/bypasses/:id/steam-details', requireUser, async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.id)) return res.status(400).json({ error: 'ID tidak valid.' });
    const bypass = await db.collection('bypasses').findOne({ _id: new ObjectId(req.params.id) });
    if (!bypass) return res.status(404).json({ error: 'Bypass tidak ditemukan.' });
    const appId = bypass.appId || bypass.steamAppId || null;
    if (!appId) return res.status(404).json({ error: 'App ID Steam belum diisi admin untuk bypass ini.' });

    const details = await fetchSteamDetailsForAppId(appId);
    if (!details) return res.status(404).json({ error: `Detail Steam untuk App ID ${appId} tidak ditemukan.` });
    res.json(details);
  } catch (e) {
    res.status(500).json({ error: 'Gagal mengambil detail dari Steam: ' + e.message });
  }
});

// ── DOWNLOAD (metadata): cek role & kembalikan info untuk mulai proses inject.
// TIDAK lagi mengirim URL HubCap mentah + API key ke client (rawan & kadang gagal
// karena Electron fetch langsung ke HubCap tidak sereliable axios di server).
// File-nya sendiri diambil lewat /api/games/:id/stream (proxy dari server).
app.get('/api/games/:id/download', requireUser, async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.id)) return res.status(400).json({ error: 'ID tidak valid.' });
    const game = await db.collection('games').findOne({ _id: new ObjectId(req.params.id) });
    if (!game) return res.status(404).json({ error: 'Game tidak ditemukan.' });

    // Cek role user
    const myLevel   = ROLE_LEVEL[req.user.role] ?? 0;
    const gameLevel = ROLE_LEVEL[game.role]     ?? 0;
    if (myLevel < gameLevel) {
      return res.status(403).json({ error: `Game ini membutuhkan paket ${game.role}. Upgrade paket kamu dulu.` });
    }

    // Cek & konsumsi limit download harian (kategori Game) — public/gold dibatasi,
    // platinum/admin unlimited (lihat DOWNLOAD_LIMITS).
    const quota = await consumeDownloadQuota(req.user, 'game');
    if (!quota.ok) {
      return res.status(429).json({ error: quota.message });
    }

    const rawUrl = game.manifestUrl || game.zipUrl || null;
    if (!rawUrl) {
      return res.status(404).json({ error: 'File download untuk game ini belum diatur admin. Hubungi admin.' });
    }

    res.json({
      streamPath: `/api/games/${req.params.id}/stream`, // client download lewat sini (proxy server)
      appId:      game.appId || null,
      steamAppId: game.appId || null,
      name:       game.name,
      downloadQuota: quota
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── STREAM (proxy): server yang download dari HubCap, lalu diteruskan ke client.
// Auth pakai token JWT yang sama (query ?token=... karena Electron http/https client
// tidak bisa kirim custom header lewat main.js dengan mudah untuk semua kasus redirect,
// jadi paling aman & simpel lewat query string yang HANYA dipakai untuk request ini).
app.get('/api/games/:id/stream', async (req, res) => {
  try {
    const token = req.query.token || (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    if (!token) return res.status(401).json({ error: 'Login diperlukan.' });
    let payload;
    try { payload = jwt.verify(token, JWT_SECRET); } catch { return res.status(401).json({ error: 'Sesi tidak valid, silakan login ulang.' }); }

    if (!ObjectId.isValid(req.params.id)) return res.status(400).json({ error: 'ID tidak valid.' });
    const game = await db.collection('games').findOne({ _id: new ObjectId(req.params.id) });
    if (!game) return res.status(404).json({ error: 'Game tidak ditemukan.' });

    let user = await db.collection('users').findOne({ discordId: payload.discordId });
    if (!user) return res.status(401).json({ error: 'User tidak ditemukan.' });
    user = await applyExpiryIfNeeded(user);

    const myLevel   = ROLE_LEVEL[user.role] ?? 0;
    const gameLevel = ROLE_LEVEL[game.role] ?? 0;
    if (myLevel < gameLevel) return res.status(403).json({ error: `Game ini membutuhkan paket ${game.role}.` });

    const rawUrl = game.manifestUrl || game.zipUrl || null;
    if (!rawUrl) return res.status(404).json({ error: 'File download belum diatur admin.' });

    const isHubcap = rawUrl.includes('hubcapmanifest.com') || rawUrl.includes('hubcap');
    if (isHubcap) {
      if (!game.appId) return res.status(400).json({ error: 'App ID game ini belum diisi admin — tidak bisa ambil manifest dari HubCap.' });
      return await streamHubcapManifest(game.appId, res, game.name);
    }

    // URL non-hubcap (misal link GitHub Release) — redirect langsung, tanpa proxy
    return res.redirect(rawUrl);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── DOWNLOAD BYPASS ──
// ── DOWNLOAD BYPASS (metadata) ──
// ── BYPASS DOWNLOAD LINK (simple, persis seperti project lama) ──
// Return directUrl langsung — tidak ada proxy, tidak ada stream complexity.
// Client (main.js) download langsung dari URL yang admin set.
app.get('/api/bypasses/:id/download-link', requireUser, async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.id)) return res.status(400).json({ error: 'ID tidak valid.' });
    const bypass = await db.collection('bypasses').findOne({ _id: new ObjectId(req.params.id) });
    if (!bypass) return res.status(404).json({ error: 'Bypass tidak ditemukan.' });

    const myLevel     = ROLE_LEVEL[req.user.role]   ?? 0;
    const bypassLevel = ROLE_LEVEL[bypass.role]     ?? 0;
    if (myLevel < bypassLevel) {
      return res.status(403).json({ error: `Bypass ini membutuhkan paket ${bypass.role}.` });
    }

    const url = bypass.zipUrl || bypass.link || bypass.driveLink || null;
    if (!url) {
      return res.status(404).json({ error: 'Link bypass belum diatur admin. Hubungi admin untuk mengisi link file bypass.' });
    }

    // Cek & konsumsi limit download harian (kategori Bypass) — public/gold dibatasi,
    // platinum/admin unlimited (lihat DOWNLOAD_LIMITS).
    const quota = await consumeDownloadQuota(req.user, 'bypass');
    if (!quota.ok) {
      return res.status(429).json({ error: quota.message });
    }

    // BUG FIX: Link dari Ryuu Generator (generator.ryuu.lol) WAJIB pakai auth (session,
    // auth_key parameter, atau X-Auth-Key header) — kalau tidak, Ryuu selalu balikin
    // "Login, auth_key, or auth_code required." Sebelumnya URL dikirim mentah ke client
    // TANPA auth apapun, jadi bypass dari Ryuu SELALU gagal. Sekarang di-proxy lewat
    // server sendiri (pakai RYUU_API_KEY dari .env, sama seperti pola HubCap), supaya
    // admin tidak perlu tempel auth key manual di tiap link, dan key-nya tidak pernah
    // terekspos ke client/Electron.
    const isRyuu = /ryuu\.lol/i.test(url);
    if (isRyuu) {
      if (!RYUU_API_KEY) {
        return res.status(400).json({
          error: 'Link bypass ini dari Ryuu Generator, tapi RYUU_API_KEY belum diisi di server (.env). Hubungi admin untuk mengisinya.'
        });
      }
      return res.json({
        streamPath: `/api/bypasses/${req.params.id}/ryuu-stream`,
        name:       bypass.name,
        steamAppId: bypass.steamAppId || bypass.appId || null,
        downloadQuota: quota
      });
    }

    // Link non-Ryuu (GitHub Release, Google Drive, CDN lain) — tetap seperti sebelumnya,
    // return langsung URL-nya ke client.
    res.json({
      directUrl:  url,
      name:       bypass.name,
      steamAppId: bypass.steamAppId || bypass.appId || null,
      downloadQuota: quota
    });
  } catch(e) {
    res.status(500).json({ error: e.message });
  }
});

// ── PROXY DOWNLOAD RYUU GENERATOR — server yang nempelin auth (X-Auth-Key), client cuma
// terima file ZIP jadi. API key Ryuu tidak pernah dikirim ke Electron/localStorage. ──
app.get('/api/bypasses/:id/ryuu-stream', requireUser, async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.id)) return res.status(400).json({ error: 'ID tidak valid.' });
    const bypass = await db.collection('bypasses').findOne({ _id: new ObjectId(req.params.id) });
    if (!bypass) return res.status(404).json({ error: 'Bypass tidak ditemukan.' });

    const myLevel     = ROLE_LEVEL[req.user.role]   ?? 0;
    const bypassLevel = ROLE_LEVEL[bypass.role]     ?? 0;
    if (myLevel < bypassLevel) {
      return res.status(403).json({ error: `Bypass ini membutuhkan paket ${bypass.role}.` });
    }

    const url = bypass.zipUrl || bypass.link || bypass.driveLink || null;
    if (!url || !/ryuu\.lol/i.test(url)) {
      return res.status(400).json({ error: 'Link bypass ini bukan link Ryuu Generator.' });
    }
    if (!RYUU_API_KEY) {
      return res.status(500).json({ error: 'RYUU_API_KEY belum diisi di server (.env). Hubungi admin.' });
    }

    let ryuuRes;
    try {
      ryuuRes = await axios.get(url, {
        headers: { 'X-Auth-Key': RYUU_API_KEY },
        responseType: 'stream',
        timeout: 0, // file manifest/zip bisa besar
        maxRedirects: 10,
        validateStatus: () => true
      });
    } catch (e) {
      console.error('[RYUU STREAM] Gagal terhubung ke Ryuu Generator:', e.message);
      return res.status(502).json({ error: 'Gagal terhubung ke Ryuu Generator: ' + e.message });
    }

    if (ryuuRes.status !== 200) {
      // Baca body error (biasanya JSON kecil kayak {"error":"..."}) supaya pesannya
      // informatif, bukan cuma "HTTP 401" polos.
      let bodyText = '';
      try {
        for await (const chunk of ryuuRes.data) {
          bodyText += chunk.toString('utf8');
          if (bodyText.length > 500) break;
        }
      } catch (e2) {}
      let parsedMsg = null;
      try {
        const parsed = JSON.parse(bodyText);
        if (parsed && typeof parsed.error === 'string') parsedMsg = parsed.error;
      } catch (e3) {}

      if (ryuuRes.status === 401 || ryuuRes.status === 403) {
        return res.status(401).json({ error: parsedMsg || 'RYUU_API_KEY tidak valid/ditolak Ryuu Generator (401/403). Hubungi admin untuk update key.' });
      }
      if (ryuuRes.status === 404) {
        return res.status(404).json({ error: parsedMsg || 'Manifest untuk game ini tidak ditemukan di Ryuu Generator.' });
      }
      if (ryuuRes.status === 429) {
        return res.status(429).json({ error: parsedMsg || 'Kuota harian Ryuu Generator habis, coba lagi nanti.' });
      }
      return res.status(502).json({ error: parsedMsg || `Ryuu Generator mengembalikan HTTP ${ryuuRes.status}.` });
    }

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${(bypass.name || 'bypass').replace(/[^a-z0-9]/gi, '_')}.zip"`);
    if (ryuuRes.headers['content-length']) res.setHeader('Content-Length', ryuuRes.headers['content-length']);
    ryuuRes.data.pipe(res);
  } catch (e) {
    console.error('[RYUU STREAM] Unexpected error:', e.message);
    if (!res.headersSent) res.status(500).json({ error: e.message });
  }
});

app.get('/api/bypasses/:id/download', requireUser, async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.id)) return res.status(400).json({ error: 'ID tidak valid.' });
    const bypass = await db.collection('bypasses').findOne({ _id: new ObjectId(req.params.id) });
    if (!bypass) return res.status(404).json({ error: 'Bypass tidak ditemukan.' });

    const myLevel     = ROLE_LEVEL[req.user.role]   ?? 0;
    const bypassLevel = ROLE_LEVEL[bypass.role]     ?? 0;
    if (myLevel < bypassLevel) {
      return res.status(403).json({ error: `Bypass ini membutuhkan paket ${bypass.role}.` });
    }

    const url = bypass.zipUrl || bypass.link || null;
    if (!url) {
      return res.status(404).json({ error: 'File bypass belum diatur admin. Hubungi admin.' });
    }

    const quota = await consumeDownloadQuota(req.user, 'bypass');
    if (!quota.ok) {
      return res.status(429).json({ error: quota.message });
    }

    // Kembalikan appId ke client — dipakai untuk findGameFolderByAppId
    // (cari folder game di steamapps sebagai target extract).
    // Stream tetap dari link manual admin (bukan HubCap).
    res.json({
      streamPath: `/api/bypasses/${req.params.id}/stream`,
      steamAppId: bypass.steamAppId || bypass.appId || null,
      appId:      bypass.appId      || bypass.steamAppId || null,
      name:       bypass.name,
      downloadQuota: quota
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/bypasses/:id/stream', async (req, res) => {
  try {
    const token = req.query.token || (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    if (!token) return res.status(401).json({ error: 'Login diperlukan.' });
    let payload;
    try { payload = jwt.verify(token, JWT_SECRET); } catch { return res.status(401).json({ error: 'Sesi tidak valid, silakan login ulang.' }); }

    if (!ObjectId.isValid(req.params.id)) return res.status(400).json({ error: 'ID tidak valid.' });
    const bypass = await db.collection('bypasses').findOne({ _id: new ObjectId(req.params.id) });
    if (!bypass) return res.status(404).json({ error: 'Bypass tidak ditemukan.' });

    let user = await db.collection('users').findOne({ discordId: payload.discordId });
    if (!user) return res.status(401).json({ error: 'User tidak ditemukan.' });
    user = await applyExpiryIfNeeded(user);

    const myLevel     = ROLE_LEVEL[user.role]   ?? 0;
    const bypassLevel = ROLE_LEVEL[bypass.role] ?? 0;
    if (myLevel < bypassLevel) return res.status(403).json({ error: `Bypass ini membutuhkan paket ${bypass.role}.` });

    const rawUrl = bypass.zipUrl || bypass.link || null;

    // ── ROUTING ──
    // Bypass SELALU pakai link (zipUrl/link) yang admin set secara manual —
    // TIDAK menggunakan HubCap sama sekali. HubCap hanya untuk game (inject Steam).
    // Bypass adalah file patch/crack yang link-nya diset admin, bukan manifest Steam.

    if (!rawUrl) {
      return res.status(404).json({ error: 'Link bypass belum diatur admin. Hubungi admin untuk mengisi link file bypass.' });
    }

    // ── STRATEGI DOWNLOAD BERDASARKAN SUMBER LINK ──
    //
    // File bypass bisa >500MB. Men-proxy file besar lewat Railway sangat berisiko
    // (timeout, memory, bandwidth terbatas). Strategi per sumber:
    //
    //  • GitHub Release (objects.githubusercontent.com / github.com/releases)
    //    → REDIRECT langsung ke URL asli. GitHub sudah handle auth via URL token-nya
    //      sendiri, tidak perlu proxy. Client download langsung, server cuma validasi auth.
    //
    //  • Google Drive
    //    → REDIRECT ke direct download URL (uc?export=download). File besar GDrive
    //      punya virus-scan warning, tapi client (Electron/axios di main.js) bisa follow.
    //
    //  • Link lain (custom CDN, dll)
    //    → REDIRECT juga — lebih aman dan efisien daripada proxy untuk file besar.
    //
    // Auth sudah divalidasi di atas (JWT + role check) sebelum redirect dikirim,
    // jadi URL asli baru bocor setelah user terbukti berhak akses.

    const isGithub = /github\.com|githubusercontent\.com/.test(rawUrl);
    const isGdrive = /drive\.google\.com/.test(rawUrl);
    const isRyuu   = /ryuu\.lol|generator\.ryuu\.lol/.test(rawUrl);

    if (isGithub) {
      // GitHub Release: resolve redirect dulu untuk dapat URL objects.githubusercontent.com
      // yang bisa langsung di-download client tanpa perlu header apapun
      try {
        const headRes = await axios.head(rawUrl, {
          maxRedirects: 10,
          timeout: 10000,
          headers: { 'User-Agent': 'ThreeOneStore/1.0' },
          validateStatus: s => s < 400
        });
        // Ikuti redirect — axios.head() sudah resolve ke final URL
        const finalUrl = headRes.request?.res?.responseUrl || headRes.config?.url || rawUrl;
        console.log('[BYPASS] GitHub redirect →', finalUrl);
        return res.redirect(302, finalUrl);
      } catch (e) {
        // Kalau head gagal, coba redirect langsung ke rawUrl — client akan follow sendiri
        console.warn('[BYPASS] GitHub head gagal, redirect ke rawUrl:', e.message);
        return res.redirect(302, rawUrl);
      }
    }

    if (isGdrive) {
      // Google Drive: convert share link → direct download
      const gdMatch = rawUrl.match(/drive\.google\.com\/(?:file\/d\/|open\?id=|uc\?.*id=)([a-zA-Z0-9_\-]+)/);
      const fileId  = gdMatch?.[1];
      if (!fileId) return res.status(400).json({ error: 'Format link Google Drive tidak dikenali.' });
      const directUrl = `https://drive.google.com/uc?export=download&id=${fileId}&confirm=t`;
      return res.redirect(302, directUrl);
    }

    if (isRyuu) {
      // Ryuu menerapkan hotlink protection berdasarkan Referer.
      // Proxy di server-side tidak andal karena Ryuu bisa berubah cara proteksinya.
      // Solusi: kembalikan URL asli ke client (main.js), biarkan main.js download
      // langsung dengan header Ryuu yang benar lewat downloadFileWithProgress.
      // main.js sudah punya logika untuk set User-Agent + Referer yang benar.
      return res.json({ directUrl: rawUrl, method: 'direct' });
    }

    // Link lain — redirect langsung, lebih aman daripada proxy untuk file besar
    return res.redirect(302, rawUrl);
  } catch (e) {
    console.error('[BYPASS STREAM] Unexpected error:', e.message);
    if (!res.headersSent) res.status(500).json({ error: e.message });
  }
});

// ══════════════════════════════════════════════════════════════════════════
// APP — BYPASS
// ══════════════════════════════════════════════════════════════════════════
app.get('/api/bypasses', requireUser, async (req, res) => {
  try {
    // Sama seperti /api/games — semua bypass tetap ditampilkan, akses tetap
    // dicek & diblokir server di /api/bypasses/:id/download & /stream.
    const bypasses = await db.collection('bypasses')
      .find({})
      .sort({ createdAt: -1 })
      .toArray();
    // PENTING: JANGAN kirim zipUrl/link mentah ke client sama sekali — kalau bocor,
    // tombol di app bisa (salah) langsung shell.openExternal() ke link aslinya
    // alih-alih download lewat proxy /api/bypasses/:id/stream yang sudah dicek role.
    // Ini juga PENYEBAB bug "tombol buka link" yang dilaporkan sebelumnya.
    res.json(bypasses.map(b => ({
      _id: b._id, name: b.name, description: b.description || '',
      imageUrl: b.imageUrl || '', role: b.role || 'public',
      sizeLabel: b.sizeLabel || '',
      appId: b.appId || b.steamAppId || null,
      steamAppId: b.steamAppId || b.appId || null,
      gameId: b.gameId || null, // dipakai client buat cocokin tombol "Install Bypass" di halaman detail Game
      isOnline: b.isOnline !== false, createdAt: b.createdAt || null,
    })));
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ══════════════════════════════════════════════════════════════════════════
// APP — HISTORI
// ══════════════════════════════════════════════════════════════════════════
// Dipanggil pas user pencet "Install"/"Pakai" di kartu Game atau Bypass
app.post('/api/history', requireUser, async (req, res) => {
  try {
    const { itemType, itemId, extractedFiles, steamPath, folderPath, itemName: fallbackName, itemImage: fallbackImage } = req.body;
    if (!['game', 'bypass'].includes(itemType)) return res.status(400).json({ error: 'itemType harus game/bypass.' });
    if (!ObjectId.isValid(itemId)) return res.status(400).json({ error: 'itemId tidak valid.' });

    const collectionName = itemType === 'game' ? 'games' : 'bypasses';
    const item = await db.collection(collectionName).findOne({ _id: new ObjectId(itemId) });
    // BUG FIX: SEBELUMNYA kalau item ini sudah keburu dihapus/diedit admin di antara waktu user
    // klik install & proses inject/extract-nya selesai di PC user, route ini langsung 404 dan
    // BATAL MENYIMPAN histori sama sekali — padahal instalasinya sendiri sudah SUKSES di PC user.
    // Ini salah satu penyebab utama laporan "histori kadang hilang". Sekarang: kalau item masih
    // ada, tetap pakai data itemnya (paling akurat/terbaru); kalau sudah gak ada, fallback ke
    // nama & gambar yang sudah dikirim client sejak awal proses install, histori tetap tersimpan.
    if (!item && !fallbackName) return res.status(404).json({ error: 'Item tidak ditemukan.' });

    const insertResult = await db.collection('history').insertOne({
      userId: req.user.discordId,
      username: req.user.username,
      itemType,
      itemId,
      itemName: item?.name || fallbackName || 'Item tidak dikenal',
      itemImage: item?.imageUrl || fallbackImage || null,
      // BUG FIX: dulu field ini (walau sudah dikirim client sejak awal) tidak pernah
      // disimpan, jadi tombol Uninstall di halaman Histori tidak punya cara untuk tahu
      // file apa saja & di folder mana yang harus dihapus di PC user — cuma bisa hapus
      // catatan histori-nya doang, file game/bypass yang sebenarnya tetap ketinggalan.
      extractedFiles: Array.isArray(extractedFiles) ? extractedFiles.filter(f => typeof f === 'string') : [],
      steamPath: itemType === 'game' ? (steamPath || null) : null,
      folderPath: itemType === 'bypass' ? (folderPath || null) : null,
      createdAt: new Date()
    });

    const itemNameResolved = item?.name || fallbackName || 'Item';
    const itemImageResolved = item?.imageUrl || fallbackImage || null;

    logActivity({
      type: 'install',
      username: req.user.username,
      discordId: req.user.discordId,
      description: `${req.user.username} meng-install ${itemType === 'game' ? 'game' : 'bypass'} "${itemNameResolved}".`,
      meta: { itemType, itemId }
    }).catch(() => {});

    notifyUser(req.user.discordId, {
      type: 'download_success',
      title: 'Download Berhasil',
      message: `${itemNameResolved} (${itemType === 'game' ? 'Game' : 'Bypass'}) berhasil di-download & dipasang.`,
      fields: [
        field('👤 Username', req.user.username, true),
        field('🆔 Discord ID', req.user.discordId, true),
        field('🎮 Nama Item', itemNameResolved, true),
        field('📦 Tipe', itemType === 'game' ? 'Game' : 'Bypass', true),
        field('💾 Ukuran File', item?.sizeLabel, true),
        field('🆔 App ID', item?.appId || item?.steamAppId, true),
        field('🧾 ID Riwayat', String(insertResult.insertedId), true)
      ],
      image: itemImageResolved,
      meta: { itemType, itemId },
      dm: false, webhook: true
    }).catch(() => {});

    res.json({ success: true, _id: insertResult.insertedId });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Dipanggil client (main.js) kalau proses download/extract/inject GAGAL di tengah jalan,
// supaya user tetap dapat notifikasi kegagalan walau tidak ada baris histori yang tercatat.
app.post('/api/downloads/failed', requireUser, async (req, res) => {
  try {
    const { itemType, itemName, itemImage, reason } = req.body;

    logActivity({
      type: 'download_failed',
      username: req.user.username,
      discordId: req.user.discordId,
      description: `Download "${itemName || 'item'}" (${itemType === 'game' ? 'Game' : 'Bypass'}) gagal untuk ${req.user.username}.`,
      meta: { itemType, itemName, reason }
    }).catch(() => {});

    notifyUser(req.user.discordId, {
      type: 'download_failed',
      title: 'Download Gagal',
      message: `Download ${itemName || 'item'} (${itemType === 'game' ? 'Game' : 'Bypass'}) gagal.`,
      fields: [
        field('👤 Username', req.user.username, true),
        field('🆔 Discord ID', req.user.discordId, true),
        field('🎮 Nama Item', itemName, true),
        field('📦 Tipe', itemType === 'game' ? 'Game' : (itemType === 'bypass' ? 'Bypass' : undefined), true),
        field('📝 Pesan Tambahan', reason, false)
      ],
      image: itemImage || undefined,
      dm: false, webhook: true
    }).catch(() => {});
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/history', requireUser, async (req, res) => {
  try {
    const rows = await db.collection('history')
      .find({ userId: req.user.discordId })
      .sort({ createdAt: -1 })
      .limit(200)
      .toArray();
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Hapus satu entri histori milik user sendiri (dipakai tombol "Uninstall" di halaman Histori).
// Ini cuma menghapus catatan histori-nya, bukan file di komputer user — launcher ini
// memang belum ngatur instalasi lokal, cuma nyatet apa yang pernah di-install/dipakai.
app.delete('/api/history/:id', requireUser, async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.id)) return res.status(400).json({ error: 'ID tidak valid.' });
    const result = await db.collection('history').deleteOne({
      _id: new ObjectId(req.params.id),
      userId: req.user.discordId // wajib punya user ini sendiri, gak bisa hapus punya orang lain
    });
    if (result.deletedCount === 0) return res.status(404).json({ error: 'Histori tidak ditemukan.' });
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Info akun sendiri (dipakai app buat nampilin nama/role/avatar terbaru)
app.get('/api/me', requireUser, (req, res) => {
  const newToken = res.getHeader('X-New-Token');
  const resp = { ...publicUser(req.user) };
  if (newToken) resp.newToken = newToken; // client simpan token baru kalau ada
  res.json(resp);
});

// ── Endpoint polling cepat KHUSUS role check — jauh lebih ringan dari /api/me
// (tidak load semua field user, tidak perlu token refresh). Dipakai client setiap
// 3 detik untuk deteksi perubahan paket secara realtime. Kalau role sama, cukup
// return { changed: false } tanpa data tambahan supaya network overhead minimal.
app.get('/api/me/role-check', requireUser, (req, res) => {
  res.json({
    role:          req.user.role,
    roleUpdatedAt: req.user.roleUpdatedAt || null
  });
});

// ══════════════════════════════════════════════════════════════════════════
// NOTIFIKASI — endpoint user (in-app)
// ══════════════════════════════════════════════════════════════════════════
app.get('/api/notifications', requireUser, async (req, res) => {
  try {
    const limit = Math.min(Number(req.query.limit) || 30, 100);
    const rows = await db.collection('notifications')
      .find({ discordId: req.user.discordId })
      .sort({ createdAt: -1 })
      .limit(limit)
      .toArray();
    const unread = await db.collection('notifications').countDocuments({ discordId: req.user.discordId, read: false });
    res.json({ items: rows, unread });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.put('/api/notifications/:id/read', requireUser, async (req, res) => {
  try {
    if (!ObjectId.isValid(req.params.id)) return res.status(400).json({ error: 'ID tidak valid.' });
    await db.collection('notifications').updateOne(
      { _id: new ObjectId(req.params.id), discordId: req.user.discordId },
      { $set: { read: true } }
    );
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.put('/api/notifications/read-all', requireUser, async (req, res) => {
  try {
    await db.collection('notifications').updateMany(
      { discordId: req.user.discordId, read: false },
      { $set: { read: true } }
    );
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ══════════════════════════════════════════════════════════════════════════
// ADMIN — LOGIN
// ══════════════════════════════════════════════════════════════════════════
app.post('/api/admin/login', (req, res) => {
  const { password } = req.body;
  if (!password || password !== process.env.ADMIN_PASSWORD) {
    return res.status(401).json({ error: 'Password admin salah.' });
  }
  const token = jwt.sign({ role: 'admin' }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token });
});

// ── Verifikasi token admin — dipanggil admin.js pas halaman di-refresh, supaya
// tahu pasti token di localStorage MASIH valid sebelum nampilin dashboard.
// Tanpa ini, token yang sudah expired/invalid tetap nampilin shell tapi semua
// datanya gagal load (401 di semua request) — kelihatan kayak "stuck".
app.get('/api/admin/verify', requireAdmin, (req, res) => {
  res.json({ success: true, admin: req.admin || { via: 'password' } });
});

// Dipanggil admin.js setelah login lewat Discord OAuth (alur sama seperti login app biasa,
// lihat /auth/poll) — cuma buat kasih pesan yang jelas kalau ternyata akun Discord itu BUKAN
// admin, alih-alih baru ketahuan belakangan pas request lain kena 403 generik.
app.get('/api/admin/verify-discord-token', async (req, res) => {
  try {
    const authHeader = req.headers.authorization || '';
    const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Token tidak ada.' });
    const payload = jwt.verify(token, JWT_SECRET);
    if (!payload?.discordId) return res.status(400).json({ error: 'Bukan token akun Discord.' });
    if (!db) return res.status(503).json({ error: 'Database belum siap, coba lagi.' });
    const user = await db.collection('users').findOne({ discordId: payload.discordId });
    if (!user) return res.status(404).json({ error: 'Akun tidak ditemukan.' });
    if (user.role !== 'admin') {
      return res.status(403).json({
        error: `Akun Discord "${user.username}" ini belum punya role Admin.`,
        role: user.role
      });
    }
    res.json({ success: true, admin: { via: 'discord', discordId: user.discordId, username: user.username, avatarUrl: user.avatarUrl } });
  } catch (e) {
    res.status(401).json({ error: 'Token tidak valid.' });
  }
});

// ══════════════════════════════════════════════════════════════════════════
// ADMIN — DASHBOARD (statistik realtime)
// ══════════════════════════════════════════════════════════════════════════
// Jakarta (WIB) selalu UTC+7 tanpa DST, jadi batas hari/minggu/bulan bisa
// dihitung langsung tanpa library timezone tambahan.
function jakartaMidnightUTC(daysAgo = 0) {
  const JAK_OFFSET_MS = 7 * 60 * 60 * 1000;
  const jakartaMs = Date.now() + JAK_OFFSET_MS;
  const d = new Date(jakartaMs);
  d.setUTCHours(0, 0, 0, 0);
  d.setUTCDate(d.getUTCDate() - daysAgo);
  return new Date(d.getTime() - JAK_OFFSET_MS);
}
function jakartaMonthStartUTC() {
  const JAK_OFFSET_MS = 7 * 60 * 60 * 1000;
  const d = new Date(Date.now() + JAK_OFFSET_MS);
  d.setUTCDate(1);
  d.setUTCHours(0, 0, 0, 0);
  return new Date(d.getTime() - JAK_OFFSET_MS);
}

// Cache singkat (4 detik) — dashboard bisa dibuka di beberapa tab admin
// sekaligus & di-refresh tiap kali ada event WebSocket masuk; cache ini
// mencegah query berat yang sama ditembak berkali-kali dalam rentang waktu
// yang sangat singkat, tanpa membuat datanya jadi basi.
let _dashboardCache = { data: null, at: 0 };
const DASHBOARD_CACHE_MS = 4000;

app.get('/api/admin/dashboard', requireAdmin, async (req, res) => {
  try {
    if (!db) return res.status(503).json({ error: 'Database belum siap, coba lagi sebentar.' });

    if (_dashboardCache.data && (Date.now() - _dashboardCache.at) < DASHBOARD_CACHE_MS) {
      return res.json({ ..._dashboardCache.data, admin: await buildAdminInfo(req.admin) });
    }

    const todayStart   = jakartaMidnightUTC(0);
    const weekStart    = jakartaMidnightUTC(6);   // termasuk hari ini = 7 hari
    const prevWeekStart = jakartaMidnightUTC(13);
    const monthStart   = jakartaMonthStartUTC();

    const [
      totalUsers, usersToday, usersWeek,
      roleCountsAgg,
      totalGames, gamesActive,
      totalBypasses, bypassesActive,
      gamesWithBypassIds,
      installsToday, installsWeek, installsMonth, installsTotal,
      loginsToday, loginsWeek, loginsPrevWeek,
      loginTrendAgg,
      recentActivity
    ] = await Promise.all([
      db.collection('users').countDocuments({}),
      db.collection('users').countDocuments({ createdAt: { $gte: todayStart } }),
      db.collection('users').countDocuments({ createdAt: { $gte: weekStart } }),
      db.collection('users').aggregate([{ $group: { _id: '$role', count: { $sum: 1 } } }]).toArray(),
      db.collection('games').countDocuments({}),
      db.collection('games').countDocuments({ isOnline: { $ne: false } }),
      db.collection('bypasses').countDocuments({}),
      db.collection('bypasses').countDocuments({ isOnline: { $ne: false } }),
      db.collection('bypasses').distinct('gameId', { gameId: { $ne: null } }),
      db.collection('history').countDocuments({ createdAt: { $gte: todayStart } }),
      db.collection('history').countDocuments({ createdAt: { $gte: weekStart } }),
      db.collection('history').countDocuments({ createdAt: { $gte: monthStart } }),
      db.collection('history').countDocuments({}),
      db.collection('activityLogs').countDocuments({ type: 'login', createdAt: { $gte: todayStart } }),
      db.collection('activityLogs').countDocuments({ type: 'login', createdAt: { $gte: weekStart } }),
      db.collection('activityLogs').countDocuments({ type: 'login', createdAt: { $gte: prevWeekStart, $lt: weekStart } }),
      db.collection('activityLogs').aggregate([
        { $match: { type: 'login', createdAt: { $gte: weekStart } } },
        { $group: {
            _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt', timezone: 'Asia/Jakarta' } },
            count: { $sum: 1 }
          } },
        { $sort: { _id: 1 } }
      ]).toArray(),
      db.collection('activityLogs').find({}).sort({ createdAt: -1 }).limit(20).toArray()
    ]);

    const roleCounts = { public: 0, gold: 0, platinum: 0, admin: 0 };
    for (const r of roleCountsAgg) { if (r._id && roleCounts.hasOwnProperty(r._id)) roleCounts[r._id] = r.count; }
    const premiumTotal = roleCounts.gold + roleCounts.platinum;
    const pct = (n) => totalUsers > 0 ? Math.round((n / totalUsers) * 1000) / 10 : 0;

    const data = {
      // Total Users
      totalUsers, usersToday, usersWeek,
      loginsToday, loginsWeek, loginsPrevWeek,
      loginTrend: loginTrendAgg,

      // Total Game
      totalGames, gamesActive, gamesInactive: totalGames - gamesActive,
      totalBypasses, bypassesActive, bypassesInactive: totalBypasses - bypassesActive,
      gamesWithBypass: gamesWithBypassIds.length,

      // Gold Aktif
      totalPublic: roleCounts.public, activeGold: roleCounts.gold, activePlatinum: roleCounts.platinum,
      pctPublic: pct(roleCounts.public), pctGold: pct(roleCounts.gold), pctPlatinum: pct(roleCounts.platinum),
      premiumTotal,

      // Total Install
      installsToday, installsWeek, installsMonth, totalInstalls: installsTotal,

      // Activity feed
      recentActivity
    };

    _dashboardCache = { data, at: Date.now() };
    res.json({ ...data, admin: await buildAdminInfo(req.admin) });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Info admin yang lagi login, dipakai panel "Selamat Datang" (nama, role, waktu
// login terakhir). Password-based admin tidak terikat akun manapun jadi cuma
// ditampilkan sebagai "Administrator" generik.
async function buildAdminInfo(admin) {
  if (!admin) return { username: 'Administrator', role: 'Super Admin', lastLoginAt: null };
  if (admin.via === 'password') return { username: 'Administrator', role: 'Super Admin', lastLoginAt: null };
  try {
    const user = await db.collection('users').findOne({ discordId: admin.discordId });
    return {
      username: admin.username || 'Admin',
      role: 'Admin',
      lastLoginAt: user?.lastLoginAt || null,
      avatarUrl: admin.avatarUrl || null
    };
  } catch {
    return { username: admin.username || 'Admin', role: 'Admin', lastLoginAt: null };
  }
}

// ══════════════════════════════════════════════════════════════════════════
// ADMIN — GAME (CRUD)
// ══════════════════════════════════════════════════════════════════════════
app.get('/api/admin/games', requireAdmin, async (req, res) => {
  const games = await db.collection('games').find({}).sort({ createdAt: -1 }).toArray();
  res.json(games);
});

app.post('/api/admin/games', requireAdmin, async (req, res) => {
  const { name, description, imageUrl, role, appId, storeUrl, manifestUrl, sizeBytes, sizeLabel, isOnline } = req.body;
  if (!name || !ROLE_LEVEL.hasOwnProperty(role)) return res.status(400).json({ error: 'Nama & role wajib diisi dengan benar.' });
  const doc = {
    name,
    description: description || '',
    imageUrl: imageUrl || null,
    role,
    appId: appId ? String(appId) : null,
    storeUrl: storeUrl || null,
    manifestUrl: manifestUrl || null,
    sizeBytes: sizeBytes || null,
    sizeLabel: sizeLabel || null,
    // Tipe game: Online (bisa multiplayer online) / Offline (singleplayer murni).
    // Default TRUE (online) kalau admin tidak eksplisit set false, biar konsisten
    // dengan behaviour lama sebelum field ini ada di form (games lama semua online).
    isOnline: isOnline === false ? false : true,
    createdAt: new Date()
  };
  const result = await db.collection('games').insertOne(doc);

  logActivity({
    type: 'admin_add_game',
    username: req.admin?.username || 'Admin',
    description: `Admin menambahkan game baru "${doc.name}".`,
    meta: { gameId: result.insertedId, name: doc.name }
  }).catch(() => {});

  res.json({ ...doc, _id: result.insertedId });
});

app.put('/api/admin/games/:id', requireAdmin, async (req, res) => {
  if (!ObjectId.isValid(req.params.id)) return res.status(400).json({ error: 'ID tidak valid.' });
  const { name, description, imageUrl, role, appId, storeUrl, manifestUrl, sizeBytes, sizeLabel, isOnline } = req.body;
  const update = {};
  if (name !== undefined) update.name = name;
  if (description !== undefined) update.description = description;
  if (imageUrl !== undefined) update.imageUrl = imageUrl;
  if (appId !== undefined) update.appId = appId ? String(appId) : null;
  if (storeUrl !== undefined) update.storeUrl = storeUrl || null;
  if (manifestUrl !== undefined) update.manifestUrl = manifestUrl || null;
  if (sizeBytes !== undefined) update.sizeBytes = sizeBytes || null;
  if (sizeLabel !== undefined) update.sizeLabel = sizeLabel || null;
  if (isOnline !== undefined) update.isOnline = isOnline === false ? false : true;
  if (role !== undefined) {
    if (!ROLE_LEVEL.hasOwnProperty(role)) return res.status(400).json({ error: 'Role tidak valid.' });
    update.role = role;
  }
  await db.collection('games').updateOne({ _id: new ObjectId(req.params.id) }, { $set: update });

  logActivity({
    type: 'admin_edit_game',
    username: req.admin?.username || 'Admin',
    description: `Admin mengubah data game "${update.name || req.params.id}".`,
    meta: { gameId: req.params.id, update }
  }).catch(() => {});

  res.json({ success: true });
});

app.delete('/api/admin/games/:id', requireAdmin, async (req, res) => {
  if (!ObjectId.isValid(req.params.id)) return res.status(400).json({ error: 'ID tidak valid.' });
  const game = await db.collection('games').findOne({ _id: new ObjectId(req.params.id) });
  await db.collection('games').deleteOne({ _id: new ObjectId(req.params.id) });

  logActivity({
    type: 'admin_delete_game',
    username: req.admin?.username || 'Admin',
    description: `Admin menghapus game "${game?.name || req.params.id}".`,
    meta: { gameId: req.params.id, name: game?.name }
  }).catch(() => {});

  res.json({ success: true });
});

// ══════════════════════════════════════════════════════════════════════════
// ADMIN — BYPASS (CRUD) — polanya sama persis kayak Game
// ══════════════════════════════════════════════════════════════════════════
app.get('/api/admin/bypasses', requireAdmin, async (req, res) => {
  const rows = await db.collection('bypasses').find({}).sort({ createdAt: -1 }).toArray();
  res.json(rows);
});

app.post('/api/admin/bypasses', requireAdmin, async (req, res) => {
  const { name, description, imageUrl, role, link, zipUrl, appId, gameId, isOnline } = req.body;
  if (!name || !ROLE_LEVEL.hasOwnProperty(role)) return res.status(400).json({ error: 'Nama & role wajib diisi dengan benar.' });
  const doc = {
    name,
    description: description || '',
    imageUrl: imageUrl || null,
    role,
    link:   link   || null, // legacy field — link manual dari admin
    zipUrl: zipUrl || link || null, // URL ZIP bypass (bisa GitHub dll) — di-proxy server, tidak pernah ke client
    appId:  appId  || null, // Steam App ID — menentukan folder extract tujuan di PC user
    gameId: (gameId && ObjectId.isValid(gameId)) ? gameId : null,
    // Tipe bypass: Online (bypass buat game yang punya mode online multiplayer) / Offline.
    // Default TRUE kalau tidak eksplisit di-set false.
    isOnline: isOnline === false ? false : true,
    createdAt: new Date()
  };
  const result = await db.collection('bypasses').insertOne(doc);

  logActivity({
    type: 'admin_add_bypass',
    username: req.admin?.username || 'Admin',
    description: `Admin menambahkan bypass baru "${doc.name}".`,
    meta: { bypassId: result.insertedId, name: doc.name }
  }).catch(() => {});

  res.json({ ...doc, _id: result.insertedId });
});

app.put('/api/admin/bypasses/:id', requireAdmin, async (req, res) => {
  if (!ObjectId.isValid(req.params.id)) return res.status(400).json({ error: 'ID tidak valid.' });
  const { name, description, imageUrl, role, link, zipUrl, appId, isOnline } = req.body;
  const update = {};
  if (name        !== undefined) update.name        = name;
  if (description !== undefined) update.description = description;
  if (imageUrl    !== undefined) update.imageUrl    = imageUrl;
  if (link        !== undefined) update.link        = link   || null;
  if (zipUrl      !== undefined) update.zipUrl      = zipUrl || link || null;
  if (appId       !== undefined) update.appId       = appId  || null;
  if (isOnline    !== undefined) update.isOnline    = isOnline === false ? false : true;
  if (role !== undefined) {
    if (!ROLE_LEVEL.hasOwnProperty(role)) return res.status(400).json({ error: 'Role tidak valid.' });
    update.role = role;
  }
  await db.collection('bypasses').updateOne({ _id: new ObjectId(req.params.id) }, { $set: update });

  logActivity({
    type: 'admin_edit_bypass',
    username: req.admin?.username || 'Admin',
    description: `Admin mengubah data bypass "${update.name || req.params.id}".`,
    meta: { bypassId: req.params.id, update }
  }).catch(() => {});

  res.json({ success: true });
});

app.delete('/api/admin/bypasses/:id', requireAdmin, async (req, res) => {
  if (!ObjectId.isValid(req.params.id)) return res.status(400).json({ error: 'ID tidak valid.' });
  const bypass = await db.collection('bypasses').findOne({ _id: new ObjectId(req.params.id) });
  await db.collection('bypasses').deleteOne({ _id: new ObjectId(req.params.id) });

  logActivity({
    type: 'admin_delete_bypass',
    username: req.admin?.username || 'Admin',
    description: `Admin menghapus bypass "${bypass?.name || req.params.id}".`,
    meta: { bypassId: req.params.id, name: bypass?.name }
  }).catch(() => {});

  res.json({ success: true });
});

// ══════════════════════════════════════════════════════════════════════════
// ADMIN — HISTORI (lihat punya semua user) & USERS (atur role)
// ══════════════════════════════════════════════════════════════════════════
// BUG FIX: SEBELUMNYA endpoint ini cuma `.limit(300)` tanpa pagination sama sekali —
// begitu histori sudah lebih dari 300 baris, entri yang lebih lama otomatis TIDAK PERNAH
// kekirim ke admin panel lagi (padahal datanya masih ada utuh di database), makanya
// kelihatan kayak "histori hilang". Sekarang pakai pagination beneran (skip/limit) + total
// count terpisah, jadi SEMUA data tetap bisa dijelajah lewat halaman berikutnya, plus
// dukungan search/filter/sort di level database biar tetap cepat walau datanya banyak.
app.get('/api/admin/history', requireAdmin, async (req, res) => {
  try {
    let { page = '1', perPage = '20', search = '', type = 'all', sort = 'newest', dateFrom = '', dateTo = '' } = req.query;
    page = Math.max(1, parseInt(page, 10) || 1);
    perPage = Math.min(100, Math.max(1, parseInt(perPage, 10) || 20));

    const query = {};
    if (type === 'game' || type === 'bypass') query.itemType = type;
    if (search && search.trim()) {
      const q = search.trim();
      const re = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
      query.$or = [{ username: re }, { itemName: re }, { userId: re }];
    }
    if (dateFrom || dateTo) {
      query.createdAt = {};
      if (dateFrom) query.createdAt.$gte = new Date(dateFrom);
      if (dateTo)   query.createdAt.$lte = new Date(dateTo);
    }

    const sortDir = sort === 'oldest' ? 1 : -1;
    const total = await db.collection('history').countDocuments(query);
    const rows = await db.collection('history')
      .find(query)
      .sort({ createdAt: sortDir })
      .skip((page - 1) * perPage)
      .limit(perPage)
      .toArray();

    // Statistik global (TIDAK ikut kepengaruh filter/search yang lagi aktif) — dipakai
    // buat kartu ringkasan di atas tabel, biar angkanya tetap representasi keseluruhan data.
    const todayStart = new Date(); todayStart.setHours(0, 0, 0, 0);
    const [totalAll, totalGame, totalBypass, totalToday] = await Promise.all([
      db.collection('history').countDocuments({}),
      db.collection('history').countDocuments({ itemType: 'game' }),
      db.collection('history').countDocuments({ itemType: 'bypass' }),
      db.collection('history').countDocuments({ createdAt: { $gte: todayStart } })
    ]);

    res.json({
      rows, total, page, perPage, totalPages: Math.max(1, Math.ceil(total / perPage)),
      stats: { all: totalAll, game: totalGame, bypass: totalBypass, today: totalToday }
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/admin/users', requireAdmin, async (req, res) => {
  const rows = await db.collection('users').find({}).sort({ createdAt: -1 }).toArray();
  res.json(rows.map(publicUser));
});

// "Set paket" — ganti role user dari admin panel. Ini juga sekaligus:
//   1) push role barunya ke Discord (add role tier yang sesuai, cabut role tier lain)
//   2) catat log histori perubahan role
//   3) kirim notif webhook ke channel Discord
// Kalau sync ke Discord gagal (misal role belum di-mapping, atau usernya sudah bukan
// member Discord), role di APP TETAP berhasil diubah — cuma sync Discord-nya yang
// dilaporkan gagal di response, biar admin tau tapi gak nge-block operasi utamanya.

// ──────────────────────────────────────────────────────────────────────────
// DISCORD DM HELPER — kirim DM embed/teks ke user langsung via Bot Token
// ──────────────────────────────────────────────────────────────────────────
async function sendDiscordDM(userId, contentOrPayload) {
  const BOT_TOKEN = process.env.DISCORD_BOT_TOKEN || '';
  if (!BOT_TOKEN) {
    console.warn('[DM] DISCORD_BOT_TOKEN tidak diset, DM tidak terkirim ke', userId);
    return { success: false, reason: 'no_bot_token' };
  }
  if (!userId) return { success: false, reason: 'no_user_id' };
  try {
    const dmRes = await axios.post(
      'https://discord.com/api/v10/users/@me/channels',
      { recipient_id: userId },
      { headers: { Authorization: `Bot ${BOT_TOKEN}`, 'Content-Type': 'application/json' } }
    );
    const channelId = dmRes.data.id;
    const payload = typeof contentOrPayload === 'string'
      ? { content: contentOrPayload }
      : contentOrPayload;
    await axios.post(
      `https://discord.com/api/v10/channels/${channelId}/messages`,
      payload,
      { headers: { Authorization: `Bot ${BOT_TOKEN}`, 'Content-Type': 'application/json' } }
    );
    console.log(`[DM] ✅ Terkirim ke userId=${userId}`);
    return { success: true };
  } catch(e) {
    const status = e.response?.status;
    const errMsg = e.response?.data?.message || e.message;
    const errCode = e.response?.data?.code;
    // 50007 = DM dimatiin user, 10013 = unknown user — bukan error fatal
    console.warn(`[DM] ❌ Gagal ke userId=${userId} | HTTP ${status} | code=${errCode} | ${errMsg}`);
    return { success: false, status, errCode, errMsg };
  }
}

// Masa aktif sekarang bisa diatur admin dalam Menit / Jam / Hari (bukan cuma hari).
// activeAmount = angka, activeUnit = 'minutes' | 'hours' | 'days'. Tetap terima
// activeDays (lama) untuk kompatibilitas mundur kalau ada request dari versi admin panel lama.
const ACTIVE_UNIT_MS = { minutes: 60 * 1000, hours: 60 * 60 * 1000, days: 24 * 60 * 60 * 1000 };
function computeActiveUntil(body) {
  const unit = ACTIVE_UNIT_MS.hasOwnProperty(body.activeUnit) ? body.activeUnit : 'days';
  const amountRaw = (body.activeAmount !== undefined && body.activeAmount !== null && body.activeAmount !== '')
    ? body.activeAmount
    : body.activeDays; // fallback lama
  if (amountRaw === undefined || amountRaw === null || amountRaw === '') return { ok: true, activeUntil: undefined }; // tidak diubah
  const amount = Number(amountRaw);
  if (!Number.isFinite(amount) || amount <= 0) {
    return { ok: false, error: `Masa aktif (${unit === 'minutes' ? 'menit' : unit === 'hours' ? 'jam' : 'hari'}) harus berupa angka lebih dari 0.` };
  }
  return { ok: true, activeUntil: new Date(Date.now() + amount * ACTIVE_UNIT_MS[unit]), unit, amount };
}

app.put('/api/admin/users/:discordId/role', requireAdmin, async (req, res) => {
  const { role } = req.body;
  if (!ROLE_LEVEL.hasOwnProperty(role)) return res.status(400).json({ error: 'Role tidak valid.' });

  const user = await db.collection('users').findOne({ discordId: req.params.discordId });
  if (!user) return res.status(404).json({ error: 'User tidak ditemukan.' });

  const oldRole  = user.role;
  const discordId = req.params.discordId;
  const username  = user.username || discordId;

  // Masa aktif (activeUntil) cuma relevan buat Gold & Platinum — Public & Admin selalu
  // unlimited waktu jadi field-nya dikosongkan lagi kalau paketnya diubah ke salah satunya.
  const update = { role, roleUpdatedAt: new Date() };
  if (role === 'gold' || role === 'platinum') {
    const period = computeActiveUntil(req.body);
    if (!period.ok) return res.status(400).json({ error: period.error });
    if (period.activeUntil !== undefined) {
      update.activeUntil = period.activeUntil;
    } else if (oldRole !== role) {
      // Baru pindah ke Gold/Platinum tapi masa aktifnya belum diisi -> kosongkan dulu,
      // admin bisa atur belakangan lewat "Atur Masa Aktif" tanpa perlu ganti paket lagi.
      update.activeUntil = null;
    }
    // Kalau role-nya SAMA & masa aktif tidak dikirim -> activeUntil yang ada dibiarkan apa adanya.
  } else {
    update.activeUntil = null;
  }

  await db.collection('users').updateOne(
    { discordId },
    { $set: update }
  );

  let discordSync = null;
  let dmResult    = null;

  if (oldRole !== role) {
    // 1. Sinkron role ke Discord (add tier baru, cabut tier lama)
    discordSync = await roleSync.syncAppRoleToDiscord(discordId, role);

    // 2. Kirim DM embed ke user
    const ROLE_COLOR = { public: 0x8f8ab0, gold: 0xffd76a, platinum: 0xa78bfa, admin: 0x4ade80 };
    const ROLE_ICON  = { public: '🌐', gold: '🥇', platinum: '💎', admin: '👑' };
    const ROLE_DESC  = {
      public:   'Akses Public — limit harian berlaku.',
      gold:     'Akses Gold — limit harian lebih besar.',
      platinum: 'Akses Platinum — download UNLIMITED!',
      admin:    'Akses Admin — kelola panel admin & akses semua fitur.'
    };
    const newActiveUntil = update.activeUntil !== undefined ? update.activeUntil : (user.activeUntil || null);
    const purchaseFields = [
      field('👤 Username', username, true),
      field('🆔 Discord ID', discordId, true),
      field('📦 Paket Sebelumnya', `${ROLE_ICON[oldRole] || '❓'} ${oldRole.toUpperCase()}`, true),
      field('📦 Paket Baru', `${ROLE_ICON[role] || '🌐'} ${role.toUpperCase()}`, true),
      field('ℹ️ Info Paket', ROLE_DESC[role] || role, false),
      field('⏳ Masa Aktif Sampai', newActiveUntil ? fmtDateTimeWIB(newActiveUntil) : (role === 'gold' || role === 'platinum' ? 'Belum diatur admin' : null), true)
    ];

    dmResult = await sendDiscordDM(discordId, {
      embeds: [buildEmbed({
        status: 'success',
        title: 'Paket Kamu Diperbarui!',
        description: `Halo **${username}**, paket kamu telah diubah oleh Admin.`,
        fields: purchaseFields,
        thumbnail: APP_LOGO_URL || undefined,
        appName: APP_NAME,
        footerNote: 'Notifikasi Paket'
      })]
    });

    // Catat aktivitas "Pembelian Paket" — dipakai Dashboard admin (stat Gold/Platinum
    // realtime & Activity Feed). Cuma dicatat kalau rolenya beneran berubah.
    logActivity({
      type: 'purchase',
      username,
      discordId,
      description: `Admin mengubah paket ${username} dari ${oldRole.toUpperCase()} ke ${role.toUpperCase()}.`,
      meta: { oldRole, newRole: role }
    }).catch(() => {});

    // 3. Log + webhook detail ke channel Discord (via roleSync — log audit Verify Role)
    await roleSync.logRoleChange({
      discordId, username, oldRole, newRole: role,
      source: 'admin',
      discordSync,
      dmResult
    });

    // 3b. Webhook kategori "Pembelian Paket" — channel Discord terpisah, khusus buat
    // notif tiap kali admin mengaktifkan/mengubah paket seorang user (best-effort).
    webhookManager.sendCategoryWebhook('purchase', {
      embed: buildEmbed({
        status: 'success',
        title: 'Paket Diperbarui',
        description: `Admin mengaktifkan/mengubah paket seorang user.`,
        fields: purchaseFields,
        thumbnail: APP_LOGO_URL || undefined,
        appName: APP_NAME,
        footerNote: 'Pembelian Paket'
      })
    }).catch(() => {});

    // 4. Realtime ke client — user tidak perlu reload, role langsung terupdate
    // Cara: tandai di DB field realtimePush, diambil pollingnya refreshCurrentUserRole (tiap 15 detik)
    // Tidak perlu socket — /api/me sudah di-hit tiap 15 detik dari client
  }

  pushAccountUpdate(discordId).catch(() => {});

  res.json({
    success: true,
    discordSync,
    dmSent: dmResult?.success ?? null,
    roleAssigned: discordSync?.added ?? null,
    roleRemoved: discordSync?.removed ?? [],
    activeUntil: update.activeUntil !== undefined ? update.activeUntil : (user.activeUntil || null)
  });
});

// "Atur Masa Aktif" — ubah/perpanjang masa aktif Gold/Platinum TANPA ganti paket.
// Berguna buat perpanjang langganan user yang paketnya sudah benar tapi mau
// ditambah/reset masa aktifnya (mis. user baru bayar lagi). Sekarang mendukung
// satuan Menit/Jam/Hari (activeAmount + activeUnit), bukan cuma hari.
app.put('/api/admin/users/:discordId/active-period', requireAdmin, async (req, res) => {
  try {
    const { clear } = req.body;
    const discordId = req.params.discordId;
    const user = await db.collection('users').findOne({ discordId });
    if (!user) return res.status(404).json({ error: 'User tidak ditemukan.' });
    if (user.role !== 'gold' && user.role !== 'platinum') {
      return res.status(400).json({ error: 'Masa aktif cuma berlaku untuk paket Gold & Platinum.' });
    }

    let activeUntil = null;
    if (!clear) {
      const period = computeActiveUntil(req.body);
      if (!period.ok) return res.status(400).json({ error: period.error });
      if (period.activeUntil === undefined) return res.status(400).json({ error: 'Isi jumlah masa aktif dulu.' });
      activeUntil = period.activeUntil;
    }

    await db.collection('users').updateOne({ discordId }, { $set: { activeUntil } });

    const renewalFields = [
      field('👤 Username', user.username || discordId, true),
      field('🆔 Discord ID', discordId, true),
      field('📦 Paket', user.role.toUpperCase(), true),
      field('⏳ Masa Aktif Sampai', activeUntil ? fmtDateTimeWIB(activeUntil) : 'Direset (belum diatur ulang)', true)
    ];

    notifyUser(discordId, {
      type: 'renewal',
      title: clear ? 'Masa Aktif Direset' : 'Masa Aktif Diperpanjang',
      message: clear
        ? 'Masa aktif paket kamu telah direset oleh Admin.'
        : `Masa aktif paket kamu telah diperpanjang oleh Admin, aktif sampai ${fmtDateTimeWIB(activeUntil)}.`,
      fields: renewalFields,
      dm: true, webhook: false
    }).catch(() => {});

    logActivity({
      type: 'renewal',
      username: user.username || discordId,
      discordId,
      description: clear
        ? `Admin mereset masa aktif paket ${user.username || discordId}.`
        : `Admin memperpanjang masa aktif paket ${user.username || discordId} sampai ${fmtDateTimeWIB(activeUntil)}.`,
      meta: { role: user.role, activeUntil }
    }).catch(() => {});

    // Webhook kategori "Perpanjangan Paket" — channel Discord terpisah, khusus buat
    // notif tiap kali admin memperpanjang/mereset masa aktif paket user (best-effort).
    webhookManager.sendCategoryWebhook('renewal', {
      embed: buildEmbed({
        status: 'info',
        title: clear ? 'Masa Aktif Direset' : 'Masa Aktif Diperpanjang',
        description: clear ? 'Admin mereset masa aktif paket user.' : 'Admin memperpanjang masa aktif paket user.',
        fields: renewalFields,
        thumbnail: APP_LOGO_URL || undefined,
        appName: APP_NAME,
        footerNote: 'Perpanjangan Paket'
      })
    }).catch(() => {});

    pushAccountUpdate(discordId).catch(() => {});

    res.json({ success: true, activeUntil });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// "Reset Limit Download" — reset counter download harian user hari ini ke 0 (Game &
// Bypass). Berguna kalau user komplain limitnya kepakai gara-gara error/bug pas download.
app.put('/api/admin/users/:discordId/reset-quota', requireAdmin, async (req, res) => {
  try {
    const discordId = req.params.discordId;
    const user = await db.collection('users').findOne({ discordId });
    if (!user) return res.status(404).json({ error: 'User tidak ditemukan.' });

    await db.collection('users').updateOne(
      { discordId },
      { $set: { downloadUsage: { date: todayDateStrJakarta(), game: 0, bypass: 0 } } }
    );
    pushAccountUpdate(discordId).catch(() => {});

    logActivity({
      type: 'admin_reset_quota',
      username: req.admin?.username || 'Admin',
      description: `Admin mereset limit download harian ${user.username || discordId}.`,
      meta: { discordId }
    }).catch(() => {});

    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ══════════════════════════════════════════════════════════════════════════
// ADMIN — PENGUMUMAN / NOTIFIKASI
// ══════════════════════════════════════════════════════════════════════════
// Kirim pengumuman ke SATU user (target=discordId) atau SEMUA user (target='all').
app.post('/api/admin/notifications/send', requireAdmin, async (req, res) => {
  try {
    const { target, title, message, dm, webhook } = req.body;
    if (!title || !message) return res.status(400).json({ error: 'Judul & pesan wajib diisi.' });

    if (!target || target === 'all') {
      const count = await notifyAllUsers({ title, message, dm: !!dm, webhook: webhook !== false });
      logActivity({
        type: 'announcement',
        username: req.admin?.username || 'Admin',
        description: `Admin mengirim broadcast "${title}" ke ${count} user.`,
        meta: { target: 'all', title, sentTo: count }
      }).catch(() => {});
      return res.json({ success: true, sentTo: count });
    }

    const user = await db.collection('users').findOne({ discordId: target });
    if (!user) return res.status(404).json({ error: 'User tidak ditemukan.' });
    await notifyUser(target, {
      type: 'announcement', title, message,
      fields: [
        field('👤 Username', user.username || target, true),
        field('🆔 Discord ID', target, true)
      ],
      dm: !!dm, webhook: !!webhook
    });
    logActivity({
      type: 'announcement',
      username: req.admin?.username || 'Admin',
      description: `Admin mengirim pesan "${title}" ke ${user.username || target}.`,
      meta: { target, title }
    }).catch(() => {});
    res.json({ success: true, sentTo: 1 });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/admin/notifications', requireAdmin, async (req, res) => {
  try {
    const rows = await db.collection('notifications').find({}).sort({ createdAt: -1 }).limit(200).toArray();
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ══════════════════════════════════════════════════════════════════════════
// ADMIN — WEBHOOK SETTINGS (webhook Discord per kategori notifikasi)
// ══════════════════════════════════════════════════════════════════════════

// Daftar semua kategori + status konfigurasinya (url terset/tidak, aktif/tidak,
// status terakhir Valid/Invalid). Dipakai buat render halaman Webhook Settings.
app.get('/api/admin/webhooks', requireAdmin, async (req, res) => {
  try {
    const rows = await webhookManager.getAll();
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Simpan/ubah URL & status aktif satu kategori webhook. Berlaku langsung
// (realtime) — notifikasi berikutnya utk kategori ini otomatis pakai URL baru,
// tanpa perlu restart server.
app.put('/api/admin/webhooks/:category', requireAdmin, async (req, res) => {
  try {
    const { url, enabled } = req.body;
    const updated = await webhookManager.upsert(req.params.category, { url, enabled });
    res.json(updated);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// Kirim pesan uji coba ke satu kategori webhook. Body opsional { url } dipakai
// kalau admin mau test URL yang baru diketik SEBELUM disimpan.
app.post('/api/admin/webhooks/:category/test', requireAdmin, async (req, res) => {
  try {
    const result = await webhookManager.testWebhook(req.params.category, req.body?.url);
    if (!result.sent) return res.status(400).json({ error: result.error || 'Gagal mengirim test webhook. Cek lagi URL-nya.' });
    res.json({ success: true });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// ══════════════════════════════════════════════════════════════════════════
// ADMIN — VERIFY ROLE (sinkron role App ⇄ Discord, webhook, resync, log)
// ══════════════════════════════════════════════════════════════════════════

// Ambil setting saat ini (role mapping, webhook url, dll) + status koneksi bot gateway
app.get('/api/admin/role-sync/settings', requireAdmin, async (req, res) => {
  try {
    const settings = await roleSync.getSettings();
    res.json({ ...settings, gateway: roleSync.getGatewayStatus() });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Simpan mapping role Discord (gold/platinum → role ID) & webhook URL
app.put('/api/admin/role-sync/settings', requireAdmin, async (req, res) => {
  try {
    const { discordRoleMap, webhookUrl, autoSyncFromDiscord, resetRoleOnLeave } = req.body;
    const updated = await roleSync.updateSettings({ discordRoleMap, webhookUrl, autoSyncFromDiscord, resetRoleOnLeave });
    res.json(updated);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Daftar role yang ada di server Discord (buat dropdown pilih "role mana = Gold/Platinum")
app.get('/api/admin/role-sync/discord-roles', requireAdmin, async (req, res) => {
  try {
    const roles = await roleSync.getGuildRoles();
    // Buang @everyone & role yang dikelola bot lain (managed) — gak relevan buat dipilih manual
    const filtered = (roles || [])
      .filter(r => r.name !== '@everyone' && !r.managed)
      .sort((a, b) => b.position - a.position)
      .map(r => ({ id: r.id, name: r.name, color: r.color }));
    res.json(filtered);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Kirim pesan test ke webhook yang lagi disetel
app.post('/api/admin/role-sync/test-webhook', requireAdmin, async (req, res) => {
  try {
    const result = await roleSync.sendTestWebhook();
    if (!result.sent) return res.status(400).json({ error: 'Gagal kirim webhook. Cek lagi URL webhook-nya.' });
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Full resync 2 arah — app_to_discord (dorong semua role app ke Discord) atau
// discord_to_app (tarik role Discord aktual jadi role app). Dipakai sekali pas
// awal setup fitur ini, atau kalau dicurigai ada yang "kesenggol" manual & out-of-sync.
app.post('/api/admin/role-sync/resync', requireAdmin, async (req, res) => {
  try {
    const { direction } = req.body;
    if (!['app_to_discord', 'discord_to_app'].includes(direction)) {
      return res.status(400).json({ error: 'direction harus app_to_discord atau discord_to_app.' });
    }
    const summary = await roleSync.fullResync(direction);
    res.json(summary);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Log histori perubahan role (dari admin, dari Discord, atau karena keluar server)
app.get('/api/admin/role-sync/logs', requireAdmin, async (req, res) => {
  try {
    const rows = await db.collection('roleSyncLogs').find({}).sort({ createdAt: -1 }).limit(200).toArray();
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ══════════════════════════════════════════════════════════════════════════
// ADMIN — APP ID LOOKUP (Steam + hubcapmanifest), dipakai pas nambah Game
// ══════════════════════════════════════════════════════════════════════════
// Alurnya:
//  1. Ambil info dasar (nama, foto, link store, deskripsi singkat) dari Steam Store API
//     pakai App ID yang diketik admin — ini publik, gak butuh API key.
//  2. Cek ke hubcapmanifest apakah manifest buat App ID itu TERSEDIA, sekalian ambil
//     ukuran filenya dari header response (Content-Length), TANPA download isinya
//     (pakai HEAD dulu, fallback GET stream yang langsung di-stop begitu header masuk)
//     — supaya gak boros kuota harian API key hubcapmanifest.
function formatBytes(bytes) {
  if (!bytes || isNaN(bytes)) return null;
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0, val = Number(bytes);
  while (val >= 1024 && i < units.length - 1) { val /= 1024; i++; }
  return `${val.toFixed(val >= 10 || i === 0 ? 0 : 1)} ${units[i]}`;
}

// Cek manifest hubcapmanifest tanpa full-download.
// Beberapa server (termasuk hubcapmanifest) balikin HTTP 405 buat HEAD request
// karena route-nya cuma didaftarkan buat GET — jadi HEAD bukan exception yang
// dilempar axios, tapi response biasa dengan status 405. Makanya fallback ke
// GET-stream-lalu-di-stop harus jalan setiap kali HEAD BUKAN 200/404, bukan cuma
// pas HEAD gagal total (network error).
async function checkHubcapManifest(appId) {
  if (!HUBCAP_API_KEY) return { configured: false, hasManifest: null, sizeBytes: null };
  const url = `${HUBCAP_BASE_URL}/api/v1/lua/${encodeURIComponent(appId)}`;
  const headers = { Authorization: `Bearer ${HUBCAP_API_KEY}` };

  // 1) Coba HEAD dulu (paling hemat kuota kalau didukung)
  try {
    const headRes = await axios.head(url, { headers, timeout: 10000, validateStatus: () => true });
    if (headRes.status === 200) {
      const len = headRes.headers['content-length'];
      return { configured: true, hasManifest: true, sizeBytes: len ? Number(len) : null };
    }
    if (headRes.status === 404) return { configured: true, hasManifest: false, sizeBytes: null };
    // 401/403/429/405/dll -> lanjut coba metode GET-stream di bawah, JANGAN langsung nyerah
  } catch (e) {
    // HEAD error jaringan -> lanjut ke fallback GET-stream juga
  }

  // 2) Fallback: GET biasa tapi responseType 'stream' & langsung di-destroy begitu
  //    header/status masuk, jadi gak menarik seluruh isi file (hemat kuota & bandwidth).
  try {
    const getRes = await axios.get(url, { headers, timeout: 10000, responseType: 'stream', validateStatus: () => true });
    const status = getRes.status;
    const len = getRes.headers['content-length'];
    getRes.data.destroy();
    if (status === 200) return { configured: true, hasManifest: true, sizeBytes: len ? Number(len) : null };
    if (status === 404) return { configured: true, hasManifest: false, sizeBytes: null };
    if (status === 401 || status === 403) return { configured: true, hasManifest: null, sizeBytes: null, error: 'hubcapmanifest: API key tidak valid/ditolak (401/403).' };
    if (status === 429) return { configured: true, hasManifest: null, sizeBytes: null, error: 'hubcapmanifest: kuota harian API key habis (429).' };
    return { configured: true, hasManifest: null, sizeBytes: null, error: `hubcapmanifest: HTTP ${status}` };
  } catch (e2) {
    return { configured: true, hasManifest: null, sizeBytes: null, error: 'hubcapmanifest: gagal dihubungi.' };
  }
}

app.get('/api/admin/appid-lookup/:appId', requireAdmin, async (req, res) => {
  const appId = String(req.params.appId).trim();
  if (!/^\d+$/.test(appId)) return res.status(400).json({ error: 'App ID harus berupa angka (App ID Steam).' });

  const result = {
    appId,
    name: null,
    description: null,
    imageUrl: null,
    storeUrl: `https://store.steampowered.com/app/${appId}/`,
    manifestUrl: null,
    sizeBytes: null,
    sizeLabel: null,
    hasManifest: null,
    hubcapConfigured: !!HUBCAP_API_KEY,
    // Deteksi otomatis tipe game (Online/Offline) dari kategori Steam-nya, biar toggle
    // di form admin bisa langsung ke-set default sesuai game aslinya — admin tetap bisa
    // ubah manual kalau deteksinya kurang pas.
    categories: [],
    isOnlineSuggested: null,
    warnings: []
  };

  // 1) Steam Store API (publik)
  try {
    const steamRes = await axios.get('https://store.steampowered.com/api/appdetails', {
      params: { appids: appId, l: 'english' },
      timeout: 10000
    });
    const entry = steamRes.data?.[appId];
    if (entry?.success && entry.data) {
      const d = entry.data;
      result.name = d.name || null;
      result.imageUrl = d.header_image || null;
      result.description = (d.short_description || '').slice(0, 300) || null;

      // Kategori Steam (mis. "Single-player", "Multi-player", "Online Co-op", "Online PvP", dst)
      // dipakai buat nebak apakah game ini punya mode online multiplayer atau murni offline.
      const catNames = (d.categories || []).map(c => c.description).filter(Boolean);
      result.categories = catNames;
      const ONLINE_HINT = /online|multi-?player|co-?op|pvp|mmo/i;
      const hasOnlineHint = catNames.some(c => ONLINE_HINT.test(c));
      // Kalau kategorinya CUMA "Single-player" tanpa hint online sama sekali → offline.
      result.isOnlineSuggested = catNames.length ? hasOnlineHint : null;
    } else {
      result.warnings.push('App ID tidak ditemukan di Steam Store.');
    }
  } catch (e) {
    result.warnings.push('Gagal mengambil data dari Steam Store.');
  }

  // 2) hubcapmanifest — cek ketersediaan manifest & ukuran file
  try {
    const hc = await checkHubcapManifest(appId);
    result.hubcapConfigured = hc.configured;
    result.hasManifest = hc.hasManifest;
    result.sizeBytes = hc.sizeBytes;
    result.sizeLabel = formatBytes(hc.sizeBytes);
    // Link manifest langsung ditampilkan ke admin kalau memang tersedia di hubcapmanifest,
    // biar bisa dicek/dibuka manual juga.
    // Simpan sebagai /manifest/ (ZIP berisi .lua + .manifest), BUKAN /lua/ (file mentah)
    // karena main.js Electron mengharapkan ZIP saat inject game ke Steam.
    if (hc.hasManifest === true) result.manifestUrl = `${HUBCAP_BASE_URL}/api/v1/manifest/${appId}`;
    if (hc.error) result.warnings.push(hc.error);
    if (hc.configured && hc.hasManifest === false) result.warnings.push('Manifest untuk App ID ini belum tersedia di hubcapmanifest.');
    if (!hc.configured) result.warnings.push('HUBCAP_API_KEY belum diisi di .env — cek ketersediaan manifest & ukuran file dilewati.');
  } catch (e) {
    result.warnings.push('Gagal mengecek hubcapmanifest.');
  }

  res.json(result);
});

// ══════════════════════════════════════════════════════════════════════════
// ADMIN — SEARCH COVER ART (SteamGridDB), opsional dipakai pas nambah Game/Bypass
// ══════════════════════════════════════════════════════════════════════════
app.get('/api/admin/steamgriddb-search', requireAdmin, async (req, res) => {
  try {
    const q = req.query.q;
    if (!q) return res.status(400).json({ error: 'Parameter q wajib diisi.' });
    if (!process.env.STEAMGRIDDB_API_KEY) return res.status(400).json({ error: 'STEAMGRIDDB_API_KEY belum diisi di .env.' });

    const headers = { Authorization: `Bearer ${process.env.STEAMGRIDDB_API_KEY}` };
    const searchRes = await axios.get(`https://www.steamgriddb.com/api/v2/search/autocomplete/${encodeURIComponent(q)}`, { headers });
    const firstMatch = searchRes.data.data?.[0];
    if (!firstMatch) return res.json({ results: [] });

    const gridRes = await axios.get(`https://www.steamgriddb.com/api/v2/grids/game/${firstMatch.id}?dimensions=600x900`, { headers });
    const results = (gridRes.data.data || []).slice(0, 8).map(g => ({ url: g.url, thumb: g.thumb }));
    res.json({ gameName: firstMatch.name, results });
  } catch (e) {
    res.status(500).json({ error: e.response?.data?.errors?.[0] || e.message });
  }
});

// ══════════════════════════════════════════════════════════════════════════
// PUBLIC CONFIG — dipanggil app pas start, biar tau nama brand & guild invite
// ══════════════════════════════════════════════════════════════════════════
app.get('/api/config', (req, res) => {
  res.json({
    appName: APP_NAME,
    discordInviteUrl: process.env.DISCORD_INVITE_URL
  });
});

// ══════════════════════════════════════════════════════════════════════════
// HEALTH CHECK — Railway/render butuh ini untuk cek server hidup
// ══════════════════════════════════════════════════════════════════════════
app.get('/health', (req, res) => {
  res.json({ status: 'ok', db: db ? 'connected' : 'disconnected', app: APP_NAME });
});

app.get('/', (req, res) => {
  if (req.accepts('html')) {
    return res.sendFile(path.join(__dirname, 'public', 'admin.html'));
  }
  res.json({ app: APP_NAME, status: 'running' });
});

// ══════════════════════════════════════════════════════════════════════════
// START
// ══════════════════════════════════════════════════════════════════════════
// ══════════════════════════════════════════════════════════════════════════
// REALTIME — periodic scan buat notifikasi "masa aktif hampir habis".
// Jalan tiap 15 menit, cek user Gold/Platinum yang activeUntil-nya kurang dari 24 jam
// lagi dan belum dikasih tau hari ini (ditandai lewat field periodWarnedAt supaya tidak spam).
// ══════════════════════════════════════════════════════════════════════════
async function scanExpiringPeriods() {
  if (!db) return;
  try {
    const soon = new Date(Date.now() + 24 * 60 * 60 * 1000);
    const users = await db.collection('users').find({
      role: { $in: ['gold', 'platinum'] },
      activeUntil: { $ne: null, $lte: soon, $gt: new Date() }
    }).toArray();

    for (const u of users) {
      const alreadyWarnedToday = u.periodWarnedAt &&
        (new Date(u.periodWarnedAt).toDateString() === new Date().toDateString());
      if (alreadyWarnedToday) continue;

      const msLeft = new Date(u.activeUntil).getTime() - Date.now();
      const hoursLeft = Math.max(1, Math.round(msLeft / (60 * 60 * 1000)));
      await notifyUser(u.discordId, {
        type: 'period_low',
        title: 'Masa Aktif Hampir Habis',
        message: `Masa aktif paket ${u.role.toUpperCase()} kamu tersisa sekitar ${hoursLeft} jam lagi. Perpanjang sekarang biar tidak terputus.`,
        fields: [
          field('👤 Username', u.username, true),
          field('🆔 Discord ID', u.discordId, true),
          field('📦 Paket', u.role.toUpperCase(), true),
          field('⏳ Sisa Masa Aktif', fmtDurationMs(msLeft) || `${hoursLeft} jam`, true),
          field('📅 Berakhir Pada', fmtDateTimeWIB(u.activeUntil), true)
        ],
        dm: true, webhook: true
      });
      await db.collection('users').updateOne({ discordId: u.discordId }, { $set: { periodWarnedAt: new Date() } });
    }
  } catch (e) {
    console.warn('[Realtime] Gagal scan masa aktif hampir habis:', e.message);
  }
}
setInterval(scanExpiringPeriods, 15 * 60 * 1000);

// ══════════════════════════════════════════════════════════════════════════
// START — http server manual (bukan app.listen langsung) supaya bisa nempelin
// WebSocket server (realtime) di path yang sama tanpa port terpisah.
// ══════════════════════════════════════════════════════════════════════════
const httpServer = http.createServer(app);
const wss = new WebSocket.Server({ server: httpServer, path: '/ws' });

wss.on('connection', (ws, req) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    const token = url.searchParams.get('token');
    const isAdminConn = url.searchParams.get('admin') === '1';
    if (!token || !JWT_SECRET) { ws.close(4001, 'no token'); return; }
    const payload = jwt.verify(token, JWT_SECRET);

    // ── Koneksi Dashboard Admin ── token admin lama (password bersama, tanpa
    // discordId) ATAU token akun Discord yang role-nya 'admin' di DB.
    if (isAdminConn) {
      (async () => {
        try {
          if (payload.role === 'admin' && !payload.discordId) {
            // token password admin — valid langsung, tidak terikat akun manapun
          } else if (payload.discordId) {
            if (!db) { ws.close(4001, 'db not ready'); return; }
            const user = await db.collection('users').findOne({ discordId: payload.discordId });
            if (!user || user.role !== 'admin') { ws.close(4003, 'not admin'); return; }
          } else {
            ws.close(4001, 'invalid token'); return;
          }

          wsRegisterAdmin(ws);
          ws.send(JSON.stringify({ event: 'connected', data: { ok: true } }));
          ws.on('close', () => wsUnregisterAdmin(ws));
          ws.on('error', () => wsUnregisterAdmin(ws));
          ws.isAlive = true;
          ws.on('pong', () => { ws.isAlive = true; });
        } catch (e) {
          ws.close(4001, 'auth failed');
        }
      })();
      return;
    }

    const discordId = payload.discordId;
    if (!discordId) { ws.close(4001, 'invalid token'); return; }

    wsRegister(discordId, ws);
    ws.send(JSON.stringify({ event: 'connected', data: { ok: true } }));

    ws.on('close', () => wsUnregister(discordId, ws));
    ws.on('error', () => wsUnregister(discordId, ws));
    // heartbeat sederhana biar koneksi mati (mis. laptop sleep) ke-detect & dibersihin
    ws.isAlive = true;
    ws.on('pong', () => { ws.isAlive = true; });
  } catch (e) {
    ws.close(4001, 'auth failed');
  }
});

// Ping semua koneksi tiap 30 detik; kalau ga jawab 1x ronde berikutnya -> putus.
setInterval(() => {
  wss.clients.forEach(ws => {
    if (ws.isAlive === false) return ws.terminate();
    ws.isAlive = false;
    try { ws.ping(); } catch {}
  });
}, 30000);

// ══════════════════════════════════════════════════════════════════════════
// WEBHOOK — kategori "Error Sistem" (opsional, default OFF). Best-effort,
// sengaja TIDAK process.exit()/crash walau ada error tak tertangani — biar
// sejalan dengan filosofi keseluruhan file ini (kegagalan satu bagian tidak
// boleh menghentikan proses utama). Admin bisa aktifkan lewat Webhook Settings
// kalau mau dapat notif Discord tiap kali ada error semacam ini.
// ══════════════════════════════════════════════════════════════════════════
process.on('unhandledRejection', (reason) => {
  console.error('[Unhandled Rejection]', reason);
  logActivity({
    type: 'system_error',
    description: `Unhandled Promise Rejection: ${String(reason?.message || reason).slice(0, 200)}`
  }).catch(() => {});
  webhookManager.sendCategoryWebhook('system_error', {
    embed: buildEmbed({
      status: 'error',
      title: 'Unhandled Promise Rejection',
      description: 'Ada promise yang gagal tapi tidak tertangani di server. Proses utama tetap berjalan normal.',
      fields: [field('📝 Pesan Tambahan', '```' + String(reason?.stack || reason).slice(0, 950) + '```', false)],
      thumbnail: APP_LOGO_URL || undefined,
      appName: APP_NAME,
      footerNote: 'Error Sistem'
    })
  }).catch(() => {});
});
process.on('uncaughtException', (err) => {
  console.error('[Uncaught Exception]', err);
  logActivity({
    type: 'system_error',
    description: `Uncaught Exception: ${String(err?.message || err).slice(0, 200)}`
  }).catch(() => {});
  webhookManager.sendCategoryWebhook('system_error', {
    embed: buildEmbed({
      status: 'error',
      title: 'Uncaught Exception',
      description: 'Ada error tak tertangani di server. Proses utama tetap berjalan normal (tidak crash).',
      fields: [field('📝 Pesan Tambahan', '```' + String(err?.stack || err).slice(0, 950) + '```', false)],
      thumbnail: APP_LOGO_URL || undefined,
      appName: APP_NAME,
      footerNote: 'Error Sistem'
    })
  }).catch(() => {});
});

// Server SELALU start dulu, DB connect di background.
// Ini penting supaya Railway tidak anggap server crash hanya karena DB lambat konek.
httpServer.listen(PORT, () => {
  console.log(`🚀 ${APP_NAME} backend jalan di port ${PORT} (HTTP + WebSocket realtime di /ws)`);
});

connectDB().catch(e => {
  console.error('❌ Gagal konek MongoDB:', e.message);
});

// Gateway Discord buat fitur Verify Role (Discord→App). Independen dari DB —
// tetap dicoba connect walau MongoDB lagi lambat/gagal, biar gak saling nge-block.
roleSync.startGateway();