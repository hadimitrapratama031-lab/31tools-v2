// ══════════════════════════════════════════════════════════════════════════
// LIVE CHAT SUPPORT — Floating Chat Widget (App Desktop)
// Modul BARU & TERPISAH dari app.js — sengaja dipisah file supaya tidak
// mengganggu logic app.js yang sudah ada. Reuse global yang SUDAH ADA di
// app.js (dimuat SEBELUM file ini di index.html, jadi tetap satu script
// scope yang sama): SERVER_URL, api(), currentUser, escapeHtml().
//
// Hook realtime: app.js meneruskan event WebSocket berawalan 'livechat:' ke
// window.LiveChatWidget.handleWsEvent(msg) lewat switch _ws.onmessage yang
// SUDAH ADA (lihat perubahan kecil di app.js) — TIDAK bikin koneksi
// WebSocket baru sama sekali, semua lewat _ws yang sama dengan fitur lain.
// ══════════════════════════════════════════════════════════════════════════

(function () {
  const EMOJI_LIST = ['😀','😁','😂','🤣','😊','😍','😘','😜','🤔','😎','😢','😭','😡','👍','👎','👏','🙏','🔥','🎉','❤️','💯','✅','❌','⚠️','🎮','💬','😴','🥳'];

  let widgetOpen = false;
  let widgetInited = false;
  let loadedOnce = false;
  let messages = [];
  let pendingImage = null; // { dataUrl, file }
  let unreadCount = 0;
  let adminOnline = false;
  let typingHideTimer = null;
  let sendTypingTimer = null;
  let lastTypingSentAt = 0;

  function $(id) { return document.getElementById(id); }

  function fmtTime(d) {
    try { return new Date(d).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }); }
    catch (e) { return ''; }
  }

  // ══════════════════════════ FLOATING HINT ("butuh bantuan? chat admin") ══════════════════════════
  // Muncul OTOMATIS sekali saat App dibuka (dipicu dari pollSessionState() begitu
  // FAB pertama kali tampil), tampil 5 detik lalu hilang sendiri. Guard
  // `hintShownThisSession` memastikan cuma muncul SEKALI per App dibuka —
  // TIDAK berulang tiap kali FAB toggle/logout-login lagi di sesi App yang sama.
  let hintShownThisSession = false;
  let hintHideTimer = null;
  function showFloatingHint() {
    if (hintShownThisSession) return;
    hintShownThisSession = true;
    const el = $('lcHint');
    if (!el) return;
    el.classList.remove('hide');
    // requestAnimationFrame supaya transisi masuk (opacity/transform) selalu
    // ke-trigger dengan mulus walau elemen baru saja diubah dari display awal.
    requestAnimationFrame(() => el.classList.add('show'));
    clearTimeout(hintHideTimer);
    hintHideTimer = setTimeout(hideFloatingHint, 5000);
  }
  function hideFloatingHint() {
    clearTimeout(hintHideTimer);
    const el = $('lcHint');
    if (!el) return;
    el.classList.remove('show');
    el.classList.add('hide');
  }

  // ══════════════════════════ FAB + WIDGET TOGGLE ══════════════════════════
  function setBadge(n) {
    unreadCount = n;
    const el = $('lcFabBadge');
    if (!el) return;
    if (n > 0) { el.style.display = 'flex'; el.textContent = n > 99 ? '99+' : String(n); }
    else el.style.display = 'none';
  }

  function openWidget() {
    widgetOpen = true;
    hideFloatingHint(); // user sudah buka chat — floating hint tidak relevan lagi
    $('lcWidget').style.display = 'flex';
    $('lcFabBtn').classList.add('lc-open');
    hideNotifPopup();
    if (!loadedOnce) loadMessages();
    else resyncMessages(); // resync ringan tiap dibuka — jaga-jaga ada yang kelewat
    markRead();
    scrollToBottom(false);
    setTimeout(() => $('lcInputText')?.focus(), 120);
  }

  function closeWidget() {
    widgetOpen = false;
    $('lcWidget').style.display = 'none';
    $('lcFabBtn').classList.remove('lc-open');
  }

  function toggleWidget() {
    if (widgetOpen) closeWidget(); else openWidget();
  }

  // ══════════════════════════ LOAD & RENDER ══════════════════════════
  function renderSkeleton() {
    const body = $('lcMessages');
    body.innerHTML = `<div class="lc-skeleton-row">
      <div class="lc-skeleton" style="width:60%;align-self:flex-start;"></div>
      <div class="lc-skeleton" style="width:45%;align-self:flex-end;"></div>
      <div class="lc-skeleton" style="width:70%;align-self:flex-start;"></div>
    </div>`;
  }

  let _syncing = false;

  async function loadMessages() {
    renderSkeleton();
    try {
      const data = await api('/api/livechat/messages');
      messages = data.messages || [];
      adminOnline = !!data.adminOnline;
      loadedOnce = true;
      renderAll();
      setHeaderStatus(adminOnline);
    } catch (e) {
      $('lcMessages').innerHTML = `<div class="lc-empty"><div class="lc-empty-sub">Gagal memuat chat. Coba lagi nanti.</div></div>`;
    }
  }

  // FIX (Live Chat realtime, akar masalah utama): dipanggil setiap kali socket
  // WS (re)connect (lihat hook di app.js `_ws.onopen`). Bandingkan riwayat lokal
  // vs riwayat server — kalau ada balasan Admin yang MASUK selama socket sempat
  // putus (mis. laptop sleep / jaringan pindah / server restart) tapi belum
  // sempat ter-render, langsung ditampilkan sekarang juga TANPA perlu user
  // menutup-buka App. Aman dipanggil berkali-kali (ada guard `_syncing`) dan
  // idempotent (dedup by _id) — tidak akan menimbulkan pesan dobel.
  async function resyncMessages({ silent } = {}) {
    if (!currentUser || _syncing) return;
    _syncing = true;
    try {
      const data = await api('/api/livechat/messages');
      const fresh = data.messages || [];
      adminOnline = !!data.adminOnline;
      setHeaderStatus(adminOnline);

      if (loadedOnce) {
        const knownIds = new Set(messages.map(m => String(m._id)));
        const missedAdminMsgs = fresh.filter(m => m.sender === 'admin' && !knownIds.has(String(m._id)) && !m.readByUser);
        messages = fresh;
        if (widgetOpen) {
          renderAll();
          markRead();
        } else if (missedAdminMsgs.length) {
          setBadge(unreadCount + missedAdminMsgs.length);
          showNotifPopup(missedAdminMsgs[missedAdminMsgs.length - 1]);
        }
      } else {
        messages = fresh;
        loadedOnce = true;
        if (widgetOpen) renderAll();
      }
    } catch (e) {
      // Diam-diam — akan dicoba lagi di reconnect/poll berikutnya, jangan
      // ganggu UI kalau memang cuma sesaat lagi offline.
    } finally {
      _syncing = false;
    }
  }

  function renderAll() {
    const empty = $('lcEmpty');
    const list = $('lcMessages');
    if (!messages.length) {
      empty.style.display = 'flex';
      empty.style.flexDirection = 'column';
      empty.style.alignItems = 'center';
      list.innerHTML = '';
      return;
    }
    empty.style.display = 'none';
    list.innerHTML = messages.map(renderMessageRow).join('');
    scrollToBottom(false);
  }

  function renderMessageRow(m) {
    const mine = m.sender === 'user';
    const imgHtml = m.imageData ? `<img src="${m.imageData}" data-lc-zoom loading="lazy" />` : '';
    const textHtml = m.text ? `<div>${escapeHtml(m.text).replace(/\n/g, '<br>')}</div>` : '';
    const readTick = mine
      ? `<svg class="icon ${m.readByAdmin ? 'lc-read' : ''}"><use href="#ic-check-check"></use></svg>`
      : '';
    return `
      <div class="lc-msg-row ${mine ? 'lc-from-user' : 'lc-from-admin'}" data-id="${m._id}">
        <div class="lc-bubble">${textHtml}${imgHtml}</div>
        <div class="lc-msg-meta">${escapeHtml(fmtTime(m.createdAt))}${readTick}</div>
      </div>`;
  }

  function appendMessage(m) {
    // Guard yang sama seperti sisi Admin — cegah dobel kalau suatu saat ada event WS
    // yang echo balik ke pengirimnya sendiri.
    if (messages.some(x => String(x._id) === String(m._id))) return;
    messages.push(m);
    const empty = $('lcEmpty');
    if (empty) empty.style.display = 'none';
    const list = $('lcMessages');
    list.insertAdjacentHTML('beforeend', renderMessageRow(m));
    scrollToBottom(true);
  }

  function scrollToBottom(smooth) {
    const body = $('lcBody');
    if (!body) return;
    requestAnimationFrame(() => { body.scrollTop = body.scrollHeight; });
  }

  // ══════════════════════════ SEND ══════════════════════════
  async function sendMessage() {
    const textEl = $('lcInputText');
    const text = (textEl.value || '').trim();
    if (!text && !pendingImage) return;

    const btn = $('lcSendBtn');
    btn.disabled = true;
    try {
      const body = { text };
      if (pendingImage) body.imageData = pendingImage.dataUrl;
      const res = await api('/api/livechat/send', { method: 'POST', body: JSON.stringify(body) });
      appendMessage(res.message);
      textEl.value = '';
      autoGrowTextarea(textEl);
      clearPendingImage();
    } catch (e) {
      showAppNotifToastSafe('Gagal Mengirim', e.message || 'Pesan gagal terkirim, coba lagi.');
    } finally {
      btn.disabled = false;
    }
  }

  function autoGrowTextarea(el) {
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 90) + 'px';
  }

  // ══════════════════════════ TYPING INDICATOR ══════════════════════════
  function notifyTyping() {
    const now = Date.now();
    if (now - lastTypingSentAt < 1500) return; // throttle, jangan spam request tiap keystroke
    lastTypingSentAt = now;
    api('/api/livechat/typing', { method: 'POST', body: JSON.stringify({ typing: true }) }).catch(() => {});
  }

  function showTypingIndicator() {
    $('lcTypingIndicator').style.display = 'flex';
    scrollToBottom(true);
    clearTimeout(typingHideTimer);
    typingHideTimer = setTimeout(() => { $('lcTypingIndicator').style.display = 'none'; }, 3500);
  }

  // ══════════════════════════ READ STATUS ══════════════════════════
  async function markRead() {
    try {
      await api('/api/livechat/read', { method: 'POST' });
      setBadge(0);
    } catch (e) {}
  }

  // ══════════════════════════ ADMIN ONLINE STATUS ══════════════════════════
  function setHeaderStatus(online) {
    adminOnline = online;
    const el = $('lcHeaderStatus');
    if (!el) return;
    el.innerHTML = online
      ? `<span class="lc-dot lc-dot-online"></span> Online`
      : `<span class="lc-dot lc-dot-offline"></span> Offline`;
  }

  // ══════════════════════════ IMAGE UPLOAD ══════════════════════════
  function handleImageFile(file) {
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      showAppNotifToastSafe('Gambar Terlalu Besar', 'Ukuran gambar maksimal 5MB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      pendingImage = { dataUrl: reader.result, file };
      $('lcImagePreviewImg').src = reader.result;
      $('lcImagePreview').style.display = 'block';
    };
    reader.readAsDataURL(file);
  }

  function clearPendingImage() {
    pendingImage = null;
    $('lcImagePreview').style.display = 'none';
    $('lcImagePreviewImg').src = '';
    $('lcImageInput').value = '';
  }

  // ══════════════════════════ EMOJI PICKER ══════════════════════════
  function buildEmojiPicker() {
    const el = $('lcEmojiPicker');
    el.innerHTML = EMOJI_LIST.map(e => `<button type="button" data-emoji="${e}">${e}</button>`).join('');
    el.addEventListener('click', (ev) => {
      const btn = ev.target.closest('button[data-emoji]');
      if (!btn) return;
      const textEl = $('lcInputText');
      textEl.value += btn.dataset.emoji;
      autoGrowTextarea(textEl);
      textEl.focus();
    });
  }

  function toggleEmojiPicker() {
    const el = $('lcEmojiPicker');
    const btn = $('lcEmojiBtn');
    const show = el.style.display === 'none';
    el.style.display = show ? 'grid' : 'none';
    btn.classList.toggle('active', show);
  }

  // ══════════════════════════ LIGHTBOX (perbesar gambar) ══════════════════════════
  function openLightbox(src) {
    const box = document.createElement('div');
    box.className = 'lc-lightbox';
    box.innerHTML = `<img src="${src}">`;
    box.addEventListener('click', () => box.remove());
    document.body.appendChild(box);
  }

  // ══════════════════════════ NOTIFICATION POPUP (widget tertutup) ══════════════════════════
  function showNotifPopup(m) {
    const el = $('lcNotifPopup');
    const preview = m.text ? escapeHtml(m.text).slice(0, 90) : '📷 Mengirim gambar';
    el.innerHTML = `
      <div class="lc-notif-popup-icon">31</div>
      <div>
        <div class="lc-notif-popup-title">💬 31 Store Support</div>
        <div class="lc-notif-popup-msg">${preview}</div>
        <div class="lc-notif-popup-cta">Lihat Chat →</div>
      </div>`;
    el.classList.add('show');
    el.onclick = () => openWidget();
    clearTimeout(el._hideTimer);
    el._hideTimer = setTimeout(hideNotifPopup, 6000);
  }
  function hideNotifPopup() {
    const el = $('lcNotifPopup');
    if (el) el.classList.remove('show');
  }

  function showAppNotifToastSafe(title, msg) {
    // Reuse toast kecil app.js kalau ada, fallback diam-diam kalau tidak.
    if (typeof showAppNotifToast === 'function') {
      showAppNotifToast({ type: 'other', title, message: msg });
    }
  }

  // ══════════════════════════ REALTIME (dipanggil dari app.js) ══════════════════════════
  function handleWsEvent(msg) {
    if (!msg || !msg.event) return;
    if (msg.event === 'livechat:message') {
      const m = msg.data;
      if (!currentUser || m.discordId !== currentUser.discordId) return;
      if (m.sender === 'admin') {
        $('lcTypingIndicator').style.display = 'none';
        if (widgetOpen) {
          appendMessage(m);
          markRead();
        } else {
          messages.push(m);
          loadedOnce = true;
          setBadge(unreadCount + 1);
          showNotifPopup(m);
        }
      } else if (m.sender === 'user') {
        // Sinkron dari device lain milik user yang sama (multi-device) — hindari duplikat.
        if (!messages.some(x => String(x._id) === String(m._id))) {
          messages.push(m);
          if (widgetOpen) appendMessage2(m);
        }
      }
    } else if (msg.event === 'livechat:typing') {
      if (msg.data?.from === 'admin' && widgetOpen) showTypingIndicator();
    } else if (msg.event === 'livechat:adminStatus') {
      setHeaderStatus(!!msg.data?.online);
    } else if (msg.event === 'livechat:cleared') {
      // Auto delete tengah malam / TTL — reset tampilan chat, mulai percakapan baru.
      messages = [];
      unreadCount = 0;
      setBadge(0);
      if (widgetOpen) renderAll();
    }
  }
  // helper kecil supaya pesan dari device lain (bukan hasil kirim sendiri di
  // widget ini) tetap ter-render kalau widget sedang kebuka.
  function appendMessage2(m) {
    if (messages.some(x => String(x._id) === String(m._id))) return;
    const empty = $('lcEmpty');
    if (empty) empty.style.display = 'none';
    $('lcMessages').insertAdjacentHTML('beforeend', renderMessageRow(m));
    scrollToBottom(true);
  }

  // ══════════════════════════ POLLING FALLBACK (defense-in-depth, BUKAN mekanisme
  // utama) ══════════════════════════
  // Perbaikan utama realtime ada di resyncMessages() yang dipicu event 'onSocketOpen'
  // dari app.js setiap kali WS (re)connect — ini cuma jaring pengaman tambahan kalau
  // untuk alasan tak terduga koneksi terlihat "OPEN" tapi sebenarnya sudah mati tanpa
  // pernah memicu close/reconnect sama sekali (sangat jarang, tapi murah untuk dijaga).
  let pollTimer = null;
  function startPollFallback() {
    clearInterval(pollTimer);
    pollTimer = setInterval(() => { if (currentUser) resyncMessages({ silent: true }); }, 25000);
  }

  // ══════════════════════════ SHOW/HIDE BERDASARKAN SESI LOGIN ══════════════════════════
  // FAB sengaja disembunyikan (display:none) di index.html sampai user benar-benar
  // login (currentUser terisi oleh app.js) — hindari nebak-nebak urutan bootstrap
  // app.js, cukup poll ringan tiap 500ms.
  let _wasLoggedIn = false;
  function pollSessionState() {
    const loggedIn = !!(typeof currentUser !== 'undefined' && currentUser && localStorage.getItem('token'));
    const fab = $('lcFabBtn');
    if (!fab) return;
    if (loggedIn && !_wasLoggedIn) {
      fab.style.display = 'flex';
      loadMessages();
      showFloatingHint();
    } else if (!loggedIn && _wasLoggedIn) {
      fab.style.display = 'none';
      closeWidget();
      messages = []; loadedOnce = false; setBadge(0);
    }
    _wasLoggedIn = loggedIn;
  }

  // ══════════════════════════ INIT ══════════════════════════
  function init() {
    if (widgetInited) return;
    widgetInited = true;
    buildEmojiPicker();

    $('lcFabBtn').addEventListener('click', toggleWidget);
    $('lcMinimizeBtn').addEventListener('click', closeWidget);
    $('lcCloseBtn').addEventListener('click', closeWidget);

    $('lcSendBtn').addEventListener('click', sendMessage);
    $('lcInputText').addEventListener('keydown', (ev) => {
      if (ev.key === 'Enter' && !ev.shiftKey) { ev.preventDefault(); sendMessage(); }
    });
    $('lcInputText').addEventListener('input', (ev) => {
      autoGrowTextarea(ev.target);
      if (ev.target.value.trim()) notifyTyping();
    });

    $('lcEmojiBtn').addEventListener('click', toggleEmojiPicker);
    $('lcImageBtn').addEventListener('click', () => $('lcImageInput').click());
    $('lcImageInput').addEventListener('change', (ev) => handleImageFile(ev.target.files?.[0]));
    $('lcImagePreviewRemove').addEventListener('click', clearPendingImage);

    $('lcMessages').addEventListener('click', (ev) => {
      const img = ev.target.closest('img[data-lc-zoom]');
      if (img) openLightbox(img.src);
    });

    setInterval(pollSessionState, 500);
    pollSessionState();
    startPollFallback();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  window.LiveChatWidget = {
    handleWsEvent,
    openWidget,
    closeWidget,
    // Dipanggil dari app.js setiap kali _ws (re)connect — lihat catatan FIX di
    // resyncMessages() untuk penjelasan akar masalahnya.
    onSocketOpen: () => resyncMessages()
  };
})();
