// ══════════════════════════════════════════════════════════════════════════
// 31 TOOLS — RENDERER (app.js)
// ══════════════════════════════════════════════════════════════════════════
const SERVER_URL = 'https://31store-production.up.railway.app';
const WS_URL = SERVER_URL.replace(/^http/, 'ws') + '/ws';

// ══════════════════════════════════════════════════════════════════════════
// PERF FIX — LAZY IMAGE LOADING untuk kartu game/bypass
// SEBELUM: renderGameCard/renderBypassCard langsung menaruh
// `background-image:url(...)` inline di setiap kartu. Browser MENDOWNLOAD
// SEMUA gambar itu begitu kartu masuk DOM, walau kartu-nya masih di luar
// layar (background-image tidak lazy secara native seperti <img loading=lazy>).
// Kalau daftar game ada 50-100+, ini artinya 50-100+ request gambar resolusi
// penuh ditembak BERSAMAAN saat halaman dibuka/scroll -> CPU/RAM/network
// spike, dan kartu yang sudah terlihat pun jadi ikut lambat kebagian
// bandwidth/decode time.
// SESUDAH: URL gambar disimpan di `data-img` (BUKAN langsung di style), lalu
// sebuah IntersectionObserver global cuma mengisi background-image saat kartu
// itu benar-benar mendekati viewport (rootMargin dilebarkan dikit biar
// preload sebelum sempat kelihatan, jadi tetap terasa instan). Kartu yang
// sudah pernah dimuat browser otomatis tidak didownload ulang (HTTP cache
// browser), dan kartu yang belum pernah masuk viewport TIDAK PERNAH
// men-trigger request gambar sama sekali.
// ══════════════════════════════════════════════════════════════════════════
let _cardImgObserver = null;
function _ensureCardImgObserver() {
  if (_cardImgObserver) return _cardImgObserver;
  if (typeof IntersectionObserver === 'undefined') return null;
  _cardImgObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const url = el.dataset.img;
      if (url) {
        el.style.backgroundImage = `url('${url}')`;
        el.style.backgroundSize = 'cover';
        el.style.backgroundPosition = 'center';
      }
      el.removeAttribute('data-img');
      _cardImgObserver.unobserve(el);
    });
  }, { root: null, rootMargin: '600px 0px', threshold: 0.01 });
  return _cardImgObserver;
}
// Dipanggil sekali per elemen `.game-art[data-img]` yang baru dibuat (lihat
// reconcileCardGrid). Kalau IntersectionObserver tidak tersedia sama sekali
// (browser sangat lama), fallback langsung tampilkan gambar seperti semula.
function observeCardImg(artEl) {
  if (!artEl || !artEl.dataset.img) return;
  const obs = _ensureCardImgObserver();
  if (!obs) {
    artEl.style.backgroundImage = `url('${artEl.dataset.img}')`;
    artEl.style.backgroundSize = 'cover';
    artEl.style.backgroundPosition = 'center';
    artEl.removeAttribute('data-img');
    return;
  }
  obs.observe(artEl);
}

// ── HELPER ──
function getOrCreateDeviceId() {
  let id = localStorage.getItem('deviceId');
  if (!id) {
    id = 'dev_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 10);
    localStorage.setItem('deviceId', id);
  }
  return id;
}

// ── Auto-refresh token saat 401 ──
let _refreshing = false;
let _refreshPending = null;

async function refreshToken() {
  if (_refreshing) return _refreshPending;
  _refreshing = true;
  _refreshPending = (async () => {
    const old = localStorage.getItem('token');
    if (!old) return null;
    try {
      const res = await fetch(SERVER_URL + '/auth/refresh', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${old}` }
      });
      if (!res.ok) return null;
      const data = await res.json();
      if (data.token) { localStorage.setItem('token', data.token); return data.token; }
    } catch(e) {}
    return null;
  })();
  try { return await _refreshPending; }
  finally { _refreshing = false; _refreshPending = null; }
}

async function api(path, options = {}) {
  const doFetch = (token) => fetch(SERVER_URL + path, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {})
    }
  });

  let token = localStorage.getItem('token');
  let res = await doFetch(token);

  // Simpan token baru kalau server refresh otomatis (X-New-Token header)
  const newTokenFromHeader = res.headers.get('X-New-Token');
  if (newTokenFromHeader) localStorage.setItem('token', newTokenFromHeader);

  // Kalau masih 401 → coba refresh manual lalu retry
  if (res.status === 401 && token) {
    const newToken = await refreshToken();
    if (newToken) {
      res = await doFetch(newToken);
    } else {
      localStorage.removeItem('token');
      showLogin();
      throw new Error('Sesi kamu sudah berakhir. Silakan login ulang.');
    }
  }

  const data = await res.json().catch(() => ({}));

  // Simpan newToken dari body /api/me kalau ada
  if (data.newToken) localStorage.setItem('token', data.newToken);

  if (!res.ok) throw new Error(data.error || 'Terjadi kesalahan.');
  return data;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str || '';
  return div.innerHTML;
}

function timeAgo(dateStr) {
  const diffSec = Math.floor((Date.now() - new Date(dateStr).getTime()) / 1000);
  if (diffSec < 60) return 'Baru saja';
  if (diffSec < 3600) return Math.floor(diffSec / 60) + ' menit lalu';
  if (diffSec < 86400) return Math.floor(diffSec / 3600) + ' jam lalu';
  return Math.floor(diffSec / 86400) + ' hari lalu';
}

// ── TITLEBAR (minimize / fullscreen / close) ──
function wireTitlebar() {
  document.getElementById('btnMinimize')?.addEventListener('click', () => window.electronAPI?.minimize());
  document.getElementById('btnMaximize')?.addEventListener('click', () => window.electronAPI?.maximize());
  document.getElementById('btnClose')?.addEventListener('click', () => window.electronAPI?.close());
}

// ── AMBIL REFERENSI ELEMEN ──
const els = {};
function grabElements() {
  els.app          = document.querySelector('.app');
  els.profileImg   = document.querySelector('.sidebar .profile img');
  els.profileName  = document.querySelector('.sidebar .profile .name');
  els.profileRole  = document.querySelector('.sidebar .profile .role');
  els.profileStatusDot = document.getElementById('profileStatusDot');
  els.navLinks     = Array.from(document.querySelectorAll('nav.menu a[data-page]'));
  els.gamesNavLink = document.querySelector('nav.menu a[data-page="games"]');
  els.bypassesNavLink = document.querySelector('nav.menu a[data-page="bypasses"]');
  els.logoutLink   = document.getElementById('navLogout');
  els.topbarH2     = document.querySelector('.topbar h2');
  els.searchInput  = document.querySelector('.search input');

  els.dashNewGrid    = document.getElementById('dashNewGrid');
  els.mktOnSaleSection = document.getElementById('mktOnSaleSection');
  els.mktOnSaleGrid    = document.getElementById('mktOnSaleGrid');
  els.gamesOnlyGrid  = document.getElementById('gamesOnlyGrid');
  els.bypassesGrid   = document.getElementById('bypassesGrid');
  els.historiListPage = document.getElementById('historiListPage');
  els.historiStats    = document.getElementById('historiStats');
  els.gamesRoleFilter = document.getElementById('gamesRoleFilter');
  els.bypassesRoleFilter = document.getElementById('bypassesRoleFilter');
  els.dashCategoryFilters = document.getElementById('dashCategoryFilters');

  els.tutorialLatestGrid  = document.getElementById('tutorialLatestGrid');
  els.tutorialGrid        = document.getElementById('tutorialGrid');
  els.tutorialCategoryFilter = document.getElementById('tutorialCategoryFilter');
  els.tutorialSearchInput = document.getElementById('tutorialSearchInput');
  els.tutorialDetailCategory = document.getElementById('tutorialDetailCategory');
  els.tutorialDetailTitle   = document.getElementById('tutorialDetailTitle');
  els.tutorialDetailImageWrap = document.getElementById('tutorialDetailImageWrap');
  els.tutorialDetailImage   = document.getElementById('tutorialDetailImage');
  els.tutorialDetailContent = document.getElementById('tutorialDetailContent');
  els.tutorialDetailVideoWrap = document.getElementById('tutorialDetailVideoWrap');
  els.tutorialDetailVideo   = document.getElementById('tutorialDetailVideo');
  els.tutorialPrevBtn = document.getElementById('tutorialPrevBtn');
  els.tutorialNextBtn = document.getElementById('tutorialNextBtn');
  els.tutorialDetailBackBtn = document.getElementById('tutorialDetailBackBtn');
}

// ── FILTER KATEGORI DI DASHBOARD ("New Games") ──
// Kategori diambil dari /api/categories (data asli database, admin bisa
// tambah/hapus kategori dari Kelola Game). Filter kerja 100% di sisi client
// terhadap data `allGames` yang sudah ada di memori — TIDAK fetch ulang ke
// server tiap kali kategori diganti, jadi instan & tetap ringan walau jumlah
// game ada ratusan/ribuan.
let allCategories = [];
let activeDashCategoryFilter = 'all';

async function loadCategories() {
  try {
    allCategories = await api('/api/categories');
    renderDashCategoryFilters();
  } catch (e) {
    // Diam-diam gagal — tombol "All Games" tetap ada, filter kategori lain cuma gak nongol
  }
}

function renderDashCategoryFilters() {
  if (!els.dashCategoryFilters) return;
  const chips = [{ slug: 'all', name: 'All Games' }, ...allCategories.map(c => ({ slug: c.slug, name: c.name }))];
  els.dashCategoryFilters.innerHTML = chips.map(c => `
    <span data-category="${escapeHtml(c.slug)}" class="${c.slug === activeDashCategoryFilter ? 'active' : ''}">${escapeHtml(c.name)}</span>
  `).join('');
}

function applyDashCategoryFilter(opts = {}) {
  if (!els.dashNewGrid) return;
  const q = els.searchInput ? els.searchInput.value.trim().toLowerCase() : '';
  let filtered = q ? allGames.filter(g => g.name.toLowerCase().includes(q)) : allGames;
  if (activeDashCategoryFilter !== 'all') {
    // `categories` (array, hasil Auto-Isi genre Steam) diprioritaskan; fallback ke
    // `category` tunggal buat data lama yang belum pernah di-Auto-Isi ulang.
    filtered = filtered.filter(g =>
      (Array.isArray(g.categories) && g.categories.length ? g.categories.includes(activeDashCategoryFilter) : g.category === activeDashCategoryFilter)
    );
  }
  renderDashGamesGrid(filtered, opts);
}

// Render grid "New Games" di Dashboard.
//
// BUG LAMA (penyebab kartu "kedap-kedip sendiri" di Dashboard): fungsi ini
// dipanggil otomatis tiap 60 detik oleh _autoRefreshTimer (juga tiap window
// difokuskan ulang & tiap ketik di search box) LEWAT applySearchAndFilters()
// -> applyDashCategoryFilter() -> di sini — dan dulu SELALU melakukan
// `innerHTML` penuh + force reflow + retrigger animasi fade, walau datanya
// PERSIS SAMA dengan yang sudah tampil. Itu artinya Dashboard berkedip ulang
// sendiri tiap 60 detik meskipun tidak ada perubahan data sama sekali.
//
// FIX: sekarang dicek dulu pakai signature — kalau data BENAR-BENAR SAMA
// dengan render terakhir, fungsi ini return lebih awal dan TIDAK menyentuh DOM
// sama sekali (nol flicker). Kalau memang berbeda, dipakai reconcileCardGrid
// (patch parsial, sama seperti grid Games/Bypass) alih-alih innerHTML penuh.
// Animasi fade-in cuma dipicu kalau `opts.animate` true — dipakai KHUSUS pas
// user manual klik chip kategori (lihat wireDashCategoryFilter), bukan pas
// polling diam-diam di belakang layar.
let _dashGridLastSig = null;

function renderDashGamesGrid(games, opts = {}) {
  if (!els.dashNewGrid) return;

  const sig = games.map(_cardItemSig).join(',');
  const alreadyRendered = els.dashNewGrid.querySelector('.game-card, .dash-empty-placeholder');
  if (!opts.force && sig === _dashGridLastSig && alreadyRendered) return; // data sama persis -> diamkan, jangan sentuh DOM
  _dashGridLastSig = sig;

  if (!games.length) {
    els.dashNewGrid.innerHTML = `
      <div class="dash-empty-placeholder">
        <div class="dash-empty-placeholder__icon"><svg class="icon icon-18"><use href="#ic-gamepad-2"></use></svg></div>
        <div class="dash-empty-placeholder__title">Belum ada game pada kategori ini.</div>
        <div class="dash-empty-placeholder__text">Coba pilih kategori lain atau cek lagi nanti.</div>
      </div>`;
    return;
  }

  reconcileCardGrid(
    els.dashNewGrid, games, renderGameCard,
    `<div class="dash-empty-placeholder"><div class="dash-empty-placeholder__icon"><svg class="icon icon-18"><use href="#ic-gamepad-2"></use></svg></div><div class="dash-empty-placeholder__title">Belum ada game pada kategori ini.</div></div>`
  );

  // Fade-in cuma buat aksi manual (klik kategori) — bukan buat polling diam-diam.
  if (opts.animate) {
    els.dashNewGrid.classList.remove('cards-fade-in');
    void els.dashNewGrid.offsetWidth; // force reflow biar animasi bisa di-retrigger
    els.dashNewGrid.classList.add('cards-fade-in');
  }
}

function wireDashCategoryFilter() {
  if (!els.dashCategoryFilters) return;
  wireCardGridClicks(els.dashNewGrid, () => allGames, 'game'); // delegated sekali, gantiin listener per-kartu per-render yang lama
  els.dashCategoryFilters.addEventListener('click', (e) => {
    const chip = e.target.closest('[data-category]');
    if (!chip) return;
    els.dashCategoryFilters.querySelectorAll('[data-category]').forEach(c => c.classList.remove('active'));
    chip.classList.add('active');
    activeDashCategoryFilter = chip.dataset.category;
    applyDashCategoryFilter({ animate: true }); // aksi manual -> boleh animasi
  });
}

// ── FILTER ROLE DI HALAMAN GAMES ──
let activeGamesRoleFilter = 'all';
// ── FILTER TYPE (Online/Offline) DI HALAMAN GAMES — kerja BARENGAN sama filter
// role & search yang sudah ada (bukan gantiin), dan dipertahankan selama masih
// di halaman ini (termasuk pas auto-refresh/realtime update data lewat WS).
let activeGamesTypeFilter = 'all'; // 'all' | 'online' | 'offline'

function applyGamesRoleFilter() {
  const q = els.searchInput ? els.searchInput.value.trim().toLowerCase() : '';
  let filtered = activeGamesRoleFilter === 'all'
    ? allGames
    : allGames.filter(g => g.role === activeGamesRoleFilter);
  if (q) filtered = filtered.filter(g => g.name.toLowerCase().includes(q));
  filtered = applyTypeFilter(filtered, activeGamesTypeFilter);
  renderGrid(els.gamesOnlyGrid, filtered);
  updateFilterResultCount('gamesResultCount', filtered.length, 'game');
}

function wireGamesRoleFilter() {
  wireCardGridClicks(els.gamesOnlyGrid, () => allGames, 'game');
  if (!els.gamesRoleFilter) return;
  els.gamesRoleFilter.addEventListener('click', (e) => {
    const btn = e.target.closest('.role-filter-tab');
    if (!btn) return;
    els.gamesRoleFilter.querySelectorAll('.role-filter-tab').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    activeGamesRoleFilter = btn.dataset.role;
    applyGamesRoleFilter();
  });
}

// Terapkan filter Type ('all'/'online'/'offline') ke sebuah list game/bypass —
// dipakai bareng di Games & Bypass biar logikanya konsisten di satu tempat.
// `isOnline` defaultnya TRUE kalau field-nya tidak diisi (konsisten dengan
// onlineBadgeHtml() & banner detail yang sudah ada — lihat baris ~778/978).
function applyTypeFilter(list, typeFilter) {
  if (typeFilter === 'online') return list.filter(x => x.isOnline !== false);
  if (typeFilter === 'offline') return list.filter(x => x.isOnline === false);
  return list;
}

// Update label "X game/bypass ditemukan" di sebelah filter Type — realtime
// mengikuti kombinasi search + role + type yang lagi aktif.
function updateFilterResultCount(elId, count, noun) {
  const el = document.getElementById(elId);
  if (!el) return;
  el.textContent = `${count} ${noun} ditemukan`;
}

function wireGamesTypeFilter() {
  const wrap = document.getElementById('gamesTypeFilter');
  if (!wrap) return;
  wrap.addEventListener('click', (e) => {
    const btn = e.target.closest('.role-filter-tab');
    if (!btn) return;
    wrap.querySelectorAll('.role-filter-tab').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    activeGamesTypeFilter = btn.dataset.type;
    applyGamesRoleFilter();
  });
}

// ── FILTER ROLE DI HALAMAN BYPASS ──
let activeBypassesRoleFilter = 'all';
// ── FILTER TYPE (Online/Offline) DI HALAMAN BYPASS — sama polanya kayak Games ──
let activeBypassesTypeFilter = 'all'; // 'all' | 'online' | 'offline'

function applyBypassesRoleFilter() {
  const q = els.searchInput ? els.searchInput.value.trim().toLowerCase() : '';
  let filtered = activeBypassesRoleFilter === 'all'
    ? allBypasses
    : allBypasses.filter(b => b.role === activeBypassesRoleFilter);
  if (q) filtered = filtered.filter(b => b.name.toLowerCase().includes(q));
  filtered = applyTypeFilter(filtered, activeBypassesTypeFilter);
  renderBypassGrid(els.bypassesGrid, filtered);
  updateFilterResultCount('bypassesResultCount', filtered.length, 'bypass');
}

function wireBypassesRoleFilter() {
  wireCardGridClicks(els.bypassesGrid, () => allBypasses, 'bypass');
  if (!els.bypassesRoleFilter) return;
  els.bypassesRoleFilter.addEventListener('click', (e) => {
    const btn = e.target.closest('.role-filter-tab');
    if (!btn) return;
    els.bypassesRoleFilter.querySelectorAll('.role-filter-tab').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    activeBypassesRoleFilter = btn.dataset.role;
    applyBypassesRoleFilter();
  });
}

function wireBypassesTypeFilter() {
  const wrap = document.getElementById('bypassesTypeFilter');
  if (!wrap) return;
  wrap.addEventListener('click', (e) => {
    const btn = e.target.closest('.role-filter-tab');
    if (!btn) return;
    wrap.querySelectorAll('.role-filter-tab').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    activeBypassesTypeFilter = btn.dataset.type;
    applyBypassesRoleFilter();
  });
}

// ── NAVIGASI ANTAR HALAMAN ──
const PAGE_IDS = {
  dashboard: 'pageDashboard',
  games: 'pageGames',
  bypasses: 'pageBypasses',
  store: 'pageStore',
  histori: 'pageHistori',
  voucher: 'pageVoucher',
  setting: 'pageSetting',
  gameDetail: 'pageGameDetail',
  tutorial: 'pageTutorial',
  tutorialDetail: 'pageTutorialDetail',
  transactions: 'pageTransactions',
  purchaseDetail: 'pagePurchaseDetail',
  requestgame: 'pageRequestgame',
  requestGameDetail: 'pageRequestGameDetail',
  steamaccounts: 'pageSteamaccounts',
  staDetail: 'pageSteamAccountDetail',
  staPurchaseDetail: 'pageStaPurchaseDetail',
  marketplaceDetail: 'pageMarketplaceDetail'
};

function showPage(pageName) {
  Object.values(PAGE_IDS).forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
  });
  const target = document.getElementById(PAGE_IDS[pageName]);
  if (target) target.style.display = '';

  els.navLinks.forEach(a => a.classList.toggle('active', a.dataset.page === pageName));

  if (pageName === 'games') applyGamesRoleFilter();
  if (pageName === 'bypasses') applyBypassesRoleFilter();
  if (pageName === 'histori') { loadHistori(); }
  if (pageName === 'tutorial') applyTutorialFilter();
  if (pageName === 'setting') { loadEditProfileForm(); loadSystemDetection(); refreshActiveToolsStatus(); refreshCloudFixStatus(); }
  if (pageName === 'store') loadPackages();
  if (pageName === 'transactions') loadTransactions();
  if (pageName === 'requestgame') initRequestGamePage();
  if (pageName === 'steamaccounts') loadSteamAccounts();
}

function wireNavigation() {
  els.navLinks.forEach(a => {
    a.addEventListener('click', (e) => {
      e.preventDefault();
      showPage(a.dataset.page);
    });
  });
  if (els.logoutLink) {
    els.logoutLink.addEventListener('click', (e) => {
      e.preventDefault();
      if (_autoRefreshTimer) clearInterval(_autoRefreshTimer);
      // Best-effort — catat event Logout ke audit trail (halaman Logs Admin Web).
      // Tidak menunggu response & tidak boleh menghambat proses logout kalau gagal.
      api('/api/logout', { method: 'POST' }).catch(() => {});
      localStorage.removeItem('token');
      localStorage.removeItem('_savedUser');
      location.reload();
    });
  }
}

// ── LOGIN OVERLAY (dibuat lewat JS, tema disamakan) ──
let loginStatusEl, pollTimer = null;

function showLogin(errorMsg = '') {
  if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
  if (!document.getElementById('nvLoginOverlay')) buildLoginOverlay();
  const overlay = document.getElementById('nvLoginOverlay');
  if (overlay) overlay.style.display = 'flex';
  if (els.app) els.app.style.display = 'none';
  if (errorMsg && loginStatusEl) {
    loginStatusEl.textContent = errorMsg;
    loginStatusEl.style.color = '#ff7eb3';
  }
}

function buildLoginOverlay() {
  const overlay = document.createElement('div');
  overlay.id = 'nvLoginOverlay';
  Object.assign(overlay.style, {
    position: 'fixed', inset: '0', zIndex: '9999',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    background: 'radial-gradient(circle at 15% 10%, #7a3fae 0%, transparent 45%),radial-gradient(circle at 90% 0%, #c4409a 0%, transparent 40%),radial-gradient(circle at 100% 100%, #4a2f8f 0%, transparent 45%),linear-gradient(135deg, #2b1c4e 0%, #3a2166 40%, #5c2a7a 70%, #7a3a8f 100%)',
    fontFamily: "'Manrope', sans-serif"
  });

  const card = document.createElement('div');
  Object.assign(card.style, {
    width: '360px', maxWidth: '90vw', padding: '38px 32px', textAlign: 'center',
    borderRadius: '22px', background: 'rgba(18,12,32,0.55)',
    border: '1px solid rgba(255,255,255,0.08)', backdropFilter: 'blur(30px)',
    boxShadow: '0 40px 80px rgba(10,5,25,0.45)'
  });

  // Cek apakah ada sesi tersimpan
  const savedToken  = localStorage.getItem('token');
  const savedUser   = _getSavedUser();
  const isReturning = !!(savedToken && savedUser);

  if (isReturning) {
    // ── RETURNING USER — tombol masuk langsung tanpa Discord ──
    card.innerHTML = `
      <img id="nvReturnAvatar" src="${escapeHtml(savedUser.avatarUrl || '')}"
        style="width:72px;height:72px;border-radius:50%;object-fit:cover;
               border:3px solid rgba(255,255,255,0.15);margin-bottom:14px;
               box-shadow:0 8px 24px rgba(0,0,0,0.4);"
        onerror="this.style.display='none'">
      <h2 style="font-family:'Poppins',sans-serif;color:#f3eefc;margin:0 0 4px;font-size:20px;">
        Selamat datang kembali!
      </h2>
      <p style="color:#a78bfa;font-size:14px;font-weight:700;margin:0 0 6px;">
        ${escapeHtml(savedUser.username || '')}
      </p>
      <p style="color:#b6a9d1;font-size:12px;margin:0 0 26px;line-height:1.5;">
        Tekan tombol di bawah untuk langsung masuk ke aplikasi.
      </p>
      <button id="nvBtnQuickLogin" style="width:100%;border:none;padding:14px;border-radius:12px;
        background:linear-gradient(90deg,#7c5cff,#a855f7);color:#fff;font-weight:700;font-size:14px;
        cursor:pointer;box-shadow:0 10px 25px rgba(124,92,255,0.45);
        display:flex;align-items:center;justify-content:center;gap:8px;margin-bottom:12px;">
        <svg class="icon icon-18"><use href="#ic-zap"></use></svg> Masuk Sekarang
      </button>
      <button id="nvBtnSwitchAccount" style="width:100%;border:1px solid rgba(255,255,255,0.12);
        padding:11px;border-radius:12px;background:transparent;color:#8f8ab0;
        font-size:12.5px;font-weight:600;cursor:pointer;">
        Ganti Akun (Login Discord)
      </button>
      <div id="nvLoginStatus" style="margin-top:14px;font-size:12px;color:#8f8ab0;min-height:16px;"></div>
    `;

    overlay.appendChild(card);
    document.body.appendChild(overlay);
    loginStatusEl = card.querySelector('#nvLoginStatus');

    // Tombol masuk langsung
    card.querySelector('#nvBtnQuickLogin').addEventListener('click', async () => {
      const btn = card.querySelector('#nvBtnQuickLogin');
      btn.disabled = true;
      btn.textContent = 'Memverifikasi...';
      if (loginStatusEl) { loginStatusEl.textContent = ''; }
      try {
        const user = await api('/api/me');

        const deviceCheck = await verifyDeviceLock();
        if (!deviceCheck.ok) {
          btn.disabled = false;
          btn.innerHTML = '<svg class="icon icon-16"><use href="#ic-zap"></use></svg> Masuk Sekarang';
          localStorage.removeItem('token');
          localStorage.removeItem('_savedUser');
          overlay.remove();
          _installModalEl = null;
          buildLoginOverlay();
          showLogin(deviceCheck.message);
          return;
        }

        hideLogin();
        enterApp(user);
        // NOTIF LOGIN: Quick Login = event login yang sah, jadi tetap pakai
        // sistem notification login existing (webhook kategori 'login' +
        // activity log) — lihat POST /api/quick-login-notify di server.js.
        // Best-effort & tidak menunggu (fire-and-forget): kalau gagal/telat,
        // Quick Login user TIDAK boleh ikut gagal/lambat karenanya.
        api('/api/quick-login-notify', { method: 'POST' }).catch(() => {});
      } catch (e) {
        btn.disabled = false;
        btn.innerHTML = '<svg class="icon icon-16"><use href="#ic-zap"></use></svg> Masuk Sekarang';
        // Bedakan error jaringan (server offline/tidak bisa dihubungi) dari token yang
        // BENAR-BENAR tidak valid. Kalau cuma masalah jaringan, jangan hapus sesi —
        // biarkan user coba lagi begitu koneksi/server sudah normal.
        const isNetworkError = /fetch|network/i.test(e.message || '');
        if (isNetworkError) {
          if (loginStatusEl) {
            loginStatusEl.textContent = 'Server tidak bisa dihubungi. Cek koneksi internet lalu coba lagi.';
            loginStatusEl.style.color = '#ff7eb3';
          }
          return;
        }
        // Token benar-benar tidak valid/akun tidak ditemukan → wajib login Discord ulang
        localStorage.removeItem('token');
        localStorage.removeItem('_savedUser');
        overlay.remove();
        _installModalEl = null;
        buildLoginOverlay();
        showLogin('Sesi kamu sudah berakhir, login ulang dengan Discord.');
      }
    });

    // Tombol ganti akun
    card.querySelector('#nvBtnSwitchAccount').addEventListener('click', () => {
      localStorage.removeItem('token');
      localStorage.removeItem('_savedUser');
      overlay.remove();
      buildLoginOverlay();
    });

  } else {
    // ── FRESH LOGIN — tombol Discord ──
    card.innerHTML = `
      <div style="font-size:42px;margin-bottom:10px;"><svg class="icon icon-18"><use href="#ic-gamepad-2"></use></svg></div>
      <h2 id="nvLoginAppName" style="font-family:'Poppins',sans-serif;color:#f3eefc;margin:0 0 8px;font-size:20px;">31 Tools</h2>
      <p style="color:#b6a9d1;font-size:13px;line-height:1.6;margin:0 0 24px;">
        Login pakai Discord untuk masuk. Akun kamu akan otomatis terdeteksi
        setelah verifikasi berhasil.
      </p>
      <button id="nvBtnLoginDiscord" style="width:100%;border:none;padding:13px;border-radius:12px;
        background:linear-gradient(90deg,#5865F2,#7c5cff);color:#fff;font-weight:700;font-size:14px;
        cursor:pointer;box-shadow:0 10px 25px rgba(92,102,255,0.4);display:flex;align-items:center;
        justify-content:center;gap:8px;">
        <svg class="icon icon-18"><use href="#ic-message-circle"></use></svg> Login dengan Discord
      </button>
      <div id="nvLoginStatus" style="margin-top:16px;font-size:12.5px;color:#8f8ab0;min-height:16px;"></div>
    `;

    overlay.appendChild(card);
    document.body.appendChild(overlay);
    loginStatusEl = card.querySelector('#nvLoginStatus');
    card.querySelector('#nvBtnLoginDiscord').addEventListener('click', startLogin);
  }

  return overlay;
}

// Simpan & ambil data user dari localStorage supaya nama+avatar bisa ditampilkan di login
function _getSavedUser() {
  try { return JSON.parse(localStorage.getItem('_savedUser') || 'null'); } catch(e) { return null; }
}
function _saveUser(user) {
  try { localStorage.setItem('_savedUser', JSON.stringify({ username: user.username, avatarUrl: user.avatarUrl, role: user.role })); } catch(e) {}
}

function hideLogin() {
  const overlay = document.getElementById('nvLoginOverlay');
  if (overlay) overlay.style.display = 'none';
  if (els.app) els.app.style.display = '';
  if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
  // Steam & Discord Detection — load di background begitu app kebuka, jadi data
  // sudah siap kalau user buka halaman Setting (tidak perlu nunggu loading).
  loadSystemDetection();
  refreshActiveToolsStatus();
  refreshCloudFixStatus();
  // Automatic Watermark Detection — scan folder Game/Bypass lokal di background,
  // ditunda beberapa detik supaya BENAR-BENAR tidak ikut membebani proses startup
  // (dashboard/daftar game/dll dimuat duluan). Hasil scan cuma menghasilkan LOG &
  // notifikasi realtime ke Admin Web — tidak pernah mempengaruhi apapun di App user.
  setTimeout(() => { runWatermarkScan().catch(() => {}); }, 4000);
}

// ── AUTOMATIC WATERMARK DETECTION — scan startup ──
// Baca watermark yang ditemukan launcher di folder Game (config/depotcache Steam)
// & folder Bypass yang PERNAH dipasangi (dari localStorage installMeta kita
// sendiri), lalu kirim ke server buat dicocokkan. Server yang memutuskan
// "perangkat sama/beda" — di sini CUMA kumpul & kirim data.
async function runWatermarkScan() {
  if (!window.electronAPI?.scanWatermarks) return; // build lama / platform non-Electron
  try {
    const steamPath = await window.electronAPI.getSteamPath().catch(() => null);
    const meta = getLocalInstallMeta();
    const bypassFolders = Object.values(meta)
      .filter(m => m?.type === 'bypass' && m?.folderPath)
      .map(m => m.folderPath);

    const scanResult = await window.electronAPI.scanWatermarks({ steamPath, bypassFolders: [...new Set(bypassFolders)] });
    if (!scanResult?.success || !scanResult.items?.length) return;

    const deviceInfo = await window.electronAPI.getDeviceInfo().catch(() => ({}));
    await api('/api/watermark/scan', { method: 'POST', body: JSON.stringify({ deviceInfo, items: scanResult.items }) });
  } catch (e) {
    // Diamkan — scan watermark TIDAK PERNAH boleh menampilkan error ke user,
    // ini murni proses background utk keperluan admin.
  }
}

// ── DEVICE LOCK — dipanggil SEKALI tiap sesi login (baru atau "Masuk Sekarang"),
// SEBELUM masuk dashboard. Kumpulkan info hardware lewat main process (IPC), lalu
// minta server cocokkan dengan perangkat yang terikat ke akun ini. Kalau server
// tidak bisa dihubungi sama sekali (jaringan), fail-open (jangan blokir user gara-gara
// koneksi) — tapi kalau server BALIKIN penolakan eksplisit (403 device beda), blokir.
async function verifyDeviceLock() {
  try {
    const info = (window.electronAPI?.getDeviceInfo) ? await window.electronAPI.getDeviceInfo() : {};
    await api('/api/device/verify', { method: 'POST', body: JSON.stringify(info || {}) });
    return { ok: true };
  } catch (e) {
    const isNetworkError = /fetch|network/i.test(e.message || '');
    if (isNetworkError) return { ok: true };
    return { ok: false, message: e.message || 'Perangkat ini tidak diizinkan mengakses akun ini.' };
  }
}

function startLogin() {
  const deviceId = getOrCreateDeviceId();
  const openExternal = window.electronAPI?.openExternal || (url => window.open(url, '_blank'));
  openExternal(`${SERVER_URL}/auth/discord?state=${encodeURIComponent(deviceId)}`);

  const discordBtn = document.getElementById('nvBtnLoginDiscord');
  if (discordBtn) { discordBtn.disabled = true; discordBtn.innerHTML = '<svg class="icon icon-16"><use href="#ic-loader-circle"></use></svg> Menunggu login di browser...'; }

  if (loginStatusEl) {
    loginStatusEl.innerHTML = 'Selesaikan login di jendela browser yang baru terbuka. <a href="#" id="nvCancelLogin" style="color:#a78bfa;text-decoration:underline;">Batal</a>';
    loginStatusEl.style.color = '#8f8ab0';
    const cancelLink = loginStatusEl.querySelector('#nvCancelLogin');
    if (cancelLink) cancelLink.addEventListener('click', (e) => { e.preventDefault(); resetLoginButton('Dibatalkan. Silakan coba lagi.'); });
  }

  if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }

  // Timeout — kalau setelah 5 menit belum juga berhasil (misal tab browser
  // ditutup tanpa menyelesaikan login, atau lupa/gagal join Discord), berhenti
  // polling dan kembalikan tombol ke keadaan semula supaya user bisa coba lagi,
  // daripada polling diam-diam tanpa batas waktu selamanya.
  const POLL_TIMEOUT_MS = 5 * 60 * 1000;
  const pollStartedAt = Date.now();

  pollTimer = setInterval(async () => {
    if (Date.now() - pollStartedAt > POLL_TIMEOUT_MS) {
      resetLoginButton('Waktu login habis. Silakan coba lagi.');
      return;
    }
    try {
      const res = await fetch(`${SERVER_URL}/auth/poll?state=${encodeURIComponent(deviceId)}`);
      const data = await res.json();
      if (data.ready) {
        clearInterval(pollTimer);
        pollTimer = null;
        localStorage.setItem('token', data.token);

        const deviceCheck = await verifyDeviceLock();
        if (!deviceCheck.ok) {
          localStorage.removeItem('token');
          localStorage.removeItem('_savedUser');
          resetLoginButton(deviceCheck.message);
          return;
        }

        hideLogin();
        enterApp(data.user);
      }
    } catch (e) {}
  }, 2000);
}

// Kembalikan tombol "Login dengan Discord" ke keadaan semula (dipakai saat dibatalkan/timeout)
function resetLoginButton(message) {
  if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
  const discordBtn = document.getElementById('nvBtnLoginDiscord');
  if (discordBtn) { discordBtn.disabled = false; discordBtn.innerHTML = '<svg class="icon icon-16"><use href="#ic-message-circle"></use></svg> Login dengan Discord'; }
  if (loginStatusEl) {
    loginStatusEl.textContent = message || '';
    loginStatusEl.style.color = '#ff7eb3';
  }
}

async function tryAutoLogin() {
  // PENTING: jangan pernah auto-masuk ke dashboard di sini. App harus SELALU mendarat
  // di halaman login dulu setiap kali dibuka (termasuk setelah ditutup lalu dibuka lagi).
  // Kalau ada sesi tersimpan (token + _savedUser di localStorage), buildLoginOverlay()
  // akan otomatis menampilkan cabang "Selamat datang kembali" dengan tombol
  // "⚡ Masuk Sekarang" — user tinggal 1x klik TANPA perlu login Discord ulang.
  // Verifikasi token yang sebenarnya (valid/expired/akun masih ada) baru dilakukan
  // server-side saat tombol itu ditekan (lewat /api/me), bukan otomatis di sini.
  showLogin();
}

// ── MASUK APP ──
let currentUser = null;
let allGames = [];
let allBypasses = [];

const PROFILE_ROLE_LABEL = { public: 'Public', gold: 'Gold', platinum: 'Platinum', admin: 'Admin' };
const PROFILE_ROLE_ICON = { public: 'ic-globe', gold: 'ic-trophy', platinum: 'ic-gem', admin: 'ic-crown' };
function setProfileRole(role) {
  if (!els.profileRole) return;
  const r = role || 'public';
  const icon = PROFILE_ROLE_ICON[r] || 'ic-globe';
  els.profileRole.innerHTML = `<span class="role-ic"><svg class="icon icon-12"><use href="#${icon}"></use></svg></span><span class="role-txt">${PROFILE_ROLE_LABEL[r] || r}</span>`;
  els.profileRole.className = `role role-${r}`;
}

// Titik status kecil di avatar sidebar — mengikuti status koneksi realtime
// (hijau = terhubung/online, abu-abu = terputus/reconnecting).
function setProfileOnlineStatus(isOnline) {
  if (!els.profileStatusDot) return;
  els.profileStatusDot.classList.toggle('is-online', !!isOnline);
  els.profileStatusDot.classList.toggle('is-offline', !isOnline);
  els.profileStatusDot.title = isOnline ? 'Online' : 'Offline';
}

function enterApp(user) {
  currentUser = user;
  _saveUser(user); // simpan untuk halaman "Selamat datang kembali"
  // Cek ulang status Maintenance sekarang SETELAH login berhasil — sebelumnya
  // (saat app baru dibuka) mungkin belum ada token tersimpan sama sekali,
  // jadi bypass belum bisa dihitung dengan benar untuk admin/whitelist.
  checkMaintenanceMode();

  if (els.profileImg) els.profileImg.src = user.avatarUrl;
  if (els.profileName) {
    els.profileName.textContent = user.username;
    els.profileName.title = user.username;
  }
  setProfileRole(user.role);
  setProfileOnlineStatus(false);

  if (els.topbarH2) els.topbarH2.textContent = `Have a good time ${user.username}!`;

  renderPackageCard(user);
  connectRealtime();
  loadNotifications();
  // Popup Welcome (sekali per AKUN, bukan cuma per sesi) — lihat
  // checkWelcomePopup() di bawah. Dipanggil PALING DULU sebelum Gold Trial
  // supaya kalau dua-duanya eligible, Welcome Popup muncul lebih dulu.
  checkWelcomePopup();

  // Popup Gold Trial (sekali per sesi login) — lihat checkGoldTrialOffer() di
  // bawah. Sengaja dipanggil DI SINI (sekali sesudah login berhasil), BUKAN di
  // handleAccountUpdate() yang jalan berkali-kali tiap ada perubahan realtime.
  checkGoldTrialOffer();

  showPage('dashboard'); // halaman utama selalu yang pertama muncul
  loadCategories();
  loadGames();
  loadBypasses();
  loadBanners();
  loadSteamAccounts();
  loadMarketplaceProducts();
  loadLeaderboard();
  loadTutorials();
  flushPendingHistory().catch(() => {}); // coba kirim ulang histori yang sempat gagal tersimpan sesi sebelumnya
  startAutoRefresh(); // <svg class="icon icon-16"><use href="#ic-arrow-left"></use></svg> polling berkala supaya game/bypass baru dari admin langsung muncul
  checkPendingPremiumCleanups(); // <svg class="icon icon-16"><use href="#ic-arrow-left"></use></svg> "kalau app tidak dibuka, pengecekan dilakukan saat app dibuka kembali"
}

// ── AUTO REFRESH — game/bypass baru dari admin sekarang muncul REALTIME lewat
// WebSocket ('games:update' / 'bypasses:update', lihat connectRealtime()) begitu
// admin simpan perubahan — jadi polling di sini cuma JARING PENGAMAN kalau koneksi
// WebSocket sempat putus, makanya interval-nya dilonggarkan (dulu 15 detik, bikin
// grid "berkedip" render ulang terus walau datanya sama — sekarang lebih jarang,
// dan render ulang sungguhan cuma terjadi kalau datanya BENERAN beda, lihat
// applyGamesUpdate()/applyBypassesUpdate()).
let _autoRefreshTimer  = null;
let _roleCheckTimer    = null; // polling cepat KHUSUS untuk deteksi perubahan role
let _autoRefreshFocusWired = false; // guard supaya listener 'focus' cuma dipasang sekali per sesi app

function startAutoRefresh() {
  if (_autoRefreshTimer) clearInterval(_autoRefreshTimer);
  if (_roleCheckTimer)   clearInterval(_roleCheckTimer);

  // Poll ringan setiap 3 detik KHUSUS untuk cek role — endpoint /api/me/role-check
  // hanya return { role, roleUpdatedAt } sehingga overhead-nya sangat kecil.
  // Kalau terdeteksi berubah, baru load ulang data lengkap via /api/me.
  _roleCheckTimer = setInterval(async () => {
    if (!currentUser) return;
    await _checkRoleRealtime();
  }, 3000);

  // Jaring pengaman kalau WebSocket putus — 60 detik cukup karena update
  // sungguhan sudah didorong realtime, ini cuma buat jaga-jaga.
  _autoRefreshTimer = setInterval(async () => {
    if (!currentUser) return;
    await loadGames();
    await loadBypasses();
    applySearchAndFilters();
  }, 60000);

  // Refresh instan begitu app kembali difokuskan (alt-tab balik ke app) — listener
  // dipasang SEKALI SAJA (guard _autoRefreshFocusWired) supaya tidak menumpuk kalau
  // startAutoRefresh() sempat terpanggil lebih dari sekali dalam satu sesi app.
  if (!_autoRefreshFocusWired) {
    _autoRefreshFocusWired = true;
    window.addEventListener('focus', async () => {
      if (!currentUser) return;
      await _checkRoleRealtime();
      await loadGames();
      await loadBypasses();
      applySearchAndFilters();
    });
  }
}

// ── Polling cepat role: pakai /api/me/role-check (ringan), baru hit /api/me lengkap
// kalau terdeteksi role atau roleUpdatedAt berubah.
let _lastKnownRoleUpdatedAt = null;
async function _checkRoleRealtime() {
  try {
    const check = await api('/api/me/role-check');
    const updatedAtChanged = check.roleUpdatedAt && check.roleUpdatedAt !== _lastKnownRoleUpdatedAt;
    const roleChanged = check.role && currentUser && check.role !== currentUser.role;

    if (!roleChanged && !updatedAtChanged) {
      return; // tidak ada perubahan, selesai
    }

    _lastKnownRoleUpdatedAt = check.roleUpdatedAt;
    await refreshCurrentUserRole(); // load data lengkap + tampilkan toast
  } catch (e) {} // jangan ganggu app kalau network sesaat terganggu
}

// ── Cek apakah role user berubah (misal admin "set paket" baru, atau role
// Discord user disinkron otomatis ke app) → update tampilan + kasih toast.
// Dipanggil berkala dari startAutoRefresh(), BUKAN endpoint baru — cukup numpang
// lewat /api/me yang memang sudah dipanggil tiap login, sekarang dipanggil ulang
// secara berkala juga supaya perubahan dari luar (admin panel / Discord) kelihatan
// tanpa user perlu logout-login manual.
async function refreshCurrentUserRole() {
  try {
    const fresh = await api('/api/me');
    if (!currentUser || !fresh || fresh.role === currentUser.role) {
      if (fresh) currentUser = { ...currentUser, ...fresh };
      return;
    }

    const oldRole = currentUser.role;
    currentUser = { ...currentUser, ...fresh };
    _saveUser(currentUser);

    setProfileRole(currentUser.role);
    showRoleUpdateToast(oldRole, currentUser.role);

    // Role berubah bisa berarti akses ke game/bypass tertentu ikut berubah (naik/turun paket)
    await loadGames();
    await loadBypasses();
    applySearchAndFilters();
  } catch (e) {} // jangan ganggu app kalau cuma gagal cek role sekali (misal lagi no-internet sebentar)
}

const ROLE_BADGE_ICON = { public: '<svg class="icon icon-16"><use href="#ic-globe"></use></svg>', gold: '<svg class="icon icon-16"><use href="#ic-trophy"></use></svg>', platinum: '<svg class="icon icon-16"><use href="#ic-gem"></use></svg>', admin: '<svg class="icon icon-16"><use href="#ic-crown"></use></svg>' };
function roleBadgeHtml(role) {
  const icon = ROLE_BADGE_ICON[role] || '<svg class="icon icon-16"><use href="#ic-globe"></use></svg>';
  return `<span class="role-pill ${role}"><span class="rp-icon">${icon}</span>${escapeHtml(role)}</span>`;
}

// Badge Online/Offline di pojok kanan-atas kartu game/bypass — dari field isOnline
// yang diatur admin (default online kalau field-nya belum pernah di-set sama sekali).
function onlineBadgeHtml(isOnline) {
  const online = isOnline !== false;
  return `<span class="online-pill ${online ? 'online' : 'offline'}">
    <span class="op-dot"></span>${online ? 'Online Mode' : 'Offline Mode'}
  </span>`;
}

// ── Cek apakah role user cukup buat akses item ini ──
// Server sudah menghitung akses ini lewat hasCatalogAccess() (hierarki
// public < gold < platinum < admin) — field `hasAccess` di /api/games &
// /api/bypasses dipakai kalau tersedia, fallback hitung ulang di sini.
const CLIENT_ROLE_LEVEL = { public: 0, gold: 1, platinum: 2, admin: 3 };
function hasAccess(item) {
  if (currentUser?.role === 'admin') return true;
  const myLevel   = CLIENT_ROLE_LEVEL[currentUser?.role] ?? 0;
  const itemLevel = CLIENT_ROLE_LEVEL[item.role] ?? 0;
  return myLevel >= itemLevel;
}

// ── Cari Bypass yang berkaitan dengan Game ini (buat tombol "Install Bypass" kedua) ──
// Prioritas: bypass yang gameId-nya cocok (dibuat via "Sekalian jadi Bypass" di admin),
// fallback: bypass yang App ID Steam-nya sama persis dengan game ini.
function findLinkedBypass(gameItem) {
  const gid = String(gameItem._id);
  let match = allBypasses.find(b => b.gameId && String(b.gameId) === gid);
  if (!match && gameItem.appId) {
    match = allBypasses.find(b => b.appId && String(b.appId) === String(gameItem.appId));
  }
  return match || null;
}

// ── HALAMAN DETAIL GAME/BYPASS ──
// Dibuka saat kartu game/bypass diklik. Data dasar (nama, role, deskripsi, cover)
// langsung ditampilkan dari data yang sudah ada, lalu detail LENGKAP & ASLI
// (release date, metacritic, developer, publisher, tag, system requirements)
// di-fetch dari Steam Store API (lewat proxy server) berdasarkan App ID game itu —
// BUKAN data fiksi/hardcode.
let _prevPageBeforeDetail = 'dashboard';
let _detailFetchToken = 0; // biar response fetch yang telat/kebalap gak nimpa detail yang lagi dibuka
let _currentDetailItem = null;     // item yang lagi dibuka di halaman detail — dipakai buat refresh tombol Install realtime kalau role user berubah SELAGI halaman ini terbuka
let _currentDetailItemType = null;

// Nama paket buat ditampilkan ke user (dipakai popup Akses Dibutuhkan & label tombol).
const ROLE_DISPLAY_NAME = { public: 'Public', gold: 'Gold', platinum: 'Platinum', admin: 'Admin' };

// ── Tombol Install (utama & bypass terkait) di halaman detail — SELALU bisa
// diklik, baik item-nya kekunci atau tidak. Kalau kekunci, klik-nya membuka
// popup "Akses Dibutuhkan" (bukan cuma tombol mati/disabled) sesuai spesifikasi:
// game/bypass tetap kelihatan & bisa dibuka normal, cuma proses install yang
// dicegat. Dipisah jadi fungsi sendiri supaya bisa dipanggil ulang kalau role
// user berubah REALTIME selagi halaman detail ini masih terbuka (lihat
// handleAccountUpdate) — tanpa perlu buka ulang halaman detailnya.
// Item yang di-gate Marketplace (marketplaceProductIds.length > 0) TIDAK
// memakai hierarki role/paket sama sekali — akses satu-satunya sumber
// kebenarannya adalah `item.hasAccess` dari server (purchase/whitelist),
// lihat catatan di marketplaceManager.js. Item biasa tetap pakai hasAccess()
// client (hierarki role) seperti sebelumnya.
function isMktGated(item) {
  return Array.isArray(item?.marketplaceProductIds) && item.marketplaceProductIds.length > 0;
}
function mktOrRoleLocked(item) {
  return isMktGated(item) ? !item.hasAccess : !hasAccess(item);
}

function applyDetailAccessState(item, itemType) {
  const locked = mktOrRoleLocked(item);
  const gated = isMktGated(item);
  const installBtn = document.getElementById('detailInstallBtn');
  installBtn.disabled = false; // SELALU aktif — locked pun tetap bisa diklik buat munculin popup
  if (locked && gated) {
    // §4.8 — card/tombol Game/Bypass yang terkunci karena Marketplace (BUKAN
    // karena kurang paket) tampil sebagai "Tidak Ada Akses" + buka modal
    // "Lihat Product", bukan popup upgrade paket.
    installBtn.className = 'detail-install-btn locked mkt-locked';
    installBtn.innerHTML = `<svg class="icon icon-16"><use href="#ic-lock"></use></svg> Tidak ada akses - Klik disini untuk beli`;
    installBtn.onclick = () => openMktLockedModal(item);
  } else if (locked) {
    installBtn.className = 'detail-install-btn locked';
    installBtn.innerHTML = `<svg class="icon icon-16"><use href="#ic-lock"></use></svg> Butuh Paket ${ROLE_DISPLAY_NAME[item.role] || item.role}`;
    installBtn.onclick = () => openAccessRequiredModal(item);
  } else {
    installBtn.className = 'detail-install-btn';
    installBtn.innerHTML = itemType === 'game' ? '<svg class="icon icon-16"><use href="#ic-zap"></use></svg> Install Game' : '<svg class="icon icon-16"><use href="#ic-shield-check"></use></svg> Aktifkan Bypass';
    installBtn.onclick = () => handleInstall(itemType, item._id, item.name);
  }

  // ── Tombol "Install Bypass" kedua — cuma muncul di halaman detail GAME,
  // dan cuma kalau memang ada Bypass yang terhubung ke game ini ──
  const bypassBtn = document.getElementById('detailInstallBypassBtn');
  const linkedBypass = itemType === 'game' ? findLinkedBypass(item) : null;
  if (linkedBypass) {
    bypassBtn.style.display = '';
    bypassBtn.disabled = false;
    const bypassLocked = mktOrRoleLocked(linkedBypass);
    const bypassGated = isMktGated(linkedBypass);
    if (bypassLocked && bypassGated) {
      bypassBtn.className = 'detail-install-bypass-btn locked mkt-locked';
      bypassBtn.innerHTML = `<svg class="icon icon-16"><use href="#ic-lock"></use></svg> Tidak ada akses - Klik disini untuk beli`;
      bypassBtn.onclick = () => openMktLockedModal(linkedBypass);
    } else if (bypassLocked) {
      bypassBtn.className = 'detail-install-bypass-btn locked';
      bypassBtn.innerHTML = `<svg class="icon icon-16"><use href="#ic-lock"></use></svg> Bypass Butuh Paket ${ROLE_DISPLAY_NAME[linkedBypass.role] || linkedBypass.role}`;
      bypassBtn.onclick = () => openAccessRequiredModal(linkedBypass);
    } else {
      bypassBtn.className = 'detail-install-bypass-btn';
      bypassBtn.innerHTML = '<svg class="icon icon-16"><use href="#ic-shield-check"></use></svg> Install Bypass';
      bypassBtn.onclick = () => handleInstall('bypass', linkedBypass._id, linkedBypass.name);
    }
  } else {
    bypassBtn.style.display = 'none';
  }
}

// ── POPUP: Akses Dibutuhkan ──
function openAccessRequiredModal(item) {
  const currentRole = currentUser?.role || 'public';
  document.getElementById('accessRequiredText').textContent =
    `Paket kamu saat ini (${ROLE_DISPLAY_NAME[currentRole] || currentRole}) tidak memiliki akses ke "${item.name}".`;
  document.getElementById('accessRequiredBadgeSlot').innerHTML = roleBadgeHtml(item.role);
  document.getElementById('accessRequiredBackdrop').style.display = 'flex';
}
function closeAccessRequiredModal() {
  document.getElementById('accessRequiredBackdrop').style.display = 'none';
}
window.closeAccessRequiredModal = closeAccessRequiredModal;
document.getElementById('accessRequiredUpgradeBtn')?.addEventListener('click', () => {
  closeAccessRequiredModal();
  showPage('store'); // halaman "Upgrade Paket"
});

function openDetailPage(item, itemType) {
  const activeLink = els.navLinks.find(a => a.classList.contains('active'));
  _prevPageBeforeDetail = activeLink ? activeLink.dataset.page : 'dashboard';
  const myFetchToken = ++_detailFetchToken;
  _currentDetailItem = item;
  _currentDetailItemType = itemType;

  // ── Isi cepat pakai data yang sudah ada (tanpa nunggu network) ──
  const coverEl = document.getElementById('detailCover');
  if (item.imageUrl) {
    coverEl.style.backgroundImage = `url('${item.imageUrl}')`;
    coverEl.className = 'detail-cover';
  } else {
    coverEl.style.backgroundImage = '';
    coverEl.className = 'detail-cover ' + artClassForId(item._id || item.name || '');
  }

  document.getElementById('detailTitle').textContent = item.name || '—';
  document.getElementById('detailDescription').textContent =
    item.description?.trim() || 'Memuat deskripsi dari Steam...';

  const steamIdRow = document.getElementById('detailSteamId');
  if (item.appId) {
    steamIdRow.style.display = 'block';
    document.getElementById('detailSteamIdVal').textContent = item.appId;
  } else {
    steamIdRow.style.display = 'none';
  }

  // Info grid — skeleton dulu sambil nunggu data Steam asli
  const setInfoBox = (id, val, isSkel) => {
    const el = document.getElementById(id);
    el.textContent = val;
    el.classList.toggle('detail-skel', !!isSkel);
  };
  const hasAppId = !!item.appId;
  setInfoBox('dibRelease', hasAppId ? '' : '—', hasAppId);
  setInfoBox('dibMetacritic', hasAppId ? '' : '—', hasAppId);
  setInfoBox('dibDeveloper', hasAppId ? '' : '—', hasAppId);
  setInfoBox('dibPublisher', hasAppId ? '' : '—', hasAppId);

  document.getElementById('detailTags').innerHTML =
    `<span class="detail-tag plain">${itemType === 'game' ? '<svg class="icon icon-16"><use href="#ic-gamepad-2"></use></svg> Game' : '<svg class="icon icon-16"><use href="#ic-shield-check"></use></svg> Bypass'}</span>` +
    (item.sizeLabel ? `<span class="detail-tag plain"><svg class="icon icon-18"><use href="#ic-save"></use></svg> ${escapeHtml(item.sizeLabel)}</span>` : '');

  renderOnlineBanner(item, itemType);

  document.getElementById('detailReqsWrap').style.display = 'none';

  applyDetailAccessState(item, itemType);

  showPage('gameDetail');
  const mainEl = document.querySelector('.main');
  if (mainEl) mainEl.scrollTop = 0;

  // ── Ambil detail ASLI dari Steam (App ID) lewat server, lalu lengkapi tampilan ──
  if (item.appId) {
    const endpoint = itemType === 'game' ? `/api/games/${item._id}/steam-details` : `/api/bypasses/${item._id}/steam-details`;
    api(endpoint)
      .then(d => {
        if (myFetchToken !== _detailFetchToken) return; // user udah pindah ke item lain, buang hasil ini
        applySteamDetails(d, item, itemType);
      })
      .catch(() => {
        if (myFetchToken !== _detailFetchToken) return;
        setInfoBox('dibRelease', '—', false);
        setInfoBox('dibMetacritic', '—', false);
        setInfoBox('dibDeveloper', '—', false);
        setInfoBox('dibPublisher', '—', false);
      });
  }
}
window.openDetailPage = openDetailPage;

// ── Banner "Online Multiplayer" / "Single Player" di halaman detail ──
// Beberapa varian teks online biar gak monoton kalau dibuka bolak-balik — dipilih
// konsisten per item (pakai hash nama/ID-nya), bukan acak tiap render.
const ONLINE_BANNER_COPIES = [
  {
    title: 'Bisa Dimainkan Online Multiplayer',
    text: 'Game ini mendukung mode online — ajak teman satu squad atau ketemu pemain baru dari seluruh dunia, dan rasakan serunya main bareng secara real-time, bukan cuma sendirian.'
  },
  {
    title: 'Online Multiplayer Ready',
    text: 'Nggak cuma seru dimainkan sendiri — game ini siap dimainkan online bareng teman. Gaskeun mabar, koordinasi strategi, dan taklukkan tantangannya bareng-bareng.'
  },
  {
    title: 'Mendukung Mode Online',
    text: 'Koneksikan diri kamu ke server online dan mainkan bareng pemain lain kapan saja. Cocok buat kamu yang suka kompetisi seru atau kerja sama tim secara real-time.'
  }
];
const OFFLINE_BANNER_COPY = {
  title: 'Single Player / Offline',
  text: 'Game ini didesain untuk dimainkan sendirian tanpa perlu koneksi online — cocok buat kamu yang mau fokus menikmati cerita dan gameplay-nya dengan tenang, kapan saja.'
};

function renderOnlineBanner(item, itemType) {
  const banner = document.getElementById('detailOnlineBanner');
  if (!banner) return;
  const isOnline = item.isOnline !== false;

  banner.style.display = 'flex';
  banner.className = 'detail-online-banner ' + (isOnline ? 'is-online' : 'is-offline');

  let copy;
  if (isOnline) {
    let hash = 0;
    const seed = String(item._id || item.name || '');
    for (let i = 0; i < seed.length; i++) hash = (hash * 31 + seed.charCodeAt(i)) >>> 0;
    copy = ONLINE_BANNER_COPIES[hash % ONLINE_BANNER_COPIES.length];
  } else {
    copy = OFFLINE_BANNER_COPY;
  }

  document.getElementById('detailOnlineBannerIcon').innerHTML = isOnline
    ? '<svg class="icon icon-24"><use href="#ic-globe"></use></svg>'
    : '<svg class="icon icon-24"><use href="#ic-power-off"></use></svg>';
  document.getElementById('detailOnlineBannerTitle').textContent = copy.title;
  document.getElementById('detailOnlineBannerText').textContent = copy.text;
}

function applySteamDetails(d, item, itemType) {
  if (d.headerImage) {
    const coverEl = document.getElementById('detailCover');
    coverEl.style.backgroundImage = `url('${d.headerImage}')`;
    coverEl.className = 'detail-cover';
  }

  if (d.shortDescription) document.getElementById('detailDescription').textContent = d.shortDescription;

  const setInfoBox = (id, val) => {
    const el = document.getElementById(id);
    el.textContent = val;
    el.classList.remove('detail-skel');
  };
  setInfoBox('dibRelease', d.releaseDate || (d.comingSoon ? 'Coming Soon' : 'Tidak diketahui'));
  setInfoBox('dibMetacritic', d.metacritic != null ? `${d.metacritic} (Meta)` : 'Tidak ada skor');
  setInfoBox('dibDeveloper', d.developers?.length ? d.developers.join(', ') : 'Tidak diketahui');
  setInfoBox('dibPublisher', d.publishers?.length ? d.publishers.join(', ') : 'Tidak diketahui');

  const tagsHtml = [
    `<span class="detail-tag plain">${itemType === 'bypass' ? '<svg class="icon icon-16"><use href="#ic-shield-check"></use></svg> Bypass' : '<svg class="icon icon-16"><use href="#ic-gamepad-2"></use></svg> Game'}</span>`,
    ...(d.categories || []).map(c => `<span class="detail-tag">${escapeHtml(c)}</span>`),
    ...(d.genres || []).map(g => `<span class="detail-tag plain">${escapeHtml(g)}</span>`)
  ].join('');
  document.getElementById('detailTags').innerHTML = tagsHtml;

  const reqsWrap = document.getElementById('detailReqsWrap');
  const hasReqs = (d.requirementsMin?.length || d.requirementsRec?.length);
  if (hasReqs) {
    reqsWrap.style.display = 'block';
    const renderReqs = list => list.map(r =>
      `<div class="drb-row">${r.label ? `<b>${escapeHtml(r.label)}:</b> ` : ''}${escapeHtml(r.value)}</div>`
    ).join('') || '<div class="drb-row">Tidak ada data.</div>';
    document.getElementById('detailReqsMin').innerHTML = renderReqs(d.requirementsMin || []);
    document.getElementById('detailReqsRec').innerHTML = renderReqs(d.requirementsRec || []);
  } else {
    reqsWrap.style.display = 'none';
  }
}

function artClassForId(seed) {
  const classes = ['a', 'b', 'c', 'd', 'e', 'f'];
  let hash = 0;
  for (let i = 0; i < String(seed).length; i++) hash = (hash * 31 + String(seed).charCodeAt(i)) >>> 0;
  return classes[hash % classes.length];
}

function wireDetailPage() {
  const backBtn = document.getElementById('detailBackBtn');
  if (backBtn) backBtn.addEventListener('click', () => showPage(_prevPageBeforeDetail));
}

// ── RENDER KARTU GAME ──
// Maks 3 tag genre/kategori paling relevan (urutan asli dari Steam = paling
// utama duluan) ditampilkan di tiap kartu game Dashboard — dibatasi 3 (bukan
// lebih) supaya tag-nya selalu muat 1 baris dan tinggi kartu tetap konsisten
// antar game, gak ada yang tiba-tiba lebih tinggi gara-gara tag-nya kepanjangan
// sampai turun ke baris ke-2. `genres` (nama asli Steam, mis. "Action", "RPG")
// diprioritaskan karena lebih enak dibaca; kalau belum ada (data lama belum
// pernah di-Auto-Isi ulang), fallback ke nama kategori admin yang dipetakan
// dari slug di `categories`.
function gameCardTagsHtml(item) {
  let tags = Array.isArray(item.genres) && item.genres.length ? item.genres : null;
  if (!tags) {
    const slugs = Array.isArray(item.categories) && item.categories.length ? item.categories : (item.category ? [item.category] : []);
    tags = slugs.map(slug => allCategories.find(c => c.slug === slug)?.name).filter(Boolean);
  }
  tags = tags.slice(0, 3);
  if (!tags.length) return '';
  return `<div class="game-tags">${tags.map(t => `<span class="game-tag">${escapeHtml(t)}</span>`).join('')}</div>`;
}

function renderGameCard(item, idx) {
  // PERF FIX: gambar TIDAK ditaruh di inline style lagi (lihat data-img +
  // observeCardImg di reconcileCardGrid) — supaya download gambar cuma
  // terjadi saat kartu ini mendekati layar, bukan langsung semua sekaligus.
  const imgAttr = item.imageUrl ? ` data-img="${item.imageUrl}"` : '';
  // Cover & judul SENGAJA TIDAK digelapkan/di-overlay lagi walau item ini di
  // atas paket user saat ini — game tetap kelihatan & bisa dibuka normal.
  // Pembatasan akses baru muncul (via popup) begitu user coba Install/Aktifkan
  // di halaman detail, lihat openAccessRequiredModal().
  // Game/Bypass yang di-gate Marketplace Product TIDAK memakai hierarki
  // Role/Paket (Public/Gold/Platinum/dst) sama sekali — aksesnya murni dari
  // purchase/whitelist Product, jadi badge Role/Paket-nya disembunyikan di
  // kartu. Game/Bypass normal (di luar Marketplace) tetap tampilkan badge
  // seperti biasa.
  const badgeHtml = isMktGated(item) ? '' : roleBadgeHtml(item.role);
  return `
    <div class="game-card" data-id="${item._id}">
      <div class="game-art${item.imageUrl ? '' : ' ' + artClassForId(item._id || item.name)}"${imgAttr}>
        <div class="badge-slot">${badgeHtml}</div>
        <div class="online-badge-slot">${onlineBadgeHtml(item.isOnline)}</div>
      </div>
      <div class="game-info">
        <h4 title="${escapeHtml(item.name)}">${escapeHtml(item.name)}</h4>
        ${gameCardTagsHtml(item)}
        <div class="game-meta">
          <span class="game-meta-hint">Lihat & Download</span>
          <span class="game-meta-arrow">›</span>
        </div>
      </div>
    </div>`;
}

// ── ANTI-FLICKER (partial update): dulu tiap ada 1 item berubah, SELURUH grid
// di-innerHTML ulang — bikin semua kartu (bukan cuma yang berubah) sempat lepas
// dari DOM sesaat, jadi kelihatan "berkedip" dan posisi scroll ke-reset. Sekarang
// kartu yang datanya SAMA PERSIS dari render terakhir tidak disentuh sama sekali
// (node DOM-nya dipertahankan), cuma kartu yang benar-benar berubah/baru/hilang
// yang di-update — dipakai bareng buat grid Games & Bypass (item shape sama).
//
// PENTING: currentUser.role IKUT masuk signature (bukan cuma properti item-nya
// sendiri) — soalnya status kunci/badge akses di tiap kartu bergantung pada
// role USER YANG LOGIN, bukan cuma data game itu sendiri. Tanpa ini, pas role
// user berubah (upgrade/downgrade paket), item.role si game TIDAK berubah sama
// sekali, jadi signature-nya dianggap "sama" dan kartu tidak pernah di-refresh
// -> badge/akses/tombol Install jadi basi sampai app dibuka ulang. Dengan role
// ikut di-hash, begitu role user berubah SEMUA kartu otomatis kebaca "berubah"
// serentak dan direfresh — tetap lewat reconcileCardGrid (bukan innerHTML
// penuh), jadi tetap tidak flicker/reset scroll.
function _cardItemSig(item) {
  return [
    item.name, item.imageUrl, item.role, item.isOnline, item._id,
    (item.categories || []).join(','), (item.genres || []).join(','),
    currentUser?.role || 'guest',
    // marketplaceProductIds IKUT masuk signature — badge Role/Paket di kartu
    // disembunyikan/dimunculkan tergantung item ini di-gate Marketplace
    // Product atau tidak (lihat renderGameCard/renderBypassCard), jadi kalau
    // field ini berubah kartu harus ikut di-render ulang.
    (item.marketplaceProductIds || []).join(',')
  ].join('|');
}

function reconcileCardGrid(container, items, renderCardFn, emptyHtml, onCardClick) {
  if (!container) return;
  if (!items.length) {
    container.innerHTML = emptyHtml;
    return;
  }
  if (container.querySelector('.game-card') === null) {
    // Kosong/belum pernah dirender (mis. baru pindah halaman, atau sebelumnya
    // nampilin pesan error/empty) — render penuh sekali, ga ada yg perlu di-diff.
    container.innerHTML = items.map((it, i) => renderCardFn(it, i)).join('');
    container.querySelectorAll('.game-card').forEach(card => {
      card.dataset.sig = _cardItemSig(items.find(x => String(x._id) === card.dataset.id));
    });
    container.querySelectorAll('.game-art[data-img]').forEach(observeCardImg); // PERF FIX: daftarkan buat lazy-load
    return;
  }

  const existing = new Map();
  container.querySelectorAll('.game-card[data-id]').forEach(node => existing.set(node.dataset.id, node));

  const frag = document.createDocumentFragment();
  items.forEach((item, i) => {
    const id = String(item._id);
    const sig = _cardItemSig(item);
    let node = existing.get(id);
    if (node) {
      existing.delete(id);
      if (node.dataset.sig !== sig) {
        const tmp = document.createElement('div');
        tmp.innerHTML = renderCardFn(item, i);
        const fresh = tmp.firstElementChild;
        fresh.dataset.sig = sig;
        node = fresh; // ganti node CUMA buat kartu ini — kartu lain sama sekali tidak tersentuh
        const artEl = node.querySelector('.game-art[data-img]');
        if (artEl) observeCardImg(artEl); // PERF FIX: kartu baru diganti -> daftarkan ulang buat lazy-load
      }
    } else {
      const tmp = document.createElement('div');
      tmp.innerHTML = renderCardFn(item, i);
      node = tmp.firstElementChild;
      node.dataset.sig = sig;
      const artEl = node.querySelector('.game-art[data-img]');
      if (artEl) observeCardImg(artEl); // PERF FIX: kartu benar-benar baru -> daftarkan buat lazy-load
    }
    frag.appendChild(node); // appendChild MEMINDAHKAN node yang sudah ada (bukan clone) — identitas DOM-nya tetap sama
  });

  // PERF FIX (memory leak): kartu yang dihapus tapi gambarnya belum sempat
  // di-load (masih punya data-img, berarti observer masih "mengintai" elemen
  // itu) harus di-unobserve dulu — kalau tidak, IntersectionObserver terus
  // menyimpan referensi ke elemen yang sudah lepas dari DOM selamanya.
  existing.forEach(node => {
    const artEl = node.querySelector?.('.game-art[data-img]');
    if (artEl && _cardImgObserver) _cardImgObserver.unobserve(artEl);
    node.remove();
  }); // item yang udah ga ada di data terbaru
  container.appendChild(frag); // container sudah kosong dari node lama (semua sudah dipindah/dihapus di atas)
}


function renderGrid(container, games) {
  reconcileCardGrid(
    container, games, renderGameCard,
    `<div style="color:#8577a3;font-size:13px;padding:10px 4px;">Belum ada game.</div>`
  );
}

// ── RENDER KARTU BYPASS ──
function renderBypassCard(item, idx) {
  // PERF FIX: sama seperti renderGameCard() — gambar di-lazy-load via data-img.
  const imgAttr = item.imageUrl ? ` data-img="${item.imageUrl}"` : '';
  // Sama seperti kartu Game: Bypass yang di-gate Marketplace Product tidak
  // pakai Role/Paket, jadi badge-nya disembunyikan (lihat renderGameCard).
  const badgeHtml = isMktGated(item) ? '' : roleBadgeHtml(item.role);
  return `
    <div class="game-card" data-id="${item._id}">
      <div class="game-art${item.imageUrl ? '' : ' ' + artClassForId(item._id || item.name)}"${imgAttr}>
        <div class="badge-slot">${badgeHtml}</div>
        <div class="online-badge-slot">${onlineBadgeHtml(item.isOnline)}</div>
      </div>
      <div class="game-info">
        <h4 title="${escapeHtml(item.name)}">${escapeHtml(item.name)}</h4>
        <div class="game-meta">
          <span class="game-meta-hint">Lihat & Download</span>
          <span class="game-meta-arrow">›</span>
        </div>
      </div>
    </div>`;
}

function renderBypassGrid(container, bypasses) {
  reconcileCardGrid(
    container, bypasses, renderBypassCard,
    `<div style="color:#8577a3;font-size:13px;padding:10px 4px;">Belum ada bypass.</div>`
  );
}

// Klik kartu di-delegasi ke container (dipasang SEKALI di init, lihat
// wireGamesRoleFilter/wireBypassesRoleFilter) — bukan per-kartu tiap render,
// biar patch parsial di reconcileCardGrid() ga perlu mikirin re-binding listener.
function wireCardGridClicks(container, getList, itemType) {
  if (!container) return;
  container.addEventListener('click', (e) => {
    const card = e.target.closest('.game-card[data-id]');
    if (!card) return;
    const list = getList();
    const item = list.find(x => String(x._id) === card.dataset.id);
    if (item) openDetailPage(item, itemType);
  });
}

async function loadBypasses() {
  try {
    const bypasses = await api('/api/bypasses'); // list bypass 100% ikut role & isi database server
    applyBypassesUpdate(bypasses);
  } catch (e) {
    const msg = `<div style="color:#ff6b81;font-size:13px;">Gagal memuat bypass: ${escapeHtml(e.message)}</div>`;
    if (els.bypassesGrid) els.bypassesGrid.innerHTML = msg;
  }
}

// Sama seperti applyGamesUpdate() — dipanggil dari polling ATAU langsung dari
// WebSocket 'bypasses:update', cuma render ulang kalau datanya benar-benar beda.
function applyBypassesUpdate(bypasses) {
  const sig = _catalogSig(bypasses);
  const changed = sig !== _lastBypassesSig;
  allBypasses = bypasses;

  if (els.bypassesNavLink) {
    const badge = els.bypassesNavLink.querySelector('.badge');
    if (badge) badge.textContent = bypasses.length;
  }

  if (!changed) return;
  _lastBypassesSig = sig;
  applyBypassesRoleFilter();
  _refreshOpenDetailAccessIfMatches(bypasses, 'bypass');
  // Bypass yang di-gate Marketplace juga dipakai sebagai tombol "Install Bypass"
  // KEDUA di halaman detail GAME (findLinkedBypass) — refresh itu juga kalau
  // yang lagi kebuka adalah GAME yang linked bypass-nya baru saja berubah akses.
  if (_currentDetailItem && _currentDetailItemType === 'game') {
    const detailPageEl = document.getElementById('pageGameDetail');
    if (detailPageEl && detailPageEl.style.display !== 'none') {
      const linked = findLinkedBypass(_currentDetailItem);
      if (linked && bypasses.some(b => String(b._id) === String(linked._id))) {
        applyDetailAccessState(_currentDetailItem, 'game');
      }
    }
  }
}

// ── ANTI-FLICKER: cuma render ulang grid game/bypass kalau datanya BENERAN
// berubah. Sebelumnya applyDashCategoryFilter()/applyGamesRoleFilter() selalu
// innerHTML ulang + retrigger animasi fade-in SETIAP kali auto-refresh jalan
// (tiap 15 detik) walau isinya sama persis — makanya kelihatan "refresh-refresh
// sendiri" terus-terusan. Sekarang dibandingkan pakai signature ringan dulu.
let _lastGamesSig = null;
let _lastBypassesSig = null;
function _catalogSig(list) {
  return JSON.stringify((list || []).map(x => [
    x._id, x.name, x.imageUrl, x.role, x.category, x.isOnline, x.description, x.sizeLabel,
    // hasAccess & marketplaceProductIds IKUT masuk signature — supaya kartu
    // Game/Bypass yang di-gate Marketplace langsung ter-refresh (berubah dari
    // "Tidak Ada Akses" ke Install) begitu entitlement user berubah, tanpa
    // butuh restart app. Tanpa ini, perubahan akses tidak dianggap "beda" dan
    // render ulang tidak pernah terjadi (lihat catatan anti-flicker di atas).
    x.hasAccess, (x.marketplaceProductIds || []).join(',')
  ]));
}

async function loadGames() {
  try {
    const games = await api('/api/games'); // list game 100% ikut role & isi database server
    applyGamesUpdate(games);
  } catch (e) {
    const msg = `<div style="color:#ff6b81;font-size:13px;">Gagal memuat game: ${escapeHtml(e.message)}</div>`;
    if (els.dashNewGrid) els.dashNewGrid.innerHTML = msg;
    if (els.gamesOnlyGrid) els.gamesOnlyGrid.innerHTML = msg;
  }
}

// Dipanggil dari loadGames() (hasil polling/fetch) MAUPUN langsung dari WebSocket
// event 'games:update' (realtime push begitu admin ubah data) — satu jalur yang
// sama supaya perilakunya konsisten, cuma render ulang kalau memang ada perubahan.
function applyGamesUpdate(games) {
  const sig = _catalogSig(games);
  const changed = sig !== _lastGamesSig;
  allGames = games;

  if (els.gamesNavLink) {
    const badge = els.gamesNavLink.querySelector('.badge');
    if (badge) badge.textContent = games.length;
  }

  if (!changed) return; // data sama persis -> jangan render ulang (anti-flicker)
  _lastGamesSig = sig;

  // Render ke dashboard grid — ikut filter kategori & search yang lagi aktif
  applyDashCategoryFilter();
  applyGamesRoleFilter();
  _refreshOpenDetailAccessIfMatches(games, 'game');
}

// ── Kalau user LAGI BUKA halaman Detail Game/Bypass pas datanya berubah
// (mis. entitlement Marketplace baru saja diberikan setelah lunas beli),
// tombol Install/"Tidak Ada Akses" di halaman itu ikut di-refresh DI TEMPAT —
// user tidak perlu klik back-lalu-buka-lagi buat lihat status terbaru. ──
function _refreshOpenDetailAccessIfMatches(freshList, itemType) {
  if (!_currentDetailItem || _currentDetailItemType !== itemType) return;
  const detailPageEl = document.getElementById('pageGameDetail');
  if (!detailPageEl || detailPageEl.style.display === 'none') return;
  const fresh = freshList.find(x => String(x._id) === String(_currentDetailItem._id));
  if (!fresh) return;
  _currentDetailItem = fresh;
  applyDetailAccessState(fresh, itemType);
}

// ══════════════════════════════════════════════════════════════════════════
// BANNER CAROUSEL — halaman utama. Data 100% dari /api/banners (dikelola dari
// Admin Web), auto-slide, next/prev, dot indicator, update realtime lewat
// WebSocket ('banners:update') tanpa perlu reload app sama sekali.
// ══════════════════════════════════════════════════════════════════════════
let bannerSlides = [];
let bannerIndex = 0;
let bannerAutoTimer = null;
const BANNER_AUTO_MS = 6000; // auto-slide tiap 6 detik (dalam rentang 5-7 detik yang diminta)
const BANNER_CODE_LOAD_TIMEOUT_MS = 5000; // kalau Code Banner ga kirim tanda "siap" dalam 5 detik -> fallback

async function loadBanners() {
  try {
    const banners = await api('/api/banners');
    renderBannerCarousel(banners);
  } catch (e) {
    renderBannerCarousel([]); // gagal load <svg class="icon icon-16"><use href="#ic-arrow-right"></use></svg> tampilkan empty state, bukan data palsu
  }
}

// Bikin dokumen HTML lengkap buat di-taruh di `srcdoc` iframe sandbox milik
// Code Banner. SATU-SATUNYA tempat HTML/CSS/JS banner custom dijalankan —
// iframe-nya pakai sandbox="allow-scripts" TANPA "allow-same-origin", jadi
// origin iframe ini SELALU opaque/unik: dia tidak akan pernah bisa membaca
// atau menyentuh window/localStorage/cookie/token app utama sama sekali,
// walau JS di dalamnya mencoba. Itu proteksi utamanya — bukan sanitasi teks.
//
// PENTING kalau diubah: fungsi identik ada juga di public/admin.js (dipakai
// buat Live Preview di editor) — keduanya sengaja disamakan persis supaya
// preview di Admin Web = tampilan asli di App. Ubah dua-duanya sekaligus.
function buildBannerSandboxDoc({ html, css, js }) {
  // Cegah `</script` mentah di dalam kode JS custom motong tag <script> pembungkus
  // lebih awal (trik XSS klasik) — aman diubah jadi `<\/script` karena di JS itu
  // tetap berarti karakter yang sama persis saat dieksekusi.
  const escJs = (js || '').replace(/<\/script/gi, '<\\/script');
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><style>
html,body{margin:0;padding:0;width:100%;height:100%;overflow:hidden;background:transparent;
font-family:'Poppins','Sora',sans-serif;color:#fff;box-sizing:border-box;}
*{box-sizing:border-box;}
${css || ''}
</style></head><body>
${html || ''}
<script>
(function(){
  function reportError(){ try { parent.postMessage({ __banner: 'error' }, '*'); } catch(_) {} }
  window.addEventListener('error', reportError);
  window.addEventListener('unhandledrejection', reportError);
  try {
    ${escJs}
  } catch (e) { reportError(); }
  try { parent.postMessage({ __banner: 'ready' }, '*'); } catch(_) {}
})();
<\/script>
</body></html>`;
}

// Dengar sinyal 'ready'/'error' dari iframe Code Banner manapun yang lagi
// nampil, lalu terapkan fallback (gradient + judul/deskripsi biasa, TANPA
// bikin app crash) kalau kode-nya error atau ga pernah kirim sinyal apa-apa.
window.addEventListener('message', (e) => {
  const data = e.data;
  if (!data || typeof data !== 'object' || !('__banner' in data)) return;
  const frame = [...document.querySelectorAll('#hcTrack .hc-code-frame')].find(f => f.contentWindow === e.source);
  if (!frame) return;
  const idx = Number(frame.dataset.idx);
  if (data.__banner === 'error') applyBannerFallback(idx);
  else if (data.__banner === 'ready') clearTimeout(frame._loadTimeout);
});

function applyBannerFallback(idx) {
  const slide = document.querySelector(`#hcTrack .hc-slide[data-idx="${idx}"]`);
  const b = bannerSlides[idx];
  if (!slide || !b || slide.dataset.fallbackApplied) return;
  slide.dataset.fallbackApplied = '1';
  slide.style.background = `linear-gradient(135deg, ${escapeHtml(b.gradientFrom || '#7b5cff')}, ${escapeHtml(b.gradientTo || '#241a3d')})`;
  slide.innerHTML = `
    <div class="hc-body">
      <span class="hc-icon"><svg class="icon icon-18"><use href="#ic-triangle-alert"></use></svg></span>
      <h1 class="hc-title">${escapeHtml(b.title || 'Banner')}</h1>
      ${b.description ? `<p class="hc-desc">${escapeHtml(b.description)}</p>` : ''}
    </div>`;
}

function renderBannerCarousel(banners) {
  const track = document.getElementById('hcTrack');
  const dotsWrap = document.getElementById('hcDots');
  if (!track || !dotsWrap) return;

  bannerSlides = Array.isArray(banners) ? banners : [];
  clearInterval(bannerAutoTimer);

  if (bannerSlides.length === 0) {
    track.innerHTML = `
      <div class="hc-slide hc-empty active">
        <div class="hc-body" style="max-width:100%;text-align:center;">
          <div class="hc-icon"><svg class="icon icon-18"><use href="#ic-folder-kanban"></use></svg></div>
          <div class="hc-title" style="font-size:18px;">Belum ada banner</div>
          <div class="hc-desc" style="margin:0 auto;">Admin belum menambahkan banner promosi.</div>
        </div>
      </div>`;
    dotsWrap.innerHTML = '';
    return;
  }

  track.innerHTML = bannerSlides.map((b, i) => {
    if (b.bannerType === 'code' && b.codeHtml) {
      // Placeholder dulu — srcdoc di-set lewat property JS di bawah (bukan
      // ditulis sebagai atribut string) biar ga perlu mikirin escaping quote
      // yang ribet & rawan salah dalam template string.
      return `<div class="hc-slide${i === 0 ? ' active' : ''} hc-code-slide" data-idx="${i}">
        <iframe class="hc-code-frame" data-idx="${i}" sandbox="allow-scripts" loading="lazy"></iframe>
      </div>`;
    }
    const bgImage = b.imageData || b.imageUrl || null;
    const bgStyle = bgImage
      ? `background-image:linear-gradient(90deg, rgba(10,6,16,.82) 0%, rgba(10,6,16,.42) 55%, rgba(10,6,16,.15) 100%), url('${escapeHtml(bgImage).replace(/'/g, "%27")}'); background-size:cover; background-position:center;`
      : `background:linear-gradient(135deg, ${escapeHtml(b.gradientFrom || '#7b5cff')}, ${escapeHtml(b.gradientTo || '#241a3d')});`;
    return `
    <div class="hc-slide${i === 0 ? ' active' : ''}" data-idx="${i}" style="${bgStyle}">
      <div class="hc-body">
        ${b.icon ? `<span class="hc-icon">${escapeHtml(b.icon)}</span>` : ''}
        <h1 class="hc-title">${escapeHtml(b.title)}</h1>
        ${b.subtitle ? `<div class="hc-subtitle">${escapeHtml(b.subtitle)}</div>` : ''}
        ${b.description ? `<p class="hc-desc">${escapeHtml(b.description)}</p>` : ''}
        ${b.ctaText ? `<button class="hc-cta" data-link="${escapeHtml(b.ctaLink || '')}">${escapeHtml(b.ctaText)}</button>` : ''}
      </div>
    </div>
  `;
  }).join('');

  // Isi srcdoc tiap iframe Code Banner SETELAH elemen benar-benar ada di DOM,
  // + pasang timeout fallback kalau iframe-nya ga pernah kirim sinyal 'ready'
  // (mis. kena error parsing sebelum listener sempat kepasang).
  bannerSlides.forEach((b, i) => {
    if (b.bannerType !== 'code' || !b.codeHtml) return;
    const frame = track.querySelector(`.hc-code-frame[data-idx="${i}"]`);
    if (!frame) return;
    try {
      frame.srcdoc = buildBannerSandboxDoc({ html: b.codeHtml, css: b.codeCss, js: b.codeJs });
    } catch (e) {
      applyBannerFallback(i);
      return;
    }
    frame._loadTimeout = setTimeout(() => applyBannerFallback(i), BANNER_CODE_LOAD_TIMEOUT_MS);
    frame.addEventListener('error', () => applyBannerFallback(i));
  });

  dotsWrap.innerHTML = bannerSlides.map((_, i) =>
    `<span class="hc-dot${i === 0 ? ' active' : ''}" data-idx="${i}"></span>`
  ).join('');

  bannerIndex = 0;
  goToBannerSlide(0, false);

  if (bannerSlides.length > 1) startBannerAutoplay();
}

function goToBannerSlide(idx, restartAutoplay = true) {
  if (bannerSlides.length === 0) return;
  const n = bannerSlides.length;
  bannerIndex = ((idx % n) + n) % n;

  document.querySelectorAll('#hcTrack .hc-slide').forEach(el => {
    el.classList.toggle('active', Number(el.dataset.idx) === bannerIndex);
  });
  document.querySelectorAll('#hcDots .hc-dot').forEach(el => {
    el.classList.toggle('active', Number(el.dataset.idx) === bannerIndex);
  });

  if (restartAutoplay && bannerSlides.length > 1) startBannerAutoplay();
}

function startBannerAutoplay() {
  clearInterval(bannerAutoTimer);
  bannerAutoTimer = setInterval(() => goToBannerSlide(bannerIndex + 1, false), BANNER_AUTO_MS);
}

// Klik prev/next/dot/CTA — event delegation, jadi tetap jalan walau slide-nya
// baru saja diganti/dirender ulang lewat realtime update.
document.getElementById('hcPrev')?.addEventListener('click', () => goToBannerSlide(bannerIndex - 1));
document.getElementById('hcNext')?.addEventListener('click', () => goToBannerSlide(bannerIndex + 1));
document.getElementById('hcDots')?.addEventListener('click', (e) => {
  const dot = e.target.closest('.hc-dot');
  if (dot) goToBannerSlide(Number(dot.dataset.idx));
});
document.getElementById('hcTrack')?.addEventListener('click', (e) => {
  const btn = e.target.closest('.hc-cta');
  if (!btn) return;
  const link = btn.dataset.link;
  if (!link) return;
  // Link internal (mis. "#store", "#games") pindah halaman di app; link http(s)
  // dibuka lewat browser default kalau ada API shell (Electron), fallback window.open.
  if (link.startsWith('#')) {
    const page = link.slice(1);
    if (document.getElementById('page' + page.charAt(0).toUpperCase() + page.slice(1))) {
      showPage(page);
    }
  } else if (window.electronAPI?.openExternal) {
    window.electronAPI.openExternal(link);
  } else {
    window.open(link, '_blank');
  }
});

// ══════════════════════════════════════════════════════════════════════════
// TUTORIAL — daftar tutorial 100% dari /api/tutorials (dikelola dari Admin Web
// di halaman "Kelola Tutorial"), update realtime lewat WebSocket
// ('tutorials:update') tanpa perlu update launcher ataupun restart app sama sekali.
// Search & filter kategori dikerjakan di client terhadap data yang sudah ada di
// memori (sama seperti Games/Bypass) — instan walau jumlah tutorial banyak.
// ══════════════════════════════════════════════════════════════════════════
let allTutorials = [];
let activeTutorialCategory = 'all';
let currentTutorialNavList = []; // daftar tutorial yang sedang tampil (ikut filter aktif) — dipakai Next/Previous
let currentTutorialIndex = -1;
let _prevPageBeforeTutorialDetail = 'tutorial';

async function loadTutorials() {
  try {
    allTutorials = await api('/api/tutorials');
    renderTutorialCategoryFilters();
    renderTutorialLatest();
    applyTutorialFilter();
  } catch (e) {
    if (els.tutorialGrid) {
      els.tutorialGrid.innerHTML = `<div style="color:#8577a3;font-size:13px;padding:10px 4px;">Gagal memuat tutorial: ${escapeHtml(e.message)}</div>`;
    }
  }
}

// Chip kategori dibangun dari kategori yang benar-benar ada di data tutorial saat
// ini (bukan dari koleksi terpisah) — otomatis update begitu admin menambah
// kategori baru lewat tutorial pertamanya di kategori itu.
function renderTutorialCategoryFilters() {
  if (!els.tutorialCategoryFilter) return;
  const categories = Array.from(new Set(allTutorials.map(t => t.category || 'Umum'))).sort();
  const chips = [{ slug: 'all', name: 'Semua Kategori' }, ...categories.map(c => ({ slug: c, name: c }))];

  if (!categories.includes(activeTutorialCategory) && activeTutorialCategory !== 'all') {
    activeTutorialCategory = 'all';
  }

  els.tutorialCategoryFilter.innerHTML = chips.map(c => `
    <button class="role-filter-tab${c.slug === activeTutorialCategory ? ' active' : ''}" data-category="${escapeHtml(c.slug)}">${escapeHtml(c.name)}</button>
  `).join('');
}

function wireTutorialCategoryFilter() {
  if (!els.tutorialCategoryFilter) return;
  els.tutorialCategoryFilter.addEventListener('click', (e) => {
    const btn = e.target.closest('.role-filter-tab');
    if (!btn) return;
    els.tutorialCategoryFilter.querySelectorAll('.role-filter-tab').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    activeTutorialCategory = btn.dataset.category;
    applyTutorialFilter();
  });
}

function wireTutorialSearch() {
  if (!els.tutorialSearchInput) return;
  els.tutorialSearchInput.addEventListener('input', () => applyTutorialFilter());
}

function applyTutorialFilter() {
  if (!els.tutorialGrid) return;
  const q = els.tutorialSearchInput ? els.tutorialSearchInput.value.trim().toLowerCase() : '';
  let filtered = allTutorials;
  if (activeTutorialCategory !== 'all') {
    filtered = filtered.filter(t => (t.category || 'Umum') === activeTutorialCategory);
  }
  if (q) {
    filtered = filtered.filter(t =>
      t.title.toLowerCase().includes(q) || (t.description || '').toLowerCase().includes(q)
    );
  }
  renderTutorialGrid(els.tutorialGrid, filtered);
}

// "Tutorial Terbaru" — 6 tutorial paling baru (data sudah terurut createdAt desc dari server)
function renderTutorialLatest() {
  if (!els.tutorialLatestGrid) return;
  renderTutorialGrid(els.tutorialLatestGrid, allTutorials.slice(0, 6));
}

function tutorialThumbStyle(item) {
  const src = item.thumbnailData || item.thumbnailUrl;
  return src ? `background-image:url('${src}');background-size:cover;background-position:center;` : '';
}

function renderTutorialCard(item) {
  return `
    <div class="tutorial-card" data-id="${item._id}">
      <div class="tutorial-card__thumb" style="${tutorialThumbStyle(item)}">
        <span class="tutorial-card__category">${escapeHtml(item.category || 'Umum')}</span>
      </div>
      <div class="tutorial-card__body">
        <h4 class="tutorial-card__title" title="${escapeHtml(item.title)}">${escapeHtml(item.title)}</h4>
        <p class="tutorial-card__desc">${escapeHtml(item.description || '')}</p>
        <span class="tutorial-card__btn"><svg class="icon icon-18"><use href="#ic-book-open"></use></svg> Baca Tutorial</span>
      </div>
    </div>`;
}

function renderTutorialGrid(container, tutorials) {
  if (!container) return;
  container.innerHTML = tutorials.length
    ? tutorials.map(t => renderTutorialCard(t)).join('')
    : `<div style="color:#8577a3;font-size:13px;padding:10px 4px;">Belum ada tutorial.</div>`;
  container.querySelectorAll('.tutorial-card').forEach(card => {
    card.addEventListener('click', () => {
      const tutorial = tutorials.find(t => t._id === card.dataset.id);
      if (tutorial) openTutorialDetail(tutorial, tutorials);
    });
  });
}

// Buka halaman baca tutorial. `navList` = daftar tutorial yang sedang tampil di
// kartu yang diklik (Terbaru ATAU hasil filter/search) — jadi Next/Previous
// jalan sesuai konteks tempat user meng-klik, bukan selalu urutan semua data.
function openTutorialDetail(tutorial, navList) {
  currentTutorialNavList = navList || allTutorials;
  currentTutorialIndex = currentTutorialNavList.findIndex(t => t._id === tutorial._id);
  _prevPageBeforeTutorialDetail = els.navLinks.find(a => a.classList.contains('active'))?.dataset.page || 'tutorial';
  renderTutorialDetail(tutorial);
  showPage('tutorialDetail');
}

function renderTutorialDetail(tutorial) {
  if (els.tutorialDetailCategory) els.tutorialDetailCategory.textContent = tutorial.category || 'Umum';
  if (els.tutorialDetailTitle) els.tutorialDetailTitle.textContent = tutorial.title;

  const imgSrc = tutorial.imageData || tutorial.imageUrl;
  if (els.tutorialDetailImageWrap && els.tutorialDetailImage) {
    if (imgSrc) {
      els.tutorialDetailImage.src = imgSrc;
      els.tutorialDetailImageWrap.style.display = '';
    } else {
      els.tutorialDetailImageWrap.style.display = 'none';
    }
  }

  // `content` sudah disanitasi ketat di server (lihat sanitizeTutorialContent di
  // server.js — tag berbahaya seperti <script>/<iframe>/<img> sudah dibuang di
  // sana) sebelum pernah disimpan ke DB, jadi aman dirender sebagai HTML di sini.
  if (els.tutorialDetailContent) els.tutorialDetailContent.innerHTML = tutorial.content || '';

  if (els.tutorialDetailVideoWrap && els.tutorialDetailVideo) {
    // videoPlatform/videoId = field baru (support YouTube & TikTok). Fallback ke
    // youtubeId lama supaya tutorial yang disimpan sebelum update ini tetap tampil.
    const platform = tutorial.videoPlatform || (tutorial.youtubeId ? 'youtube' : '');
    const videoId = tutorial.videoId || tutorial.youtubeId || '';

    // Histori debug Error 153/152 (lihat catatan lengkap di main.js):
    // file:// = gak ada Referer sama sekali -> 153. Referer="youtube.com"
    // -> kontradiktif, jadi 152. Load app lewat local HTTP server -> video
    // jalan TAPI bikin fetch ke backend sendiri gagal (ERR_NETWORK_ACCESS_DENIED),
    // jadi di-revert. Fix final: kasih Referer/origin = domain produksi kita
    // sendiri (SERVER_URL) — origin pihak ketiga yang valid & masuk akal buat
    // YouTube, tanpa perlu ubah cara app di-load sama sekali.
    const EMBED_REFERER = SERVER_URL + '/';

    let embedSrc = '';
    let referer = '';
    if (platform === 'youtube' && videoId) {
      referer = EMBED_REFERER;
      embedSrc = `https://www.youtube-nocookie.com/embed/${videoId}?origin=${encodeURIComponent(SERVER_URL)}`;
    } else if (platform === 'tiktok' && videoId) {
      referer = EMBED_REFERER;
      embedSrc = `https://www.tiktok.com/embed/v2/${videoId}`;
    }

    if (embedSrc) {
      // httpreferrer WAJIB di-set sebelum src diubah supaya navigasi pertama
      // ke YouTube/TikTok langsung bawa Referer yang benar.
      els.tutorialDetailVideo.setAttribute('httpreferrer', referer);
      els.tutorialDetailVideo.src = embedSrc;
      els.tutorialDetailVideoWrap.style.display = '';
    } else {
      els.tutorialDetailVideo.src = '';
      els.tutorialDetailVideoWrap.style.display = 'none';
    }
  }

  if (els.tutorialPrevBtn) els.tutorialPrevBtn.disabled = currentTutorialIndex <= 0;
  if (els.tutorialNextBtn) els.tutorialNextBtn.disabled = currentTutorialIndex < 0 || currentTutorialIndex >= currentTutorialNavList.length - 1;

  const scrollEl = document.querySelector('#pageTutorialDetail .detail-scroll');
  if (scrollEl) scrollEl.scrollTop = 0;
}

function wireTutorialDetailNav() {
  if (els.tutorialDetailBackBtn) {
    els.tutorialDetailBackBtn.addEventListener('click', () => showPage(_prevPageBeforeTutorialDetail));
  }
  if (els.tutorialPrevBtn) {
    els.tutorialPrevBtn.addEventListener('click', () => {
      if (currentTutorialIndex > 0) {
        currentTutorialIndex--;
        renderTutorialDetail(currentTutorialNavList[currentTutorialIndex]);
      }
    });
  }
  if (els.tutorialNextBtn) {
    els.tutorialNextBtn.addEventListener('click', () => {
      if (currentTutorialIndex >= 0 && currentTutorialIndex < currentTutorialNavList.length - 1) {
        currentTutorialIndex++;
        renderTutorialDetail(currentTutorialNavList[currentTutorialIndex]);
      }
    });
  }
}

// ══════════════════════════════════════════════════════════════════════════
// TOP INSTALLER MINGGUAN — leaderboard realtime dari /api/leaderboard, dihitung
// server dari data histori install asli (bukan dummy), update otomatis lewat
// WebSocket ('leaderboard:update') setiap ada install baru dari user manapun.
// ══════════════════════════════════════════════════════════════════════════
const LB_ROLE_LABEL = { public: 'Public', gold: 'Gold', platinum: 'Platinum', admin: 'Admin' };
const LB_RANK_BADGE = { 1: '<svg class="icon icon-16"><use href="#ic-trophy"></use></svg>', 2: '<svg class="icon icon-16"><use href="#ic-medal"></use></svg>', 3: '<svg class="icon icon-16"><use href="#ic-medal"></use></svg>' };

// Jumlah entry yang terakhir dirender — disimpan di luar renderLeaderboard()
// supaya listener resize/font-load di bawah bisa re-kalkulasi tinggi list
// KAPAN SAJA (tanpa perlu data baru dari server), termasuk saat window
// di-resize realtime atau begitu web font selesai ter-load (metrik baris
// bisa berubah sedikit begitu font asli ter-apply, sebelumnya ini bikin
// hasil ukur jadi basi & baris terakhir kepotong walau ruang masih ada).
let _lbLastEntriesCount = 0;
let _lbResizeObserver = null;
let _lbResizeDebounce = null;
let _lbListenersWired = false; // guard terpisah dari _lbResizeObserver — supaya window listener/fonts.ready TETAP cuma dipasang sekali walaupun ResizeObserver tidak tersedia di environment ini (jaga-jaga, walau di Electron/Chromium modern harusnya selalu ada)

function _lbRecalc() {
  const list = document.getElementById('lbList');
  if (list && _lbLastEntriesCount > 0) adjustLeaderboardListHeight(list, _lbLastEntriesCount);
}

// Dipasang SEKALI saja (elemen .leaderboard/#lbList sendiri tidak pernah
// di-recreate, cuma isinya yang di-replace tiap render) — ResizeObserver
// mendeteksi SEMUA perubahan ukuran kartu (resize window, sidebar collapse,
// perubahan layout lain yang tidak selalu memicu event 'resize' bawaan
// window), jadi jauh lebih andal daripada cuma window.resize saja.
function ensureLeaderboardResizeObserver(list) {
  if (_lbListenersWired) return;
  const card = list.closest('.leaderboard');
  if (!card) return;
  _lbListenersWired = true;

  if (typeof ResizeObserver !== 'undefined') {
    _lbResizeObserver = new ResizeObserver(() => {
      clearTimeout(_lbResizeDebounce);
      _lbResizeDebounce = setTimeout(_lbRecalc, 80);
    });
    _lbResizeObserver.observe(card);
  }

  // Jaring pengaman tambahan: window resize (buat lingkungan yang entah
  // kenapa tidak memicu ResizeObserver) + begitu web font selesai load.
  window.addEventListener('resize', () => {
    clearTimeout(_lbResizeDebounce);
    _lbResizeDebounce = setTimeout(_lbRecalc, 80);
  });
  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(_lbRecalc).catch(() => {});
  }
  // Recalc SEGERA (tanpa nunggu debounce resize) tepat pas window melewati
  // breakpoint 880px — inilah momen persis mode fullscreen <-> minimize
  // berpindah, jadi jumlah baris yang ditampilkan langsung ikut berubah
  // tanpa delay/kedip.
  if (typeof _lbCompactWindowMQ.addEventListener === 'function') {
    _lbCompactWindowMQ.addEventListener('change', _lbRecalc);
  } else if (typeof _lbCompactWindowMQ.addListener === 'function') {
    _lbCompactWindowMQ.addListener(_lbRecalc); // Safari lama
  }
}

async function loadLeaderboard() {
  try {
    const data = await api('/api/leaderboard');
    renderLeaderboard(data);
  } catch (e) {
    renderLeaderboard({ entries: [] });
  }
}

function formatInstallCount(n) {
  if (n >= 1000) return (n / 1000).toFixed(n % 1000 === 0 ? 0 : 1) + ' K';
  return String(n);
}

function renderLeaderboard(data) {
  const list = document.getElementById('lbList');
  if (!list) return;
  // Total maksimal 5 user teratas — dipotong di sini juga (bukan cuma andalkan
  // server) sebagai jaring pengaman kalau suatu saat endpoint berubah.
  const entries = ((data && Array.isArray(data.entries)) ? data.entries : []).slice(0, 5);
  _lbLastEntriesCount = entries.length;

  if (entries.length === 0) {
    list.style.maxHeight = ''; // biarkan natural buat empty state, gak perlu area scroll kosong
    list.innerHTML = `
      <div class="lb-empty">
        <div class="lb-empty-icon"><svg class="icon icon-18"><use href="#ic-trophy"></use></svg></div>
        <div>Belum ada install minggu ini.<br>Jadilah yang pertama!</div>
      </div>`;
    return;
  }

  list.innerHTML = entries.map((u, i) => {
    const rank = i + 1;
    const roleClass = u.role || 'public';
    const avatar = u.avatarUrl || 'https://cdn.discordapp.com/embed/avatars/0.png';
    // Rank #1-3 pakai ikon trofi/medali (LB_RANK_BADGE); #4 & #5 tetap perlu
    // "tampil lebih jelas" — dibuatkan badge angka bulat senada, bukan cuma
    // teks polos kayak sebelumnya.
    const rankInner = LB_RANK_BADGE[rank] || `<span class="lb-rank-num">${rank}</span>`;
    return `
      <div class="lb-row rank-${rank}">
        <div class="lb-rank">${rankInner}</div>
        <div class="lb-avatar-wrap">
          <img src="${escapeHtml(avatar)}" alt="" onerror="this.src='https://cdn.discordapp.com/embed/avatars/0.png'">
          ${rank <= 3 ? `<span class="lb-badge">${LB_RANK_BADGE[rank]}</span>` : ''}
        </div>
        <div class="lb-info">
          <div class="name">${escapeHtml(u.username || 'Unknown')}</div>
          <span class="lb-role-tag ${roleClass}">${LB_ROLE_LABEL[roleClass] || roleClass}</span>
        </div>
        <div class="score"><span class="flame"><svg class="icon icon-18"><use href="#ic-flame"></use></svg></span> ${formatInstallCount(u.installs || 0)} install</div>
      </div>`;
  }).join('');

  adjustLeaderboardListHeight(list, entries.length);
  ensureLeaderboardResizeObserver(list);
}

// ── Mode fullscreen vs minimize: SATU-SATUNYA sumber kebenaran ─────────────
// Sebelumnya mode ini dibaca dari custom property CSS (`--lb-rows`, di-set
// di dalam beberapa @media/@container berbeda) lewat
// `getComputedStyle(card).getPropertyValue('--lb-rows')`. Itu ternyata
// rapuh: custom property yang di-set DI DALAM @container query tidak selalu
// sudah ke-resolve konsisten pas dibaca lewat getComputedStyle tepat
// sesudah resize (tergantung timing style-recalc vs layout di
// Chromium/Electron) — hasilnya kadang balik ke nilai LAMA (3) walau card
// sudah visually sempit, jadi baris ke-4 di mode minimize tidak muncul
// walau ruang jelas cukup (persis bug yang dilaporkan). Sekarang mode
// ditentukan LANGSUNG di sini dengan mengukur geometri asli (lebar window
// via matchMedia + lebar ASLI card via getBoundingClientRect) — angka
// breakpoint-nya sama persis dengan yang dipakai style.css (880px & 380px,
// lihat komentar di sana) — tapi TIDAK LAGI bergantung pada round-trip
// lewat CSS custom property sama sekali, jadi hasilnya selalu konsisten
// dengan geometri yang benar-benar sedang dirender saat ini.
const LB_FULLSCREEN_MAX_ROWS = 3;
const LB_COMPACT_MAX_ROWS = 4;
// Sinkron dengan style.css: `@media (max-width:880px)` — begitu hero-row
// stack 1 kolom, Top Installer sudah dianggap mode "minimize/sempit".
const _lbCompactWindowMQ = window.matchMedia('(max-width: 880px)');
// Sinkron dengan style.css: `@container lbCard (max-width:380px)` — kartu
// bisa sudah kegencet sempit duluan (grid hero-row 1.7fr:1fr) walau window
// belum menyentuh 880px sama sekali.
const LB_COMPACT_CARD_WIDTH = 380;

function lbGetMaxRows(card) {
  if (_lbCompactWindowMQ.matches) return LB_COMPACT_MAX_ROWS;
  const cardWidth = card.getBoundingClientRect().width;
  if (cardWidth > 0 && cardWidth <= LB_COMPACT_CARD_WIDTH) return LB_COMPACT_MAX_ROWS;
  return LB_FULLSCREEN_MAX_ROWS;
}

// Batasi tinggi area .lb-list supaya PERSIS menampilkan baris-baris PENUH
// (tidak pernah baris yang kepotong separuh) — sisanya (kalau ada) tetap ada
// di DOM, cuma butuh scroll halus di dalam card buat dilihat (lihat CSS
// .lb-list: overflow-y:auto + scroll-behavior:smooth).
//
// Jumlah baris yang ditampilkan TIDAK PERNAH di-hardcode dari jumlah entry —
// selalu `min(entriesCount, lbGetMaxRows(card))`, jadi:
//   - Fullscreen -> maks 3 baris, sisanya scroll (kartu tetap fixed 300px —
//     boleh ada ruang kosong sisa di bawah baris ke-3, itu memang disengaja).
//   - Minimize/window sempit -> maks 4 baris, baris ke-4 DIJAMIN utuh tidak
//     kepotong (kartu `height:auto` otomatis membungkus PAS sebesar 4 baris
//     ini, jadi tidak ada ruang kosong tersisa maupun bagian yang terpotong).
// Tinggi 1 baris SELALU diukur langsung dari DOM (getBoundingClientRect),
// bukan ditebak/di-hardcode, supaya tetap akurat walau breakpoint mengubah
// padding/ukuran avatar/font baris. Dipanggil ulang otomatis tiap window
// di-resize / card berubah ukuran lewat ensureLeaderboardResizeObserver()
// di bawah, jadi hasilnya tidak pernah basi.
function adjustLeaderboardListHeight(list, entriesCount) {
  const card = list.closest('.leaderboard');
  const firstRow = list.querySelector('.lb-row:not(.lb-skel)') || list.querySelector('.lb-row');
  if (!card || !firstRow) { list.style.maxHeight = ''; return; }

  const rowHeight = firstRow.getBoundingClientRect().height;
  if (!(rowHeight > 0)) { list.style.maxHeight = ''; return; }

  const rowGap = 9; // WAJIB sinkron sama CSS .lb-list{gap:9px}
  const maxRows = lbGetMaxRows(card);
  const rowsToShow = Math.max(1, Math.min(entriesCount, maxRows));
  const desired = rowHeight * rowsToShow + rowGap * Math.max(0, rowsToShow - 1);
  // +1px jaga-jaga pembulatan sub-pixel, supaya baris terakhir yang
  // seharusnya utuh tidak ke-crop 1px gara-gara rounding.
  list.style.maxHeight = `${Math.ceil(desired) + 1}px`;
}

// ── SEARCH ──
function applySearchAndFilters() {
  if (!els.searchInput) return;
  applyDashCategoryFilter();
  if (document.getElementById(PAGE_IDS.games)?.style.display !== 'none') {
    applyGamesRoleFilter(); // sudah baca els.searchInput.value + role + type sendiri
  }
  if (document.getElementById(PAGE_IDS.bypasses)?.style.display !== 'none') {
    applyBypassesRoleFilter(); // sudah baca els.searchInput.value + role + type sendiri
  }
}

// PERF FIX (sesuai request user): sebelumnya applySearchAndFilters() dipanggil
// LANGSUNG di tiap event 'input' — artinya tiap 1 huruf diketik, langsung
// filter ULANG seluruh allGames/allBypasses (lowercase + string includes utk
// tiap item) DAN hitung signature buat 3 grid berbeda (Dashboard/Games/
// Bypasses) sekaligus, walau user masih dalam proses mengetik satu kata.
// Untuk katalog besar (ratusan game) ini kerja berat yang terbuang percuma
// tiap keystroke. Sekarang di-debounce 200ms — filter baru jalan setelah user
// berhenti mengetik sejenak, hasil akhirnya identik, cuma proses di
// tengah-tengah mengetik yang dihilangkan.
let _searchDebounceTimer = null;
function wireSearch() {
  if (!els.searchInput) return;
  els.searchInput.addEventListener('input', () => {
    clearTimeout(_searchDebounceTimer);
    _searchDebounceTimer = setTimeout(applySearchAndFilters, 200);
  });
}

// ══════════════════════════════════════════════════════════════
// PROGRESS MODAL — download + install UI
// ══════════════════════════════════════════════════════════════

let _dlModal = null;
let _dlLastInstallArgs = null; // untuk retry
let _dlRetryHandler = null; // override retry generik (dipakai Active Tools, dll — bukan cuma install game/bypass)

function getDlModal() {
  if (_dlModal) return _dlModal;

  const overlay = document.createElement('div');
  overlay.className = 'dl-overlay';
  overlay.id = 'dlOverlay';
  overlay.innerHTML = `
    <div class="dl-card">
      <div class="dl-header">
        <div class="dl-icon" id="dlIcon"><svg class="icon icon-18"><use href="#ic-arrow-down-to-line"></use></svg></div>
        <div>
          <div class="dl-title" id="dlTitle">Mengunduh...</div>
          <div class="dl-subtitle" id="dlSubtitle">Mohon tunggu sebentar</div>
        </div>
      </div>

      <!-- Step indicators: 1=Koneksi 2=Download 3=Ekstrak 4=Install -->
      <div class="dl-steps">
        <div class="dl-step" id="dlStep1"></div>
        <div class="dl-step" id="dlStep2"></div>
        <div class="dl-step" id="dlStep3"></div>
        <div class="dl-step" id="dlStep4"></div>
      </div>

      <div class="dl-stage">
        <span class="dl-stage-dot" id="dlStageDot"></span>
        <span id="dlStageText">Menginisialisasi...</span>
      </div>

      <div class="dl-bar-track">
        <div class="dl-bar-fill indeterminate" id="dlBarFill"></div>
      </div>

      <div class="dl-stats">
        <div id="dlStatsLeft">—</div>
        <div id="dlStatsRight">—</div>
      </div>

      <div class="dl-error-box" id="dlErrorBox">
        <div class="dl-error-title"><svg class="icon icon-18"><use href="#ic-triangle-alert"></use></svg> Terjadi Kesalahan</div>
        <div id="dlErrorMsg"></div>
      </div>

      <div class="dl-success-box" id="dlSuccessBox">
        <div id="dlSuccessMsg"></div>
      </div>

      <div class="dl-actions">
        <button class="dl-btn dl-btn-cancel" id="dlBtnCancel">Batalkan</button>
        <button class="dl-btn dl-btn-retry" id="dlBtnRetry"><svg class="icon icon-18"><use href="#ic-rotate-ccw"></use></svg> Coba Lagi</button>
        <button class="dl-btn dl-btn-primary" id="dlBtnClose"><svg class="icon icon-18"><use href="#ic-check"></use></svg> Selesai</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);

  document.getElementById('dlBtnCancel').addEventListener('click', async () => {
    await window.electronAPI.cancelDownload().catch(() => {});
    dlModalHide();
  });
  document.getElementById('dlBtnClose').addEventListener('click', () => {
    // Kalau modal ini lagi menampilkan hasil Active Tools yang GAGAL dan user
    // memilih menutup (bukan retry), batalkan rencana resume — supaya
    // aktivasi Active Tools lain yang tidak berhubungan (mis. dari Settings)
    // tidak tiba-tiba "menyambar" ke download yang sudah ditinggalkan user.
    _pendingInstallAfterActiveTools = null;
    dlModalHide();
  });
  document.getElementById('dlBtnRetry').addEventListener('click', () => {
    if (_dlRetryHandler) {
      const fn = _dlRetryHandler;
      dlModalHide();
      setTimeout(fn, 180);
      return;
    }
    if (_dlLastInstallArgs) {
      dlModalHide();
      setTimeout(() => handleInstall(..._dlLastInstallArgs), 180);
    }
  });

  _dlModal = {
    overlay,
    icon:        overlay.querySelector('#dlIcon'),
    title:       overlay.querySelector('#dlTitle'),
    subtitle:    overlay.querySelector('#dlSubtitle'),
    stageDot:    overlay.querySelector('#dlStageDot'),
    stageText:   overlay.querySelector('#dlStageText'),
    barFill:     overlay.querySelector('#dlBarFill'),
    statsLeft:   overlay.querySelector('#dlStatsLeft'),
    statsRight:  overlay.querySelector('#dlStatsRight'),
    errorBox:    overlay.querySelector('#dlErrorBox'),
    errorMsg:    overlay.querySelector('#dlErrorMsg'),
    successBox:  overlay.querySelector('#dlSuccessBox'),
    successMsg:  overlay.querySelector('#dlSuccessMsg'),
    btnCancel:   overlay.querySelector('#dlBtnCancel'),
    btnRetry:    overlay.querySelector('#dlBtnRetry'),
    btnClose:    overlay.querySelector('#dlBtnClose'),
    steps:       [1,2,3,4].map(i => overlay.querySelector(`#dlStep${i}`)),
  };
  return _dlModal;
}

function dlModalShow(title, subtitle = 'Mohon tunggu sebentar', icon = '<svg class="icon icon-16"><use href="#ic-arrow-down-to-line"></use></svg>') {
  const m = getDlModal();
  _dlRetryHandler = null;
  m.title.textContent    = title;
  m.subtitle.textContent = subtitle;
  m.icon.innerHTML       = icon;
  m.icon.className       = 'dl-icon';
  m.stageDot.className   = 'dl-stage-dot';
  m.barFill.className    = 'dl-bar-fill indeterminate';
  m.barFill.style.width  = '0%';
  m.errorBox.className   = 'dl-error-box';
  m.successBox.className = 'dl-success-box';
  m.btnRetry.className   = 'dl-btn dl-btn-retry';
  m.btnClose.className   = 'dl-btn dl-btn-primary';
  m.btnCancel.style.display = 'inline-block';
  m.statsLeft.textContent   = '—';
  m.statsRight.textContent  = '—';
  m.steps.forEach(s => s.className = 'dl-step');
  m.overlay.classList.add('show');
}

function dlModalHide() {
  const m = getDlModal();
  m.overlay.classList.remove('show');
}

function dlSetStage(text, stepDone = 0, isError = false) {
  const m = getDlModal();
  m.stageText.textContent = text;
  m.stageDot.className = 'dl-stage-dot' + (isError ? ' fail' : stepDone >= 4 ? ' done' : '');
  m.steps.forEach((s, i) => {
    if (i < stepDone) s.className = 'dl-step done';
    else if (i === stepDone && !isError) s.className = 'dl-step active';
    else if (i === stepDone && isError) s.className = 'dl-step error';
  });
}

function dlSetProgress(downloaded, total) {
  const m = getDlModal();
  if (total > 0) {
    const pct = Math.min(100, Math.round((downloaded / total) * 100));
    m.barFill.className   = 'dl-bar-fill';
    m.barFill.style.width = pct + '%';
    m.statsLeft.textContent  = `${pct}%`;
    m.statsRight.textContent = `${fmtBytes(downloaded)} / ${fmtBytes(total)}`;
  } else {
    m.barFill.className = 'dl-bar-fill indeterminate';
    m.statsLeft.textContent  = fmtBytes(downloaded);
    m.statsRight.textContent = 'Ukuran tidak diketahui';
  }
}

function dlSetSuccess(msg, detailMsg = '') {
  const m = getDlModal();
  m.icon.innerHTML   = '<svg class="icon icon-16"><use href="#ic-circle-check-big"></use></svg>';
  m.icon.className     = 'dl-icon success';
  m.subtitle.textContent = 'Proses selesai';
  m.barFill.className  = 'dl-bar-fill success';
  m.barFill.style.width = '100%';
  m.stageDot.className = 'dl-stage-dot done';
  m.steps.forEach(s => s.className = 'dl-step done');
  m.stageText.textContent = msg;
  m.statsLeft.textContent  = '100%';
  m.btnCancel.style.display = 'none';
  m.btnClose.className = 'dl-btn dl-btn-primary show';
  if (detailMsg) {
    m.successBox.className = 'dl-success-box show';
    // innerHTML (bukan textContent) — detailMsg kadang menyertakan markup ikon SVG
    // inline (mis. "Restart Steam agar perubahan aktif" dengan ikon warning), yang
    // SEBELUMNYA malah tampil sebagai teks mentah "<svg class=...>" ke user (lihat
    // screenshot bug) karena textContent tidak pernah merender HTML. detailMsg di
    // sini SELALU string internal yang di-hardcode oleh app sendiri (bukan input
    // dari user/server luar), jadi aman dipakai innerHTML.
    m.successMsg.innerHTML = detailMsg;
  }
}

function dlSetError(errMsg) {
  const m = getDlModal();
  m.icon.innerHTML    = '<svg class="icon icon-16"><use href="#ic-circle-x"></use></svg>';
  m.icon.className      = 'dl-icon error';
  m.subtitle.textContent = 'Proses gagal';
  m.barFill.className   = 'dl-bar-fill error';
  m.stageDot.className  = 'dl-stage-dot fail';
  m.stageText.textContent = 'Gagal';
  // Sembunyikan tombol cancel, tampilkan Retry DAN Close
  m.btnCancel.style.display = 'none';
  m.btnRetry.className  = 'dl-btn dl-btn-retry show';
  m.btnClose.className  = 'dl-btn dl-btn-primary show'; // <svg class="icon icon-16"><use href="#ic-arrow-left"></use></svg> tombol close selalu muncul saat error
  m.errorBox.className  = 'dl-error-box show';
  m.errorMsg.textContent = errMsg;
}

function fmtBytes(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

// ── Daftarkan listener progress dari main process (sekali saja) ──
let _progressListenerSet = false;
function ensureProgressListener() {
  if (_progressListenerSet) return;
  _progressListenerSet = true;
  // Dukung kedua nama event (download-progress dari main.js baru, inject-download-progress dari lama)
  const handler = ({ downloaded, total }) => dlSetProgress(downloaded, total);
  window.electronAPI.onDownloadProgress(handler);
  // Kalau ada onInjectDownloadProgress juga, daftarkan (kompatibilitas project lama)
  if (typeof window.electronAPI.onInjectDownloadProgress === 'function') {
    window.electronAPI.onInjectDownloadProgress(handler);
  }
}

// ── META INSTALL LOKAL (localStorage) — dipakai uninstall ──
// Sama seperti project lama: begitu install berhasil, extractedFiles/steamPath/folderPath
// langsung disimpan di localStorage PC ini juga (dikunci per history _id dari server),
// supaya uninstall punya sumber data yang PASTI ada & akurat, tidak cuma bergantung ke
// hasil GET /api/history yang datang dari round-trip server.
function getLocalInstallMeta() {
  try { return JSON.parse(localStorage.getItem('installMeta') || '{}'); } catch (e) { return {}; }
}
function saveLocalInstallMeta(historyId, meta) {
  if (!historyId) return;
  const map = getLocalInstallMeta();
  map[String(historyId)] = meta;
  localStorage.setItem('installMeta', JSON.stringify(map));
}
function removeLocalInstallMeta(historyId) {
  const map = getLocalInstallMeta();
  delete map[String(historyId)];
  localStorage.setItem('installMeta', JSON.stringify(map));
}

// ── HISTORI: kirim ke server dengan retry + antrian offline biar histori TIDAK PERNAH HILANG ──
// BUG SEBELUMNYA: kalau POST /api/history gagal (network blip sesaat, server 500,
// token mepet expired, dll) PADAHAL inject/install-nya sendiri sudah SUKSES di PC user,
// histori itu langsung hilang selamanya — gak ada retry, gak ada catatan apapun, dan
// error-nya malah bikin seluruh proses install kelihatan "gagal" padahal filenya udah kepasang.
// SEKARANG: coba beberapa kali dulu (dengan jeda), kalau masih gagal juga, payload-nya
// diantrikan ke localStorage & otomatis dicoba kirim ulang tiap kali app/hal. Histori dibuka.
function _getPendingHistoryQueue() {
  try { return JSON.parse(localStorage.getItem('pendingHistorySync') || '[]'); } catch (e) { return []; }
}
function _setPendingHistoryQueue(list) {
  try { localStorage.setItem('pendingHistorySync', JSON.stringify(list)); } catch (e) {}
}

async function saveHistoryWithRetry(payload, attempts = 3) {
  for (let i = 0; i < attempts; i++) {
    try {
      return await api('/api/history', { method: 'POST', body: JSON.stringify(payload) });
    } catch (e) {
      if (i === attempts - 1) {
        const queue = _getPendingHistoryQueue();
        queue.push({ payload, queuedAt: Date.now() });
        _setPendingHistoryQueue(queue);
        console.warn('[Histori] Gagal simpan ke server setelah beberapa percobaan, diantrikan buat dicoba lagi nanti:', e.message);
        return null;
      }
      await new Promise(r => setTimeout(r, 700 * (i + 1))); // backoff singkat sebelum retry
    }
  }
}

// Dicoba tiap kali halaman Histori dibuka / app baru masuk — kirim ulang antrian yang tertunda
async function flushPendingHistory() {
  const queue = _getPendingHistoryQueue();
  if (!queue.length) return false;
  const stillPending = [];
  let anySucceeded = false;
  for (const entry of queue) {
    try {
      await api('/api/history', { method: 'POST', body: JSON.stringify(entry.payload) });
      anySucceeded = true;
    } catch (e) {
      stillPending.push(entry);
    }
  }
  _setPendingHistoryQueue(stillPending);
  return anySucceeded;
}

// ── AUTOMATIC WATERMARK DETECTION ──
// Diminta ke server TEPAT SEBELUM inject/install (bukan menggantikan alur
// download yang sudah ada, cuma tambahan). Best-effort: kalau gagal (network
// blip, dll), install/inject TETAP lanjut seperti biasa TANPA watermark —
// fitur ini murni observability, tidak boleh sampai mengganggu proses utama.
async function issueWatermarkSafe(productType, productId) {
  try {
    const deviceInfo = (window.electronAPI?.getDeviceInfo) ? await window.electronAPI.getDeviceInfo() : {};
    const res = await api('/api/watermark/issue', { method: 'POST', body: JSON.stringify({ productType, productId, deviceInfo }) });
    if (res?.downloadId && res?.blob) return { downloadId: res.downloadId, blob: res.blob };
  } catch (e) { /* diamkan — lihat komentar di atas */ }
  return null;
}

// ── Lapor hasil GAGAL/BATAL ke server (best-effort) — attemptId dipakai server buat
// menandai attempt tanpa pernah menyentuh kuota (lihat catatan di /api/downloads/failed).
// stage: 'download' (gagal sebelum/saat unduh) | 'install' (unduh sukses, extract/copy/inject
// gagal) | 'cancelled' (user membatalkan). rollback (kalau ada) = hasil pembersihan file
// dari main process (lihat rollbackTrackedCopies() di main.js).
function reportDownloadOutcome({ itemType, itemName, itemImage, downloadAttemptId, stage, rollback, reason }) {
  api('/api/downloads/failed', {
    method: 'POST',
    body: JSON.stringify({ itemType, itemName, itemImage: itemImage || null, downloadAttemptId, stage, rollback, reason })
  }).catch(() => {});
}

// ── INSTALL -> catat ke histori ──
async function handleInstall(itemType, itemId, itemName) {
  if (!ensureActiveToolsActiveOrPrompt(itemType, itemId, itemName)) return;

  _dlLastInstallArgs = [itemType, itemId, itemName];
  ensureProgressListener();

  const isGame = itemType === 'game';
  dlModalShow(
    itemName,
    isGame ? 'Inject game ke Steam' : 'Install bypass ke folder game',
    isGame ? '<svg class="icon icon-16"><use href="#ic-gamepad-2"></use></svg>' : '<svg class="icon icon-16"><use href="#ic-shield-check"></use></svg>'
  );
  dlSetStage('Menghubungkan ke server...', 0);

  // downloadAttemptId: dibuat server begitu link/stream diminta (lihat
  // GET /api/games/:id/download & /api/bypasses/:id/download-link). Dipakai
  // buat lapor status akhir (sukses/gagal/batal) ke server TANPA pernah
  // mengurangi limit download harian di titik manapun sebelum sukses.
  let downloadAttemptId = null;

  try {
    let result;

    if (isGame) {
      // ── GAME INJECT (pakai HubCap lewat proxy server, tidak berubah) ──
      const data = await api(`/api/games/${itemId}/download`);
      if (!data.streamPath) throw new Error(data.error || 'Server tidak memberikan link download. Pastikan admin sudah mengisi data game.');
      downloadAttemptId = data.downloadAttemptId || null;
      dlSetStage('URL diterima, mendeteksi Steam...', 1);

      const token = localStorage.getItem('token') || '';
      const zipUrl = `${SERVER_URL}${data.streamPath}`;
      const streamAuthHeaders = { Authorization: `Bearer ${token}` };

      const steamPath = await window.electronAPI.getSteamPath();
      if (!steamPath) throw new Error('Steam tidak ditemukan di PC ini. Pastikan Steam sudah terinstall dan pernah dijalankan.');

      const gameWatermark = await issueWatermarkSafe('game', itemId);

      dlSetStage('Mengunduh & meng-inject file...', 1);
      result = await window.electronAPI.injectGame({
        steamPath,
        zipUrl,
        extraHeaders: streamAuthHeaders,
        watermark: gameWatermark
      });

      if (result.cancelled) {
        dlModalHide();
        reportDownloadOutcome({ itemType, itemName, itemImage: null, downloadAttemptId, stage: 'cancelled', rollback: result.rollback, reason: 'Dibatalkan oleh user.' });
        return;
      }
      if (!result.success) {
        const err = new Error(result.error || 'Inject game gagal tanpa keterangan.');
        err.stage = result.stage || 'install';
        err.rollback = result.rollback || null;
        throw err;
      }

      dlSetStage('Menyimpan ke histori...', 3);
      const gameMeta = allGames.find(g => String(g._id) === String(itemId));
      const histResp = await saveHistoryWithRetry({
        itemType, itemId, itemName,
        itemImage: gameMeta?.imageUrl || null, // fallback kalau game-nya sempat dihapus/diedit admin sebelum histori tersimpan
        extractedFiles: result.extractedFiles || [], steamPath,
        downloadAttemptId
      });
      saveLocalInstallMeta(histResp?._id, { type: 'game', extractedFiles: result.extractedFiles || [], steamPath });

      dlSetSuccess(
        'Inject berhasil!',
        `${result.extractedFiles?.length || 0} file berhasil dipasang.
<svg class="icon icon-16"><use href="#ic-triangle-alert"></use></svg> dan berhasil masuk ke Library Steam.`
      );

    } else {
      // ── BYPASS INSTALL ──
      // Bisa datang dalam 2 bentuk dari server:
      //  • directUrl  → link biasa (GitHub/GDrive/CDN lain), didownload langsung, tanpa auth.
      //  • streamPath → link Ryuu Generator, WAJIB lewat proxy server sendiri (server yang
      //    nempelin RYUU_API_KEY), makanya butuh Authorization Bearer token kita ke streamPath-nya.
      // Sebelumnya cuma directUrl yang ditangani, jadi bypass dari Ryuu (streamPath) selalu
      // gagal dengan error auth dari Ryuu itu sendiri.
      dlSetStage('Mengambil link bypass...', 1);
      const linkData = await api(`/api/bypasses/${itemId}/download-link`);
      if (!linkData.directUrl && !linkData.streamPath) {
        throw new Error(linkData.error || 'Link bypass tidak ditemukan. Pastikan admin sudah mengisi link file bypass.');
      }
      downloadAttemptId = linkData.downloadAttemptId || null;

      const appId = linkData.steamAppId || linkData.appId;
      if (!appId) throw new Error('App ID belum diisi admin pada bypass ini. Hubungi admin.');

      dlSetStage('Mendeteksi Steam...', 1);
      const steamPath = await window.electronAPI.getSteamPath();
      if (!steamPath) throw new Error('Steam tidak ditemukan. Pastikan Steam sudah terinstall.');

      dlSetStage(`Mencari folder game (App ID: ${appId})...`, 2);
      const folderResult = await window.electronAPI.findGameFolderByAppId({ steamPath, appId: String(appId) });
      if (!folderResult.found) throw new Error(folderResult.error || `Game dengan App ID ${appId} belum terinstall di Steam. Install gamenya dulu lalu coba lagi.`);

      dlSetStage('Mengunduh bypass...', 2);
      const bypassToken = localStorage.getItem('token') || '';
      const bypassDriveUrl = linkData.streamPath ? `${SERVER_URL}${linkData.streamPath}` : linkData.directUrl;
      const bypassExtraHeaders = linkData.streamPath ? { Authorization: `Bearer ${bypassToken}` } : {};
      const bypassWatermark = await issueWatermarkSafe('bypass', itemId);

      result = await window.electronAPI.installBypass({
        folderPath:   folderResult.folderPath,
        driveUrl:     bypassDriveUrl,
        extraHeaders: bypassExtraHeaders,
        userId:       currentUser?.discordId || currentUser?.userId || '',
        deviceId:     getOrCreateDeviceId(),
        gameId:       itemId,
        gameName:     itemName,
        steamAppId:   String(appId),
        watermark:    bypassWatermark,
      });
      if (result.cancelled) {
        dlModalHide();
        reportDownloadOutcome({ itemType, itemName, itemImage: null, downloadAttemptId, stage: 'cancelled', rollback: result.rollback, reason: 'Dibatalkan oleh user.' });
        return;
      }
      if (!result.success) {
        const err = new Error(result.error || 'Install bypass gagal tanpa keterangan.');
        err.stage = result.stage || 'install';
        err.rollback = result.rollback || null;
        throw err;
      }

      dlSetStage('Menyimpan ke histori...', 3);
      const bypassMeta = allBypasses.find(b => String(b._id) === String(itemId));
      const histResp = await saveHistoryWithRetry({
        itemType, itemId, itemName,
        itemImage: bypassMeta?.imageUrl || null, // fallback kalau bypass-nya sempat dihapus/diedit admin sebelum histori tersimpan
        extractedFiles: result.extractedFiles || [],
        folderPath: result.folderPath || null,
        downloadAttemptId
      });
      saveLocalInstallMeta(histResp?._id, { type: 'bypass', extractedFiles: result.extractedFiles || [], folderPath: result.folderPath || null });

      dlSetSuccess(
        'Bypass berhasil dipasang!',
        `<svg class="icon icon-16"><use href="#ic-folder"></use></svg> Diekstrak ke:
${result.folderPath || '—'}

${result.extractedFiles?.length || 0} file berhasil dipasang.`
      );
    }

    loadHistori();

  } catch (e) {
    dlSetError(e.message);
    // Laporkan kegagalan ke server supaya user dapat notifikasi (in-app + realtime) DAN
    // supaya attempt-nya ditandai gagal di server — best-effort, jangan sampai gagalnya
    // laporan ini menutupi error aslinya. Limit download TIDAK berkurang sama sekali
    // untuk kasus ini (lihat catatan di /api/downloads/failed).
    const failedMeta = isGame
      ? allGames.find(g => String(g._id) === String(itemId))
      : allBypasses.find(b => String(b._id) === String(itemId));
    reportDownloadOutcome({
      itemType, itemName, itemImage: failedMeta?.imageUrl || null,
      downloadAttemptId, stage: e.stage || 'download', rollback: e.rollback || null, reason: e.message
    });
  }
}

// ── HALAMAN HISTORI ──
let _allHistori = [];
let _historiFilter = 'all'; // all | game | bypass

async function loadHistori() {
  if (!els.historiListPage) return;
  renderHistoriSkeleton();
  try {
    await flushPendingHistory(); // coba kirim ulang histori yang sempat gagal tersimpan sebelumnya
    const rows = await api('/api/history');
    _allHistori = rows;
    renderHistoriStats(rows);
    applyHistoriFilter();
  } catch (e) {
    if (els.historiStats) els.historiStats.innerHTML = '';
    els.historiListPage.innerHTML = `
      <div class="histori-error-state">
        <div class="her-icon"><svg class="icon icon-18"><use href="#ic-triangle-alert"></use></svg></div>
        <div class="her-title">Gagal Memuat Histori</div>
        <div class="her-msg">${escapeHtml(e.message)}</div>
        <button class="her-retry" id="btnHistoriRetry">Coba Lagi</button>
      </div>`;
    document.getElementById('btnHistoriRetry')?.addEventListener('click', loadHistori);
  }
}

function renderHistoriSkeleton() {
  if (els.historiStats) {
    els.historiStats.innerHTML = [1, 2, 3].map(() => `
      <div class="hstat-card">
        <div class="hstat-icon-wrap skel-pulse hstat-skel-icon"></div>
        <div style="flex:1;">
          <div class="skel-pulse hstat-skel-num" style="margin-bottom:7px;"></div>
          <div class="skel-pulse hstat-skel-label"></div>
        </div>
      </div>`).join('');
  }
  els.historiListPage.innerHTML = `<div class="histori-skel-list">${[1, 2, 3, 4].map(() => `<div class="skel-pulse hsk-row"></div>`).join('')}</div>`;
}

function renderHistoriStats(rows) {
  if (!els.historiStats) return;
  const totalGame = rows.filter(r => r.itemType === 'game').length;
  const totalBypass = rows.filter(r => r.itemType === 'bypass').length;
  const stats = [
    { icon: '<svg class="icon icon-24"><use href="#ic-package"></use></svg>', color: '#7c5cff', num: rows.length, label: 'Total Histori' },
    { icon: '<svg class="icon icon-24"><use href="#ic-gamepad-2"></use></svg>', color: '#8b5cf6', num: totalGame,   label: 'Game Diinstall' },
    { icon: '<svg class="icon icon-24"><use href="#ic-shield-check"></use></svg>', color: '#0ea5e9', num: totalBypass, label: 'Bypass Dipakai' },
  ];
  els.historiStats.innerHTML = stats.map(s => `
    <div class="hstat-card" style="--hic:${s.color};">
      <div class="hstat-icon-wrap">${s.icon}</div>
      <div>
        <div class="hstat-num" style="color:${s.color};">${s.num}</div>
        <div class="hstat-label">${s.label}</div>
      </div>
    </div>`).join('');

  // Update angka di tab filter (sebelumnya selalu nampil "0" karena tidak pernah diisi)
  const setCount = (id, n) => { const el = document.getElementById(id); if (el) el.textContent = n; };
  setCount('htabCountAll', rows.length);
  setCount('htabCountGame', totalGame);
  setCount('htabCountBypass', totalBypass);
}

function wireHistoriTabs() {
  document.querySelectorAll('#historiTabs .htab').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#historiTabs .htab').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      _historiFilter = btn.dataset.filter;
      applyHistoriFilter();
    });
  });
}

function applyHistoriFilter() {
  const rows = _historiFilter === 'all' ? _allHistori : _allHistori.filter(r => r.itemType === _historiFilter);
  renderHistoriCards(rows);
}

// Label grup tanggal: "Hari Ini" / "Kemarin" / "12 Juli 2026"
function historiDateLabel(dateStr) {
  const d = new Date(dateStr);
  const now = new Date();
  const startOfDay = dt => new Date(dt.getFullYear(), dt.getMonth(), dt.getDate()).getTime();
  const diffDays = Math.round((startOfDay(now) - startOfDay(d)) / 86400000);
  if (diffDays === 0) return 'Hari Ini';
  if (diffDays === 1) return 'Kemarin';
  return d.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
}

function renderHistoriCards(rows) {
  if (!els.historiListPage) return;

  if (!rows.length) {
    const empty = _historiFilter === 'all'
      ? { icon: '<svg class="icon icon-24"><use href="#ic-clock"></use></svg>', title: 'Belum Ada Histori', sub: 'Game atau bypass yang kamu install akan muncul di sini.' }
      : { icon: _historiFilter === 'game' ? '<svg class="icon icon-16"><use href="#ic-gamepad-2"></use></svg>' : '<svg class="icon icon-16"><use href="#ic-shield-check"></use></svg>', title: `Belum Ada Histori ${_historiFilter === 'game' ? 'Game' : 'Bypass'}`, sub: `Kamu belum pernah install ${_historiFilter === 'game' ? 'game' : 'bypass'} apapun.` };
    els.historiListPage.innerHTML = `
      <div class="histori-empty">
        <div class="histori-empty-icon">${empty.icon}</div>
        <div class="histori-empty-title">${empty.title}</div>
        <div class="histori-empty-sub">${empty.sub}</div>
      </div>`;
    return;
  }

  // Kelompokkan per tanggal (Hari Ini / Kemarin / tanggal lengkap), urutan sudah
  // terbaru dulu karena /api/history sudah di-sort createdAt:-1 dari server.
  const groups = [];
  let currentLabel = null, currentGroup = null;
  rows.forEach(h => {
    const label = historiDateLabel(h.createdAt);
    if (label !== currentLabel) {
      currentLabel = label;
      currentGroup = { label, items: [] };
      groups.push(currentGroup);
    }
    currentGroup.items.push(h);
  });

  els.historiListPage.innerHTML = `
    <div class="histori-groups">
      ${groups.map(g => `
        <div class="histori-group">
          <div class="histori-group-date">
            <span class="histori-date-label">${escapeHtml(g.label)}</span>
            <span class="histori-date-line"></span>
            <span class="histori-date-count">${g.items.length} item</span>
          </div>
          <div class="histori-cards">
            ${g.items.map(renderHistoriCard).join('')}
          </div>
        </div>`).join('')}
    </div>`;

  wireHistoriCardActions();
}

function renderHistoriCard(h) {
  const isGame = h.itemType === 'game';
  // Ambil role TERKINI item ini (kalau masih ada di daftar games/bypasses yang aktif) —
  // supaya badge role tetap akurat walau role item berubah setelah di-install.
  const list = isGame ? allGames : allBypasses;
  const liveItem = list.find(x => String(x._id) === String(h.itemId));
  const role = liveItem?.role || null;
  const d = new Date(h.createdAt);
  const fullDate = d.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' }) + ' • ' + d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });

  return `
    <div class="histori-card" data-hid="${h._id}">
      <div class="hcard-cover">
        ${h.itemImage
          ? `<img src="${escapeHtml(h.itemImage)}" alt="" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='flex';">
             <div class="hcard-cover-fallback" style="display:none;">${isGame ? '<svg class="icon icon-16"><use href="#ic-gamepad-2"></use></svg>' : '<svg class="icon icon-16"><use href="#ic-shield-check"></use></svg>'}</div>`
          : `<div class="hcard-cover-fallback">${isGame ? '<svg class="icon icon-16"><use href="#ic-gamepad-2"></use></svg>' : '<svg class="icon icon-16"><use href="#ic-shield-check"></use></svg>'}</div>`
        }
        <span class="hcard-type-badge ${isGame ? 'hcard-type-game' : 'hcard-type-bypass'}">${isGame ? '<svg class="icon icon-16"><use href="#ic-gamepad-2"></use></svg> Game' : '<svg class="icon icon-16"><use href="#ic-shield-check"></use></svg> Bypass'}</span>
        <button class="hcard-uninstall" data-id="${h._id}" title="Hapus dari histori">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6m5 0V4a2 2 0 012-2h0a2 2 0 012 2v2"/></svg>
        </button>
      </div>
      <div class="hcard-body">
        <div class="hcard-name" title="${escapeHtml(h.itemName)}">${escapeHtml(h.itemName)}</div>
        <div class="hcard-footer">
          <div class="hcard-meta-row">
            <span class="hcard-time"><svg class="icon icon-18"><use href="#ic-clock"></use></svg> ${timeAgo(h.createdAt)}</span>
            ${role ? `<span class="hcard-role ${role}">${escapeHtml(role)}</span>` : ''}
          </div>
          <div class="hcard-date-full">${fullDate}</div>
        </div>
      </div>
    </div>`;
}

// Uninstall pakai konfirmasi 2 langkah (klik pertama jadi warning, klik kedua baru
// benar-benar hapus) — supaya tidak kehapus tidak sengaja, tanpa perlu popup alert().
async function wireHistoriCardActions() {
  els.historiListPage.querySelectorAll('.hcard-uninstall').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      if (!btn.classList.contains('confirm')) {
        btn.classList.add('confirm');
        btn.title = 'Klik lagi untuk konfirmasi hapus';
        setTimeout(() => btn.classList.remove('confirm'), 3000); // batal otomatis kalau tidak jadi diklik
        return;
      }
      const card = btn.closest('.histori-card');
      const historiId = btn.dataset.id;
      const row = _allHistori.find(h => String(h._id) === String(historiId));

      // PENTING: utamakan data dari localStorage (installMeta) — ini disimpan LANGSUNG
      // di PC ini tepat saat install barusan berhasil, jadi dijamin ada & akurat (persis
      // pola project lama yang uninstall-nya sudah terbukti jalan). Data dari server
      // (row.extractedFiles/dst) cuma dipakai sebagai fallback kalau localStorage-nya
      // kosong (misal histori disinkron dari device lain, atau data dari sebelum fix ini).
      const localMeta = getLocalInstallMeta()[String(historiId)];
      const itemType     = localMeta?.type        ?? row?.itemType;
      const extractedFiles = (localMeta?.extractedFiles ?? row?.extractedFiles) || [];
      const steamPathMeta  = localMeta?.steamPath  ?? row?.steamPath  ?? null;
      const folderPathMeta = localMeta?.folderPath ?? row?.folderPath ?? null;

      btn.disabled = true;
      try {
        let fileWarning = '';
        let needRestartSteam = false;

        // BUG FIX: sebelumnya di sini cuma langsung DELETE ke /api/history tanpa
        // pernah menyentuh file di PC user sama sekali — jadi "uninstall" cuma
        // menghilangkan catatannya, file .lua/.manifest (game) atau file bypass di
        // folder game tetap ada. Sekarang panggil removeGame/removeBypass dulu.
        if (itemType === 'game') {
          if (extractedFiles.length) {
            // steamPath mungkin tidak tersimpan (histori lama sebelum fix ini) —
            // fallback ke deteksi ulang steamPath di PC ini kalau tidak ada.
            const steamPath = steamPathMeta || await window.electronAPI.getSteamPath();
            if (steamPath) {
              const rmResult = await window.electronAPI.removeGame({ steamPath, extractedFiles });
              if (!rmResult?.success) fileWarning = ` (file di PC gagal dihapus: ${rmResult?.error || 'tidak diketahui'})`;
              else needRestartSteam = true; // file sudah kehapus, tapi Steam masih baca cache lama sampai di-restart
            } else {
              fileWarning = ' (Steam tidak ditemukan, file di PC tidak ikut dihapus)';
            }
          } else {
            fileWarning = ' (histori lama, daftar file tidak tersimpan — hapus manual dari folder Steam kalau perlu)';
          }
        } else if (itemType === 'bypass') {
          if (extractedFiles.length && folderPathMeta) {
            const rmResult = await window.electronAPI.removeBypass({ folderPath: folderPathMeta, extractedFiles });
            if (!rmResult?.success) fileWarning = ` (file di PC gagal dihapus: ${rmResult?.error || 'tidak diketahui'})`;
          } else {
            fileWarning = ' (histori lama, daftar file tidak tersimpan — hapus manual dari folder game kalau perlu)';
          }
        }

        card?.classList.add('removing');
        await api('/api/history/' + historiId, { method: 'DELETE' });
        removeLocalInstallMeta(historiId);

        if (needRestartSteam) {
          // PENTING: file .lua/.manifest yang baru dihapus BARU benar-benar hilang dari
          // Steam (unlock game hilang) setelah Steam di-restart — kalau tidak, Steam masih
          // pakai cache lama dan kelihatan seperti "uninstall tidak berfungsi" padahal
          // filenya sudah beneran terhapus dari PC.
          showHistoriRestartToast();
        } else {
          showHistoriToast('Berhasil dihapus dari histori' + fileWarning);
        }
        setTimeout(() => loadHistori(), 220);
      } catch (err) {
        btn.disabled = false;
        card?.classList.remove('removing');
        showHistoriToast('Gagal hapus: ' + err.message);
      }
    });
  });
}

// ══════════════════════════════════════════════════════════════════════════
// TOAST AUTO-HIDE — SEMUA toast di app ini (notif realtime, histori, role
// diperbarui, dst) pakai helper YANG SAMA supaya konsisten: selalu hilang
// otomatis TEPAT 4 detik setelah muncul terakhir kali.
//
// BUG FIX: sebelumnya tiap toast punya timer sendiri-sendiri dan cuma
// diandalkan dari setTimeout biasa — begitu window app di-minimize/di-hidden
// lama, browser (Electron/Chromium) suka nge-throttle setTimeout di
// background, jadi toast yang harusnya sudah ilang malah nyangkut sampai
// window aktif lagi ("notif suka ga ilang-ilang"). Sekarang tiap kali toast
// ditampilkan, waktu seharusnya-hilang (hideAt) dicatat, DAN begitu window
// balik jadi visible, semua toast yang harusnya udah lewat waktunya langsung
// dipaksa ketutup — jadi dijamin tidak akan nyangkut lagi.
// ══════════════════════════════════════════════════════════════════════════
const TOAST_AUTO_HIDE_MS = 4000;
const _activeToastTimers = new Map(); // el -> { timer, hideAt, showClass }

function scheduleToastAutoHide(el, showClass = 'show', ms = TOAST_AUTO_HIDE_MS) {
  const existing = _activeToastTimers.get(el);
  if (existing) clearTimeout(existing.timer);
  const hideAt = Date.now() + ms;
  const timer = setTimeout(() => {
    el.classList.remove(showClass);
    _activeToastTimers.delete(el);
  }, ms);
  _activeToastTimers.set(el, { timer, hideAt, showClass });
}

document.addEventListener('visibilitychange', () => {
  if (document.visibilityState !== 'visible') return;
  const now = Date.now();
  for (const [el, info] of _activeToastTimers) {
    if (now >= info.hideAt) {
      el.classList.remove(info.showClass);
      clearTimeout(info.timer);
      _activeToastTimers.delete(el);
    }
  }
});

// Toast khusus uninstall game — kasih tombol "Restart Steam Sekarang" langsung di toastnya,
// karena tanpa restart, perubahan (game/DLC hilang dari Steam) belum akan kelihatan.
function showHistoriRestartToast() {
  let toastEl = document.querySelector('.histori-toast');
  if (!toastEl) {
    toastEl = document.createElement('div');
    toastEl.className = 'histori-toast';
    document.body.appendChild(toastEl);
  }
  toastEl.innerHTML = `File berhasil dihapus. <svg class="icon icon-16"><use href="#ic-triangle-alert"></use></svg> Restart Steam agar perubahan aktif —
    <a href="#" id="historiRestartSteamBtn" style="color:#a78bfa;text-decoration:underline;font-weight:700;">Restart Sekarang</a>`;
  toastEl.classList.add('show');
  scheduleToastAutoHide(toastEl, 'show');
  document.getElementById('historiRestartSteamBtn')?.addEventListener('click', async (e) => {
    e.preventDefault();
    toastEl.classList.remove('show');
    const steamPath = await window.electronAPI.getSteamPath();
    if (steamPath) await window.electronAPI.restartSteam(steamPath);
  });
}

function showHistoriToast(msg) {
  let toastEl = document.querySelector('.histori-toast');
  if (!toastEl) {
    toastEl = document.createElement('div');
    toastEl.className = 'histori-toast';
    document.body.appendChild(toastEl);
  }
  toastEl.textContent = msg;
  toastEl.classList.add('show');
  scheduleToastAutoHide(toastEl, 'show');
}

// ── Toast khusus notif "role/paket kamu diperbarui" — dipanggil dari
// refreshCurrentUserRole() begitu terdeteksi role berubah.
const ROLE_TOAST_LABEL = { public: 'Public', gold: 'Gold', platinum: 'Platinum', admin: 'Admin' };
const ROLE_TOAST_DESC  = {
  public:   'Akses kamu kembali ke mode Public.',
  gold:     'Kamu sekarang bisa akses semua konten Gold! <svg class="icon icon-16"><use href="#ic-party-popper"></use></svg>',
  platinum: 'Akses UNLIMITED ke semua konten aktif! <svg class="icon icon-16"><use href="#ic-rocket"></use></svg>',
};
// ══════════════════════════════════════════════════════════════════════════
// REALTIME — WebSocket (download limit, masa aktif, status akun, notifikasi)
// Semua perubahan dari admin (role, masa aktif, reset kuota) & event server (limit
// abis, paket abis, download sukses/gagal) langsung sampai ke sini TANPA perlu
// refresh/restart/login ulang. Polling (_roleCheckTimer dkk) tetap jalan sebagai
// fallback kalau koneksi WS lagi putus (mis. jaringan tidak stabil).
// ══════════════════════════════════════════════════════════════════════════
let _ws = null;
let _wsReconnectTimer = null;
let _wsReconnectDelay = 2000;
let _wsHasConnectedOnce = false; // guard: resync games/bypasses cuma perlu saat RECONNECT, bukan koneksi pertama (sudah di-load di init sequence)

function connectRealtime() {
  const token = localStorage.getItem('token');
  if (!token || !currentUser) return;
  try { _ws?.close(); } catch (e) {}

  _ws = new WebSocket(`${WS_URL}?token=${encodeURIComponent(token)}`);

  _ws.onopen = () => {
    _wsReconnectDelay = 2000;
    setProfileOnlineStatus(true);
    // FIX (Live Chat realtime): setiap kali socket ini (re)connect — termasuk
    // setelah putus diam-diam (laptop sleep, jaringan pindah, server restart) lalu
    // otomatis reconnect — langsung resync riwayat chat dari server. Sebelumnya
    // TIDAK ada hook ini sama sekali, jadi kalau socket sempat mati & balik lagi,
    // balasan Admin yang terkirim selama jeda itu tidak pernah muncul sampai App
    // ditutup-buka ulang (yang notabene memaksa fetch REST dari nol). Ini akar
    // masalah utamanya — bukan cuma soal event WS-nya, tapi soal TIDAK ADA
    // mekanisme "catch up" setelah reconnect.
    window.LiveChatWidget?.onSocketOpen?.();

    // WHITELIST REALTIME FIX — bagian RECONNECT: kalau socket sempat putus lalu
    // admin melakukan whitelist grant/revoke SELAGI putus, event 'account:update'
    // itu fire-and-forget (tidak di-queue server) jadi hilang begitu saja dan
    // TIDAK pernah sampai. Supaya state game/bypass (hasAccess) tetap benar
    // setelah App balik online, sinkronisasi ulang SEKALI setiap kali RECONNECT
    // (bukan koneksi pertama saat startup — itu sudah di-cover init sequence,
    // lihat pemanggilan loadGames()/loadBypasses() setelah initApp) — bukan
    // polling berkala, cukup dipicu oleh event connect itu sendiri.
    if (_wsHasConnectedOnce && currentUser) { loadGames(); loadBypasses(); }
    // Sama untuk Marketplace: kalau sempat putus lalu Admin ubah Product atau
    // pembayaran/whitelist user ini berubah SELAGI putus, event
    // marketplace:*:update itu fire-and-forget juga (tidak di-queue server) —
    // resync sekali tiap RECONNECT biar grid Product On Sale, gating akses
    // Game/Bypass, dan (kalau lagi terbuka) halaman Detail Product tidak
    // pernah nyangkut di state lama.
    if (_wsHasConnectedOnce && currentUser) { handleMktAccessUpdate(); }
    _wsHasConnectedOnce = true;
  };

  _ws.onmessage = (ev) => {
    let msg;
    try { msg = JSON.parse(ev.data); } catch (e) { return; }
    if (!msg || !msg.event) return;

    if (msg.event === 'account:update') {
      handleAccountUpdate(msg.data);
    } else if (msg.event === 'notification') {
      handleIncomingNotification(msg.data);
    } else if (msg.event === 'notification:unread-count') {
      setNotifUnreadCount(msg.data.unread);
    } else if (msg.event === 'device:reset') {
      handleDeviceReset();
    } else if (msg.event === 'banners:update') {
      renderBannerCarousel(msg.data);
    } else if (msg.event === 'categories:update') {
      // Push realtime dari Admin Web (tambah/edit/hapus/reorder/toggle Active) —
      // server HANYA mengirim kategori berstatus Active, jadi tinggal dipakai
      // langsung tanpa filter tambahan di sini. Filter Dashboard yang lagi aktif
      // otomatis kebawa lewat applyDashCategoryFilter() (misal kategori yang lagi
      // dipilih ternyata baru saja dinonaktifkan admin -> otomatis balik ke "All Games").
      allCategories = msg.data || [];
      if (activeDashCategoryFilter !== 'all' && !allCategories.some(c => c.slug === activeDashCategoryFilter)) {
        activeDashCategoryFilter = 'all';
      }
      renderDashCategoryFilters();
      applyDashCategoryFilter();
    } else if (msg.event === 'tutorials:update') {
      allTutorials = msg.data;
      renderTutorialCategoryFilters();
      renderTutorialLatest();
      applyTutorialFilter();
    } else if (msg.event === 'leaderboard:update') {
      renderLeaderboard(msg.data);
    } else if (msg.event === 'games:update') {
      // Push realtime dari admin (tambah/edit/hapus game) — langsung dipakai,
      // TIDAK fetch ulang. applyGamesUpdate() sendiri yang cek apa datanya
      // beda dari sebelumnya sebelum render ulang (anti-flicker).
      applyGamesUpdate(msg.data);
    } else if (msg.event === 'bypasses:update') {
      applyBypassesUpdate(msg.data);
    } else if (msg.event === 'premium:cleanup') {
      handlePremiumCleanup(msg.data);
    } else if (msg.event === 'transaction:update') {
      handleTransactionUpdate(msg.data);
    } else if (msg.event === 'steamAccounts:order:update') {
      handleStaOrderUpdate(msg.data);
    } else if (msg.event === 'steamAccounts:credentialsDm') {
      // Flow: Pembayaran berhasil -> Backend verifikasi -> kirim kredensial ke
      // DM Discord -> hasilnya (berhasil/gagal + alasan spesifik kalau gagal)
      // di-push ke sini secara realtime. TIDAK PERNAH menebak/pakai pesan
      // generik kalau gagal — pesan errornya persis dari backend.
      handleStaCredentialsDmUpdate(msg.data);
    } else if (msg.event === 'steamAccounts:products:update') {
      // Payload cuma sinyal "ada perubahan" (lihat broadcastSteamAccountsUpdate
      // di server.js) — TIDAK berisi isOwner/hasPendingOrder karena itu
      // personal per-user. Selalu fetch ulang personalized biar status
      // kepemilikan/proses pembayaran user ini sendiri tidak pernah salah
      // ke-reset oleh aktivitas user lain.
      loadSteamAccounts();
    } else if (msg.event === 'gameRequest:update') {
      handleGameRequestUpdate(msg.data);
    } else if (msg.event === 'marketplace:products:update') {
      // Push realtime dari Admin Web (Add/Edit/Delete/Nonaktifkan Product).
      // Payload dari backend (broadcastMarketplaceProductsUpdate di server.js)
      // CUMA sinyal "ada perubahan" ({ changed, at }) — TIDAK berisi daftar
      // produk, karena data produk personalized per-user (isOwner/
      // hasPendingOrder beda-beda tiap user, sama seperti pola
      // steamAccounts:products:update). Makanya di sini SELALU fetch ulang
      // via loadMarketplaceProducts(), bukan langsung pakai msg.data — kalau
      // langsung dipakai, produk baru justru tidak akan muncul (dan produk
      // lain malah ikut hilang dari grid karena payload sinyal ini kosong).
      loadMarketplaceProducts();
    } else if (msg.event === 'marketplace:access:update') {
      // Entitlement user berubah realtime (Whitelist grant/revoke dari Admin,
      // atau order siapapun baru saja lunas) — lihat handleMktAccessUpdate().
      handleMktAccessUpdate(msg.data);
    } else if (msg.event === 'marketplace:order:update') {
      // Status order KlikQRIS (pending/completed/expired/failed) berubah —
      // dipakai buat update modal QRIS yang lagi terbuka secara instan, tanpa
      // menunggu polling 5 detik (pollMktPurchaseStatus tetap jalan sebagai
      // fallback kalau WS lagi putus).
      handleMktOrderUpdate(msg.data);
    } else if (msg.event === 'packages:update') {
      _lastPackagesData = msg.data;
      if (document.getElementById('pageStore')?.style.display !== 'none') {
        renderPackages(_lastPackagesData);
        renderCompareTable(_lastPackagesData);
      }
    } else if (msg.event === 'app-update:config') {
      // Admin mengubah pengaturan App Update saat user sedang online —
      // langsung dievaluasi ulang tanpa perlu buka ulang app.
      applyAppUpdateConfig(msg.data);
    } else if (msg.event === 'maintenance:config') {
      // Admin mengaktifkan/menonaktifkan Maintenance Mode saat user sedang
      // online — langsung diterapkan (App dikunci/dibuka kembali) tanpa
      // perlu buka ulang app. Payload ini sudah personalized (field `bypass`
      // sudah dihitung server berdasarkan whitelist/role user ini).
      applyMaintenanceConfig(msg.data);
    } else if (msg.event === 'active-tools:config') {
      // Admin mengubah pengaturan Active Tools saat user sedang online —
      // kartu di halaman Settings langsung ter-update tanpa perlu buka ulang app.
      applyActiveToolsConfig(msg.data);
    } else if (msg.event === 'cloud-fix:config') {
      // Sama seperti active-tools:config di atas, untuk Cloud FIX.
      applyCloudFixConfig(msg.data);
    } else if (msg.event.startsWith('livechat:')) {
      // Live Chat Support — modul terpisah (livechat.js), lihat handleWsEvent() di sana.
      window.LiveChatWidget?.handleWsEvent(msg);
    }
  };

  _ws.onclose = () => {
    setProfileOnlineStatus(false);
    if (!currentUser) return; // sudah logout, tidak perlu reconnect
    clearTimeout(_wsReconnectTimer);
    _wsReconnectTimer = setTimeout(connectRealtime, _wsReconnectDelay);
    _wsReconnectDelay = Math.min(_wsReconnectDelay * 1.5, 30000);
  };
  _ws.onerror = () => { try { _ws.close(); } catch (e) {} };
}

function disconnectRealtime() {
  clearTimeout(_wsReconnectTimer);
  try { _ws?.close(); } catch (e) {}
  _ws = null;
  _wsHasConnectedOnce = false;
}

// Dipanggil setiap kali server push perubahan role / masa aktif / limit download
// (lihat 'account:update' di connectRealtime()).
async function handleAccountUpdate(freshUser) {
  if (!currentUser || !freshUser) return;
  const oldRole = currentUser.role;
  const oldUsername = currentUser.username;
  const oldAvatarUrl = currentUser.avatarUrl;
  currentUser = { ...currentUser, ...freshUser };
  _saveUser(currentUser);

  setProfileRole(currentUser.role);
  renderPackageCard(currentUser);

  // Nama/foto bisa berubah baik dari device lain (Edit Profil) maupun sinkronisasi
  // biasa — terapkan ke sidebar/topbar kalau memang ada perubahan, TANPA restart.
  if (freshUser.username && freshUser.username !== oldUsername) applyProfileToUI({ username: freshUser.username });
  if (freshUser.avatarUrl && freshUser.avatarUrl !== oldAvatarUrl) applyProfileToUI({ avatarUrl: freshUser.avatarUrl });

  // Kalau halaman Setting (form Edit Profil) sedang kebuka, refresh baseline-nya
  // juga supaya tidak menampilkan data basi/menimpa perubahan dari device lain.
  const settingPageEl = document.getElementById('pageSetting');
  if (settingPageEl && settingPageEl.style.display !== 'none' && !_epSaving) loadEditProfileForm();

  if (oldRole && freshUser.role && oldRole !== freshUser.role) {
    showRoleUpdateToast(oldRole, freshUser.role);
    loadGames();
    loadBypasses();

    // Kalau user LAGI BUKA halaman detail game/bypass pas role-nya berubah,
    // tombol Install/Aktifkan-nya di-refresh juga di tempat — user tidak perlu
    // klik back-lalu-buka-lagi buat lihat status akses terbaru.
    const detailPageEl = document.getElementById('pageGameDetail');
    if (_currentDetailItem && detailPageEl && detailPageEl.style.display !== 'none') {
      applyDetailAccessState(_currentDetailItem, _currentDetailItemType);
    }
  }

  // Steam & Discord Detection — role di card Discord ikut ke-update realtime kalau
  // halaman Setting kebetulan lagi punya data (tanpa perlu klik Refresh manual).
  const roleEl = document.getElementById('sysdetDiscordRole');
  if (roleEl && _sysdetData) {
    const ROLE_LABEL = { public: '<svg class="icon icon-16"><use href="#ic-globe"></use></svg> Public', gold: '<svg class="icon icon-16"><use href="#ic-trophy"></use></svg> Gold', platinum: '<svg class="icon icon-16"><use href="#ic-gem"></use></svg> Platinum', admin: '<svg class="icon icon-16"><use href="#ic-crown"></use></svg> Admin' };
    roleEl.innerHTML = ROLE_LABEL[currentUser.role] || currentUser.role;
  }

  // (Gold Trial tidak lagi punya banner/halaman tersendiri di sini — status
  // "sedang trial atau tidak" sudah otomatis kelihatan dari pkg-badge & progress
  // masa aktif di renderPackageCard() lewat user.accountStatus.isGoldTrial,
  // TANPA perlu request/refresh terpisah tiap ada account:update.)
}

// Dipanggil kalau admin menekan "Reset Device" saat app ini sedang aktif — paksa
// logout sekarang juga (tanpa perlu restart app), user tinggal login ulang dan
// perangkat ini otomatis didaftarkan lagi sebagai perangkat baru.
function handleDeviceReset() {
  disconnectRealtime();
  localStorage.removeItem('token');
  localStorage.removeItem('_savedUser');
  currentUser = null;
  location.reload();
}

// ══════════════════════════════════════════════════════════════════════════
// AUTO REMOVE INSTALLED PREMIUM CONTENT
// Dipicu server (event WS 'premium:cleanup') begitu masa aktif Gold/Platinum
// habis — realtime kalau app lagi kebuka, atau lewat checkPendingPremiumCleanups()
// begitu app dibuka lagi kalau tadi sempat tertutup. TIDAK ADA cara bagi user
// biasa untuk membatalkan proses ini (tidak ada tombol skip/cancel di modal-nya).
// ══════════════════════════════════════════════════════════════════════════
const _processedCleanupJobs = new Set(); // cegah job yang sama diproses 2x (WS + polling nyaris bareng)

async function checkPendingPremiumCleanups() {
  try {
    const { jobs } = await api('/api/premium-cleanup/pending');
    for (const job of (jobs || [])) {
      await handlePremiumCleanup(job);
    }
  } catch (e) {} // best-effort — jangan sampai gagal ganggu proses buka app
}

async function handlePremiumCleanup(job) {
  if (!job || !job.jobId || _processedCleanupJobs.has(job.jobId)) return;
  _processedCleanupJobs.add(job.jobId);

  // SILENT untuk manual (dipicu admin dari 🧹/Hapus Manual) — sesuai permintaan
  // eksplisit, TIDAK ADA popup/notifikasi apapun yang ditampilkan ke user, file
  // tetap dihapus di background seperti biasa. Auto-delete setelah paket Gold/
  // Platinum expired TETAP tampilkan modal peringatan seperti biasa.
  const silent = job.reason === 'manual';
  if (!silent) showPremiumCleanupModal('start', job);

  try { await api(`/api/premium-cleanup/${job.jobId}/start`, { method: 'POST' }); } catch (e) {}

  const results = [];
  let needRestartSteam = false;
  let cachedSteamPath = null;

  for (const item of (job.items || [])) {
    let removed = false, error = null;
    try {
      if (item.itemType === 'game') {
        if (!item.extractedFiles || !item.extractedFiles.length) {
          error = 'Data file tidak lengkap (histori lama)';
        } else {
          const steamPath = item.steamPath || cachedSteamPath || (cachedSteamPath = await window.electronAPI.getSteamPath());
          if (!steamPath) { error = 'Steam tidak ditemukan di PC ini'; }
          else {
            const rm = await window.electronAPI.removeGame({ steamPath, extractedFiles: item.extractedFiles });
            removed = !!rm?.success;
            if (removed) needRestartSteam = true;
            else error = rm?.error || 'Gagal menghapus file game';
          }
        }
      } else if (item.itemType === 'bypass') {
        if (!item.extractedFiles || !item.extractedFiles.length || !item.folderPath) {
          error = 'Data file tidak lengkap (histori lama)';
        } else {
          const rm = await window.electronAPI.removeBypass({ folderPath: item.folderPath, extractedFiles: item.extractedFiles });
          removed = !!rm?.success;
          if (!removed) error = rm?.error || 'Gagal menghapus file bypass';
        }
      } else {
        error = 'Tipe item tidak dikenal';
      }
    } catch (e) {
      error = e.message || 'Terjadi kesalahan';
    }

    if (removed) removeLocalInstallMeta(item.historyId);
    results.push({ historyId: item.historyId, itemType: item.itemType, itemName: item.itemName, removed, error });
  }

  let serverResult = { removedGames: [], removedBypass: [], failed: [] };
  try {
    serverResult = await api(`/api/premium-cleanup/${job.jobId}/complete`, {
      method: 'POST',
      body: JSON.stringify({ results })
    });
  } catch (e) {}

  if (!silent) showPremiumCleanupModal('done', job, { ...serverResult, needRestartSteam });

  // Refresh tampilan supaya konten yang barusan dihapus langsung hilang dari Histori/Games
  setTimeout(() => {
    loadHistori().catch(() => {});
    loadGames().catch(() => {});
    loadBypasses().catch(() => {});
  }, 300);
}

// ── Modal Auto Remove — 2 state: 'start' (peringatan sebelum hapus, tanpa tombol
// tutup — proses tidak bisa dibatalkan) dan 'done' (hasil akhir + tombol Perpanjang/Beli). ──
function showPremiumCleanupModal(state, job, resultData) {
  let overlay = document.getElementById('premiumCleanupOverlay');
  if (!overlay) return;
  overlay.style.display = 'flex';
  const roleLabel = String(job.role || '').toUpperCase();

  if (state === 'start') {
    const isManual = job.reason === 'manual';
    const title = isManual
      ? 'Admin Menghapus Konten Kamu'
      : `Paket ${escapeHtml(roleLabel)} Kamu Telah Berakhir`;
    const desc = `Seluruh <b>${job.gameCount || 0} game</b> dan <b>${job.bypassCount || 0} bypass</b>${isManual ? '' : ' premium'} yang kamu install akan otomatis dihapus dari PC ini sekarang. Proses ini tidak bisa dibatalkan.`;
    overlay.innerHTML = `
      <div class="pcm-modal">
        <div class="pcm-icon pcm-icon--warn">${isManual ? '<svg class="icon icon-16"><use href="#ic-brush"></use></svg>' : '<svg class="icon icon-16"><use href="#ic-alarm-clock"></use></svg>'}</div>
        <div class="pcm-title">${title}</div>
        <div class="pcm-desc">${desc}</div>
        <div class="pcm-progress"><div class="pcm-progress-bar"></div></div>
        <div class="pcm-status">Sedang menghapus, mohon tunggu...</div>
      </div>`;
    return;
  }

  // state === 'done'
  const removedGames  = resultData?.removedGames  || [];
  const removedBypass = resultData?.removedBypass || [];
  const failed        = resultData?.failed || [];
  const ok = failed.length === 0;
  const isManualDone = job.reason === 'manual';
  const doneTitle = ok
    ? (isManualDone ? 'Konten Berhasil Dihapus' : 'Konten Premium Berhasil Dihapus')
    : 'Penghapusan Selesai (Sebagian Gagal)';
  const doneQualifier = isManualDone ? '' : ' premium';

  overlay.innerHTML = `
    <div class="pcm-modal">
      <div class="pcm-icon ${ok ? 'pcm-icon--ok' : 'pcm-icon--partial'}">${ok ? '<svg class="icon icon-16"><use href="#ic-circle-check-big"></use></svg>' : '<svg class="icon icon-16"><use href="#ic-triangle-alert"></use></svg>'}</div>
      <div class="pcm-title">${doneTitle}</div>
      <div class="pcm-desc">
        <b>${removedGames.length}</b> game dan <b>${removedBypass.length}</b> bypass${doneQualifier} sudah dihapus dari PC ini.
        ${failed.length ? `<br><span style="color:#ffb4b4;">${failed.length} item gagal dihapus otomatis — cek folder Steam/game secara manual kalau perlu.</span>` : ''}
      </div>
      <div class="pcm-actions">
        ${resultData?.needRestartSteam ? `<button class="pcm-btn pcm-btn--ghost" id="pcmRestartSteamBtn"><svg class="icon icon-18"><use href="#ic-refresh-cw"></use></svg> Restart Steam</button>` : ''}
        <button class="pcm-btn pcm-btn--primary" id="pcmUpgradeBtn"><svg class="icon icon-18"><use href="#ic-shopping-cart"></use></svg> Perpanjang / Beli Paket</button>
      </div>
      <button class="pcm-close" id="pcmCloseBtn">Tutup</button>
    </div>`;

  document.getElementById('pcmUpgradeBtn')?.addEventListener('click', () => {
    closePremiumCleanupModal();
    showPage('store');
  });
  document.getElementById('pcmCloseBtn')?.addEventListener('click', closePremiumCleanupModal);
  document.getElementById('pcmRestartSteamBtn')?.addEventListener('click', async () => {
    const steamPath = await window.electronAPI.getSteamPath();
    if (steamPath) await window.electronAPI.restartSteam(steamPath);
  });
}

function closePremiumCleanupModal() {
  const overlay = document.getElementById('premiumCleanupOverlay');
  if (overlay) overlay.style.display = 'none';
}


const PKG_UNIT_LABEL = { minutes: 'menit', hours: 'jam', days: 'hari' };
function renderPackageCard(user) {
  const status = user?.accountStatus;
  const badgeEl = document.getElementById('pkgBadge');
  const badgeTextEl = document.getElementById('pkgBadgeText');
  const periodBlock = document.getElementById('pkgPeriodBlock');
  const numEl = document.getElementById('pkgPeriodNumber');
  const unitEl = document.getElementById('pkgPeriodUnit');
  const untilEl = document.getElementById('pkgPeriodUntil');
  const fillEl = document.getElementById('pkgProgressFill');
  const upgradeBtn = document.getElementById('pkgUpgradeBtn');
  if (!badgeEl || !status) return;

  const ROLE_LABEL = { public: 'Public', gold: 'Gold Aktif', platinum: 'Platinum Aktif', admin: 'Admin' };
  badgeEl.className = `pkg-badge ${user.role}`;
  badgeTextEl.innerHTML = ROLE_LABEL[user.role] || user.role;

  if (status.hasActivePeriod) {
    periodBlock.style.display = '';
    if (status.activeUntil) {
      const msLeft = Math.max(0, new Date(status.activeUntil).getTime() - Date.now());
      const daysLeft = msLeft / 86400000;
      let value, unit;
      if (daysLeft >= 1) { value = Math.ceil(daysLeft); unit = 'hari'; }
      else if (msLeft >= 3600000) { value = Math.ceil(msLeft / 3600000); unit = 'jam'; }
      else { value = Math.max(0, Math.ceil(msLeft / 60000)); unit = 'menit'; }

      numEl.textContent = value;
      unitEl.textContent = unit;
      untilEl.textContent = 'aktif s/d ' + new Date(status.activeUntil).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' });

      // Progress bar: dianggap penuh di 30 hari, makin sedikit makin merah
      const pct = Math.max(4, Math.min(100, Math.round((msLeft / (30 * 86400000)) * 100)));
      fillEl.style.width = pct + '%';
      fillEl.className = 'pkg-progress-fill' + (daysLeft <= 1 ? ' danger' : daysLeft <= 3 ? ' warn' : '');
    } else {
      numEl.textContent = '∞'; unitEl.textContent = ''; untilEl.textContent = 'Belum ada batas waktu';
      fillEl.style.width = '100%'; fillEl.className = 'pkg-progress-fill';
    }
  } else {
    periodBlock.style.display = 'none';
  }

  const setQuota = (elId, q) => {
    const el = document.getElementById(elId);
    if (!el) return;
    if (!q || q.unlimited) { el.textContent = 'Unlimited'; el.className = 'pkg-quota-value unlimited'; return; }
    el.textContent = `${q.remaining}/${q.limit}`;
    el.className = 'pkg-quota-value' + (q.remaining === 0 ? ' empty' : q.remaining <= 1 ? ' low' : '');
  };
  setQuota('pkgQuotaGame', status.download?.game);
  setQuota('pkgQuotaBypass', status.download?.bypass);

  if (upgradeBtn) {
    upgradeBtn.style.display = (user.role === 'platinum') ? 'none' : '';
  }
}

function wirePackageCard() {
  document.getElementById('pkgUpgradeBtn')?.addEventListener('click', () => {
    showPage('store');
  });
}

// ── CLAIM VOUCHER ──
// Server (POST /api/voucher/claim) yang melakukan seluruh validasi (kode valid,
// expired, kuota, sudah pernah diklaim) + update role/masa aktif user. Di sini
// cuma kirim kode & tampilkan hasilnya — update role/limit/paket di sidebar
// otomatis realtime lewat WS 'account:update' yang sudah ditangani handleAccountUpdate().
function wireVoucherClaim() {
  const input = document.getElementById('voucherCodeInput');
  const btn = document.getElementById('btnClaimVoucher');
  const resultEl = document.getElementById('voucherClaimResult');
  if (!input || !btn) return;

  const doClaim = async () => {
    const code = input.value.trim();
    if (!code) {
      resultEl.style.display = 'block';
      resultEl.className = 'voucher-claim-result error';
      resultEl.textContent = 'Masukkan kode voucher dulu.';
      return;
    }
    btn.disabled = true;
    const originalText = btn.textContent;
    btn.textContent = 'Memproses...';
    resultEl.style.display = 'none';
    try {
      const data = await api('/api/voucher/claim', { method: 'POST', body: JSON.stringify({ code }) });
      resultEl.style.display = 'block';
      resultEl.className = 'voucher-claim-result success';
      resultEl.innerHTML = `<svg class="icon icon-16"><use href="#ic-party-popper"></use></svg> Voucher berhasil diklaim! Paket ${data.role.toUpperCase()} kamu ${data.extended ? 'diperpanjang' : 'aktif'} ${data.durationLabel}.`;
      input.value = '';
    } catch (e) {
      resultEl.style.display = 'block';
      resultEl.className = 'voucher-claim-result error';
      resultEl.innerHTML = '<svg class="icon icon-16"><use href="#ic-triangle-alert"></use></svg> ' + (e.message || 'Gagal claim voucher, coba lagi.');
    } finally {
      btn.disabled = false;
      btn.textContent = originalText;
    }
  };

  btn.addEventListener('click', doClaim);
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); doClaim(); } });
  input.addEventListener('input', () => { input.value = input.value.toUpperCase(); });
}

// ══════════════════════════════════════════════════════════════════════════
// WELCOME POPUP — popup otomatis untuk user baru, tampil SEKALI PER AKUN
// (bukan cuma per sesi login seperti Gold Trial). Server yang menentukan
// tampil/tidaknya lewat GET /api/welcome-popup (dicek terhadap
// welcomePopupSeenVersion di akun user vs version config saat ini di DB) —
// jadi tidak bisa "diakalin" dengan clear data lokal App. Konten (judul,
// deskripsi, banner, daftar info, teks tombol) 100% dinamis dari Admin Web.
// `_welcomePopupCheckedThisSession` cukup mencegah pengecekan dobel dalam
// satu sesi App yang sama (mis. kalau enterApp() sempat terpanggil ulang).
// ══════════════════════════════════════════════════════════════════════════
let _welcomePopupCheckedThisSession = false;

async function checkWelcomePopup() {
  if (_welcomePopupCheckedThisSession) return;
  _welcomePopupCheckedThisSession = true;
  try {
    const res = await api('/api/welcome-popup');
    if (res && res.show && res.popup) {
      renderWelcomePopup(res.popup);
      openWelcomePopup();
    }
  } catch (e) {
    // Diam-diam gagal — Welcome Popup murni informatif, jangan sampai error
    // di sini mengganggu proses login/masuk ke Dashboard.
  }
}

function renderWelcomePopup(popup) {
  const bannerEl = document.getElementById('welcomePopupBanner');
  if (popup.bannerUrl) {
    bannerEl.src = popup.bannerUrl;
    bannerEl.style.display = '';
  } else {
    bannerEl.style.display = 'none';
  }

  document.getElementById('welcomePopupTitle').textContent = popup.title || '👋 Selamat Datang di 31 Store!';

  const descEl = document.getElementById('welcomePopupDesc');
  if (popup.description) {
    descEl.textContent = popup.description;
    descEl.style.display = '';
  } else {
    descEl.style.display = 'none';
  }

  const itemsEl = document.getElementById('welcomePopupItems');
  itemsEl.innerHTML = (popup.items || []).map(item => `<li>${escapeHtmlWp(item)}</li>`).join('');

  document.getElementById('welcomePopupPrimaryBtn').textContent = popup.primaryButtonText || 'Mulai Sekarang';
  document.getElementById('welcomePopupSecondaryBtn').textContent = popup.secondaryButtonText || 'Jangan Tampilkan Lagi';
}

// Helper escape kecil khusus di sini (item popup dari Admin Web tetap teks
// biasa, bukan HTML, jadi wajib di-escape sebelum dimasukkan ke innerHTML).
function escapeHtmlWp(str) {
  return String(str || '').replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

function openWelcomePopup() {
  document.getElementById('welcomePopupBackdrop').style.display = 'flex';
}

function closeWelcomePopup() {
  document.getElementById('welcomePopupBackdrop').style.display = 'none';
}

// Baik "Mulai Sekarang" maupun "Jangan Tampilkan Lagi" sama-sama menutup
// popup DAN menandainya sudah dilihat (supaya tidak muncul lagi buat akun
// ini) — dikirim best-effort, popup tetap ditutup di App walau request ini
// sempat gagal (tidak boleh mengganggu penggunaan App).
async function dismissWelcomePopup() {
  closeWelcomePopup();
  try {
    await api('/api/welcome-popup/seen', { method: 'POST' });
  } catch (e) {
    // Diam-diam gagal — paling buruk popup ini muncul lagi login berikutnya.
  }
}

document.getElementById('welcomePopupPrimaryBtn')?.addEventListener('click', dismissWelcomePopup);
document.getElementById('welcomePopupSecondaryBtn')?.addEventListener('click', dismissWelcomePopup);

// ══════════════════════════════════════════════════════════════════════════
// GOLD TRIAL — popup otomatis SEKALI sesudah login (bukan lagi banner Dashboard
// atau halaman terpisah). Dicek via GET /api/gold-trial (server yang menentukan
// eligible/tidak sepenuhnya); kalau eligible & belum pernah klaim, popup tampil
// dengan ringkasan durasi + limit download dan tombol "Klaim Sekarang"/"Nanti".
// `_goldTrialPopupShownThisSession` memastikan popup ini CUMA muncul sekali per
// sesi login (tidak muncul lagi tiap ganti halaman/tiap account:update masuk).
// ══════════════════════════════════════════════════════════════════════════
let _goldTrialPopupShownThisSession = false;

function gtLimitText(v) { return (v === null || v === undefined) ? 'Unlimited' : `${v}x/hari`; }

// Dipanggil SEKALI tiap kali enterApp() sukses (lihat pemanggilannya di atas).
// Kalau user tidak eligible / sudah pernah klaim -> tidak melakukan apa-apa
// (tidak ada popup, tidak ada efek samping lain).
async function checkGoldTrialOffer() {
  if (_goldTrialPopupShownThisSession) return;
  try {
    const s = await api('/api/gold-trial');
    if (s && s.eligible && s.offer) {
      openGoldTrialModal();
      renderGoldTrialOfferState(s.offer);
      _goldTrialPopupShownThisSession = true;
    }
  } catch (e) {
    // Diam-diam gagal — Gold Trial murni bonus opsional, jangan sampai error di sini
    // mengganggu proses login/masuk ke Dashboard.
  }
}

function openGoldTrialModal() {
  document.getElementById('goldTrialBackdrop').style.display = 'flex';
}
function closeGoldTrialModal() {
  document.getElementById('goldTrialBackdrop').style.display = 'none';
}
window.closeGoldTrialModal = closeGoldTrialModal;

function renderGoldTrialOfferState(offer) {
  document.getElementById('goldTrialModalTitle').textContent = 'Gold Trial Gratis Tersedia! 🎉';
  document.getElementById('goldTrialCloseBtn').style.display = '';
  document.getElementById('goldTrialModalBody').innerHTML = `
    <div class="access-required-icon"><svg class="icon icon-32"><use href="#ic-star"></use></svg></div>
    <div class="access-required-text">Kamu member baru di Discord Server kami — klaim paket <b>Gold gratis</b> sekarang, cuma bisa <b>1x per akun</b>.</div>
    <div class="access-required-need">Durasi Trial: <b>${escapeHtml(offer.durationLabel)}</b></div>
    <div class="access-required-need">Limit Download: <b>${gtLimitText(offer.gameLimit)}</b> Game &middot; <b>${gtLimitText(offer.bypassLimit)}</b> Bypass</div>
    <div style="display:flex;gap:8px;width:100%;margin-top:6px;">
      <button class="btn-secondary" id="btnGoldTrialLater" style="flex:1;">Nanti</button>
      <button class="btn-primary" id="btnGoldTrialClaim" style="flex:1;">Klaim Sekarang</button>
    </div>
  `;
  document.getElementById('btnGoldTrialLater').addEventListener('click', closeGoldTrialModal);
  document.getElementById('btnGoldTrialClaim').addEventListener('click', doClaimGoldTrial);
}

function renderGoldTrialLoadingState() {
  document.getElementById('goldTrialModalTitle').textContent = 'Memproses Klaim...';
  document.getElementById('goldTrialCloseBtn').style.display = 'none'; // cegah ditutup di tengah proses
  document.getElementById('goldTrialModalBody').innerHTML = `
    <div class="access-required-icon"><svg class="icon icon-32"><use href="#ic-loader-circle"></use></svg></div>
    <div class="access-required-text">Sedang mengaktifkan Gold Trial kamu, mohon tunggu sebentar...</div>
  `;
}

function renderGoldTrialResultState({ success, title, text }) {
  document.getElementById('goldTrialModalTitle').textContent = title;
  document.getElementById('goldTrialCloseBtn').style.display = '';
  document.getElementById('goldTrialModalBody').innerHTML = `
    <div class="access-required-icon"><svg class="icon icon-32"><use href="#${success ? 'ic-party-popper' : 'ic-triangle-alert'}"></use></svg></div>
    <div class="access-required-text">${escapeHtml(text)}</div>
    <button class="btn-primary" id="btnGoldTrialCloseResult" style="width:100%;margin-top:6px;">Oke, Mengerti</button>
  `;
  document.getElementById('btnGoldTrialCloseResult').addEventListener('click', closeGoldTrialModal);
}

async function doClaimGoldTrial() {
  renderGoldTrialLoadingState();
  try {
    const data = await api('/api/gold-trial/claim', { method: 'POST' });
    renderGoldTrialResultState({
      success: true,
      title: 'Gold Trial Aktif! 🎉',
      text: data.message || `Gold Trial kamu berhasil diaktifkan selama ${data.durationLabel}.`
    });
    // Role/masa aktif/limit user berubah -> refresh pkg-badge & progress di
    // Dashboard TANPA perlu reload app (account:update WS juga akan menyusul).
    await refreshCurrentUserRole();
  } catch (e) {
    renderGoldTrialResultState({
      success: false,
      title: 'Gagal Klaim Gold Trial',
      text: e.message || 'Terjadi kesalahan, coba lagi nanti.'
    });
  }
}

// ── NOTIFICATION BELL ──
let _notifUnread = 0;
function setNotifUnreadCount(n) {
  _notifUnread = n || 0;
  const dot = document.getElementById('notifDot');
  if (!dot) return;
  if (_notifUnread <= 0) { dot.style.display = 'none'; return; }
  dot.style.display = 'flex';
  dot.className = 'dot count';
  dot.textContent = _notifUnread > 9 ? '9+' : String(_notifUnread);
}

async function loadNotifications() {
  const listEl = document.getElementById('notifList');
  if (!listEl) return;
  try {
    const data = await api('/api/notifications?limit=30');
    setNotifUnreadCount(data.unread);
    if (!data.items || data.items.length === 0) {
      listEl.innerHTML = '<div class="notif-empty">Belum ada notifikasi.</div>';
      return;
    }
    listEl.innerHTML = data.items.map(notifItemHtml).join('');
    listEl.querySelectorAll('.notif-item').forEach(itemEl => {
      itemEl.addEventListener('click', async () => {
        const id = itemEl.dataset.id;
        if (itemEl.classList.contains('unread')) {
          itemEl.classList.remove('unread');
          try { await api(`/api/notifications/${id}/read`, { method: 'PUT' }); } catch (e) {}
          setNotifUnreadCount(Math.max(0, _notifUnread - 1));
        }
      });
    });
  } catch (e) {
    listEl.innerHTML = '<div class="notif-empty">Gagal memuat notifikasi.</div>';
  }
}

const NOTIF_ICON = {
  download_success: '<svg class="icon icon-16"><use href="#ic-circle-check-big"></use></svg>', download_failed: '<svg class="icon icon-16"><use href="#ic-circle-x"></use></svg>', quota_low: '<svg class="icon icon-16"><use href="#ic-triangle-alert"></use></svg>',
  quota_empty: '<svg class="icon icon-16"><use href="#ic-ban"></use></svg>', period_low: '<svg class="icon icon-16"><use href="#ic-loader-circle"></use></svg>', period_expired: '<svg class="icon icon-16"><use href="#ic-ban"></use></svg>',
  renewal: '<svg class="icon icon-16"><use href="#ic-refresh-cw"></use></svg>', announcement: '<svg class="icon icon-16"><use href="#ic-megaphone"></use></svg>'
};
function notifItemHtml(n) {
  const icon = NOTIF_ICON[n.type] || '<svg class="icon icon-16"><use href="#ic-bell"></use></svg>';
  return `<div class="notif-item ${n.read ? '' : 'unread'}" data-id="${n._id}">
    <span class="ni-icon">${icon}</span>
    <div>
      <div class="ni-title">${escapeHtml(n.title)}</div>
      <div class="ni-msg">${escapeHtml(n.message)}</div>
      <div class="ni-time">${timeAgo(n.createdAt)}</div>
    </div>
  </div>`;
}

function wireNotifBell() {
  const bell = document.getElementById('notifBell');
  const dropdown = document.getElementById('notifDropdown');
  if (!bell || !dropdown) return;

  bell.addEventListener('click', (e) => {
    e.stopPropagation();
    const willOpen = !dropdown.classList.contains('open');
    dropdown.classList.toggle('open', willOpen);
    if (willOpen) loadNotifications();
  });
  document.addEventListener('click', (e) => {
    if (!bell.contains(e.target)) dropdown.classList.remove('open');
  });
  document.getElementById('notifMarkAllRead')?.addEventListener('click', async (e) => {
    e.stopPropagation();
    try { await api('/api/notifications/read-all', { method: 'PUT' }); } catch (er) {}
    setNotifUnreadCount(0);
    document.querySelectorAll('.notif-item.unread').forEach(el => el.classList.remove('unread'));
  });
}

// Notifikasi baru dari WS: update badge, refresh list kalau dropdown lagi kebuka,
// dan tampilkan toast kecil di pojok kanan-atas.
function handleIncomingNotification(n) {
  _notifUnread += 1;
  setNotifUnreadCount(_notifUnread);
  const dropdown = document.getElementById('notifDropdown');
  if (dropdown?.classList.contains('open')) loadNotifications();
  showAppNotifToast(n);

  // Notifikasi terkait limit/masa aktif langsung dampaknya ke kartu paket —
  // minta data akun terbaru biar kartu ikut ter-update tanpa nunggu polling.
  if (['quota_low', 'quota_empty', 'period_low', 'period_expired'].includes(n.type)) {
    api('/api/me').then(fresh => { if (fresh) { currentUser = { ...currentUser, ...fresh }; renderPackageCard(currentUser); } }).catch(() => {});
  }
}

function showAppNotifToast(n) {
  let el = document.querySelector('.app-notif-toast');
  if (!el) { el = document.createElement('div'); el.className = 'app-notif-toast'; document.body.appendChild(el); }
  const icon = NOTIF_ICON[n.type] || '<svg class="icon icon-16"><use href="#ic-bell"></use></svg>';
  el.innerHTML = `<span class="ant-icon">${icon}</span><div><div class="ant-title">${escapeHtml(n.title)}</div><div class="ant-msg">${escapeHtml(n.message)}</div></div>`;

  el.classList.remove('show');
  // Buang & paksa reflow dulu sebelum nambah 'show' lagi, supaya kalau toast
  // sebelumnya baru saja ditutup (atau masih kebuka), animasi slide-in-nya tetap
  // jalan bersih dari awal, bukan cuma diem di posisi lama.
  void el.offsetWidth;
  requestAnimationFrame(() => el.classList.add('show'));

  // Selalu hilang otomatis tepat 4 detik setelah muncul (lihat scheduleToastAutoHide).
  scheduleToastAutoHide(el, 'show');
}

function showRoleUpdateToast(oldRole, newRole) {
  let toastEl = document.querySelector('.role-update-toast');
  if (!toastEl) {
    toastEl = document.createElement('div');
    toastEl.className = 'role-update-toast';
    document.body.appendChild(toastEl);
  }

  const icon      = ROLE_BADGE_ICON[newRole] || '<svg class="icon icon-16"><use href="#ic-globe"></use></svg>';
  const upgraded  = (CLIENT_ROLE_LEVEL[newRole] ?? 0) > (CLIENT_ROLE_LEVEL[oldRole] ?? 0);
  const downgraded = (CLIENT_ROLE_LEVEL[newRole] ?? 0) < (CLIENT_ROLE_LEVEL[oldRole] ?? 0);
  const headerIcon = upgraded ? '<svg class="icon icon-16"><use href="#ic-party-popper"></use></svg>' : downgraded ? '<svg class="icon icon-16"><use href="#ic-package"></use></svg>' : '<svg class="icon icon-16"><use href="#ic-refresh-cw"></use></svg>';
  const oldIcon   = ROLE_BADGE_ICON[oldRole] || '<svg class="icon icon-16"><use href="#ic-globe"></use></svg>';

  toastEl.className = `role-update-toast show ${newRole}`;
  toastEl.innerHTML = `
    <div class="rut-header">
      <span class="rut-header-icon">${headerIcon}</span>
      <span class="rut-header-title">Paket Diperbarui!</span>
      <button class="rut-close" onclick="this.closest('.role-update-toast').classList.remove('show')">×</button>
    </div>
    <div class="rut-body">
      <div class="rut-change-row">
        <span class="rut-role-old">${oldIcon} ${ROLE_TOAST_LABEL[oldRole] || oldRole}</span>
        <span class="rut-arrow"><svg class="icon icon-18"><use href="#ic-arrow-right"></use></svg></span>
        <span class="rut-role-new ${newRole}">${icon} ${ROLE_TOAST_LABEL[newRole] || newRole}</span>
      </div>
      <div class="rut-desc">${ROLE_TOAST_DESC[newRole] || ''}</div>
    </div>
  `;
  scheduleToastAutoHide(toastEl, 'show');
}

// ── CONFIG ──
let _appConfig = {};
async function loadConfig() {
  try {
    const res = await fetch(SERVER_URL + '/api/config');
    const cfg = await res.json();
    _appConfig = cfg || {};
    document.title = cfg.appName;
    const nameEl = document.getElementById('nvLoginAppName');
    if (nameEl) nameEl.textContent = cfg.appName;
    const tbTitle = document.querySelector('.titlebar-title');
    if (tbTitle) tbTitle.textContent = cfg.appName;
  } catch (e) {}
}

// ── START ──
// ══════════════════════════════════════════════════════════════════════════
// EDIT PROFIL (halaman Setting) — Foto Profil App, Display Name, Username, Bio.
// PENTING: ini SEPENUHNYA terpisah dari data Discord (card "Steam & Discord
// Detection" di bawah) — mengedit profil di sini TIDAK PERNAH mengubah akun
// Discord user. Perubahan langsung diterapkan realtime ke sidebar/topbar
// TANPA perlu restart app (lihat applyProfileToUI() & handleAccountUpdate()).
// ══════════════════════════════════════════════════════════════════════════
const EP_USERNAME_RE = /^[a-z][a-z0-9_]{2,19}$/;
let _epBaseline = null;   // { displayName, username, bio } terakhir tersimpan di server
let _epPendingPhotoBase64 = null; // data URL foto baru yang belum disimpan (kalau ada)
let _epSaving = false;

function wireEditProfile() {
  const photoInput = document.getElementById('epPhotoInput');
  document.getElementById('epAvatarWrap')?.addEventListener('click', () => photoInput?.click());
  document.getElementById('epPhotoBtn')?.addEventListener('click', () => photoInput?.click());
  photoInput?.addEventListener('change', (e) => handleEpPhotoSelected(e.target.files?.[0]));

  document.getElementById('epDisplayName')?.addEventListener('input', () => { validateEpDisplayName(); updateEpDirtyState(); });
  document.getElementById('epUsername')?.addEventListener('input', (e) => {
    // Paksa lowercase & buang karakter ilegal langsung saat mengetik, jadi user
    // tidak perlu menebak-nebak format yang diterima.
    const cleaned = e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 20);
    if (cleaned !== e.target.value) e.target.value = cleaned;
    validateEpUsername();
    updateEpDirtyState();
  });
  document.getElementById('epBio')?.addEventListener('input', () => { validateEpBio(); updateEpDirtyState(); });

  document.getElementById('epSaveBtn')?.addEventListener('click', saveEditProfile);
}

async function loadEditProfileForm() {
  try {
    const data = await api('/api/profile');
    _epBaseline = {
      displayName: data.app.displayName || '',
      username: data.app.username || '',
      bio: data.app.bio || ''
    };
    _epPendingPhotoBase64 = null;

    const nameEl = document.getElementById('epDisplayName');
    const userEl = document.getElementById('epUsername');
    const bioEl  = document.getElementById('epBio');
    const avatarEl = document.getElementById('epAvatarPreview');

    if (nameEl) nameEl.value = _epBaseline.displayName;
    if (userEl) userEl.value = _epBaseline.username;
    if (bioEl)  bioEl.value  = _epBaseline.bio;
    if (avatarEl) avatarEl.src = data.app.photoUrl || data.discord.avatarUrl || currentUser?.avatarUrl || '';

    updateEpBioCount();
    clearEpFieldMessages();
    updateEpDirtyState();
  } catch (e) {
    showHistoriToast('Gagal memuat data profil: ' + e.message);
  }
}

function updateEpBioCount() {
  const bioEl = document.getElementById('epBio');
  const countEl = document.getElementById('epBioCount');
  if (bioEl && countEl) countEl.textContent = String(bioEl.value.length);
}

function clearEpFieldMessages() {
  ['epDisplayNameMsg', 'epUsernameMsg'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.classList.remove('is-error', 'is-ok');
  });
  document.getElementById('epDisplayName')?.classList.remove('is-invalid');
  document.getElementById('epUsername')?.classList.remove('is-invalid');
}

function validateEpDisplayName() {
  const el = document.getElementById('epDisplayName');
  const msgEl = document.getElementById('epDisplayNameMsg');
  if (!el || !msgEl) return true;
  const v = el.value.trim();
  let err = '';
  if (v.length < 2) err = 'Minimal 2 karakter.';
  else if (v.length > 32) err = 'Maksimal 32 karakter.';
  msgEl.textContent = err;
  msgEl.classList.toggle('is-error', !!err);
  el.classList.toggle('is-invalid', !!err);
  return !err;
}

function validateEpUsername() {
  const el = document.getElementById('epUsername');
  const msgEl = document.getElementById('epUsernameMsg');
  if (!el || !msgEl) return true;
  const v = el.value.trim();
  let err = '';
  if (!v) err = ''; // username boleh dikosongkan (belum pernah diset)
  else if (!EP_USERNAME_RE.test(v)) err = '3-20 karakter, huruf kecil/angka/underscore, wajib diawali huruf.';
  msgEl.textContent = err || '3-20 karakter, huruf kecil/angka/underscore, wajib diawali huruf.';
  msgEl.classList.toggle('is-error', !!err);
  el.classList.toggle('is-invalid', !!err);
  return !err;
}

function validateEpBio() {
  updateEpBioCount();
  const el = document.getElementById('epBio');
  if (!el) return true;
  return el.value.length <= 160;
}

function handleEpPhotoSelected(file) {
  if (!file) return;
  const ALLOWED = ['image/png', 'image/jpeg', 'image/jpg', 'image/webp'];
  if (!ALLOWED.includes(file.type)) {
    showHistoriToast('Format foto harus PNG, JPG, atau WEBP.');
    return;
  }
  if (file.size > 3 * 1024 * 1024) {
    showHistoriToast('Ukuran foto maksimal 3MB.');
    return;
  }
  const reader = new FileReader();
  reader.onload = () => {
    _epPendingPhotoBase64 = reader.result; // data URL, siap dikirim ke server
    const avatarEl = document.getElementById('epAvatarPreview');
    if (avatarEl) avatarEl.src = reader.result; // preview instan sebelum disimpan
    updateEpDirtyState();
  };
  reader.onerror = () => showHistoriToast('Gagal membaca file foto.');
  reader.readAsDataURL(file);
}

function updateEpDirtyState() {
  const saveBtn = document.getElementById('epSaveBtn');
  if (!saveBtn || !_epBaseline) return;

  const nameEl = document.getElementById('epDisplayName');
  const userEl = document.getElementById('epUsername');
  const bioEl  = document.getElementById('epBio');

  const isDirty =
    !!_epPendingPhotoBase64 ||
    (nameEl && nameEl.value.trim() !== _epBaseline.displayName) ||
    (userEl && userEl.value.trim() !== _epBaseline.username) ||
    (bioEl && bioEl.value !== _epBaseline.bio);

  const isValid = validateEpDisplayName() && validateEpUsername() && validateEpBio();

  saveBtn.disabled = !isDirty || !isValid || _epSaving;
}

function setEpSaving(saving) {
  _epSaving = saving;
  const saveBtn = document.getElementById('epSaveBtn');
  const textEl = document.getElementById('epSaveBtnText');
  const photoBtn = document.getElementById('epPhotoBtn');
  if (!saveBtn) return;
  saveBtn.classList.toggle('is-loading', saving);
  if (photoBtn) photoBtn.disabled = saving;
  if (textEl) {
    textEl.innerHTML = saving ? `<span class="ep-spinner"></span> Menyimpan...` : 'Simpan Perubahan';
  }
  if (saving) saveBtn.disabled = true; else updateEpDirtyState();
}

async function saveEditProfile() {
  if (_epSaving || !_epBaseline) return;
  if (!validateEpDisplayName() || !validateEpUsername() || !validateEpBio()) return;

  const nameEl = document.getElementById('epDisplayName');
  const userEl = document.getElementById('epUsername');
  const bioEl  = document.getElementById('epBio');

  setEpSaving(true);
  try {
    // Foto disimpan lewat endpoint terpisah (bisa dikirim sendiri tanpa field lain).
    if (_epPendingPhotoBase64) {
      await api('/api/profile/photo', { method: 'POST', body: JSON.stringify({ imageBase64: _epPendingPhotoBase64 }) });
      _epPendingPhotoBase64 = null;
    }

    const patch = {};
    if (nameEl && nameEl.value.trim() !== _epBaseline.displayName) patch.displayName = nameEl.value.trim();
    if (userEl && userEl.value.trim() !== _epBaseline.username && userEl.value.trim()) patch.username = userEl.value.trim();
    if (bioEl && bioEl.value !== _epBaseline.bio) patch.bio = bioEl.value;

    let fresh = null;
    if (Object.keys(patch).length) {
      fresh = await api('/api/profile', { method: 'PUT', body: JSON.stringify(patch) });
    } else {
      fresh = await api('/api/profile');
    }

    _epBaseline = {
      displayName: fresh.app.displayName || '',
      username: fresh.app.username || '',
      bio: fresh.app.bio || ''
    };

    // Terapkan langsung ke seluruh App (sidebar, topbar) tanpa perlu restart —
    // event 'account:update' dari server (lihat handleAccountUpdate()) juga akan
    // menyusul untuk device lain yang sedang login dengan akun yang sama.
    applyProfileToUI({ username: fresh.app.displayName || currentUser?.username, avatarUrl: fresh.app.photoUrl || currentUser?.avatarUrl });

    showHistoriToast('Profil berhasil disimpan!');
    updateEpDirtyState();
  } catch (e) {
    showHistoriToast('Gagal menyimpan profil: ' + e.message);
  } finally {
    setEpSaving(false);
  }
}

// Terapkan nama/foto terbaru ke SEMUA tempat currentUser sudah ditampilkan di App
// (sidebar, topbar) — dipanggil baik setelah simpan sendiri MAUPUN saat menerima
// event realtime 'account:update' (mis. diedit dari device lain).
function applyProfileToUI({ username, avatarUrl }) {
  if (!currentUser) return;
  if (username) currentUser.username = username;
  if (avatarUrl) currentUser.avatarUrl = avatarUrl;
  _saveUser(currentUser);

  if (els.profileImg && avatarUrl) els.profileImg.src = avatarUrl;
  if (els.profileName && username) {
    els.profileName.textContent = username;
    els.profileName.title = username;
  }
  if (els.topbarH2 && username) els.topbarH2.textContent = `Have a good time ${username}!`;
}

// ══════════════════════════════════════════════════════════════════════════
// STEAM & DISCORD DETECTION (halaman Setting)
// ══════════════════════════════════════════════════════════════════════════
let _sysdetData = null;
let _sysdetLoading = false;

function wireSystemDetection() {
  document.getElementById('btnSysdetRefresh')?.addEventListener('click', () => loadSystemDetection());
  document.getElementById('btnOpenSteamFolder')?.addEventListener('click', () => openSysdetFolder(_sysdetData?.steam?.location));
  document.getElementById('btnOpenLibraryFolder')?.addEventListener('click', () => openSysdetFolder(_sysdetData?.steam?.libraries?.[0]?.path));

  // Realtime: main process cuma kirim event ini kalau status Running/Closed BENERAN
  // berubah — jadi tinggal tempel ke 2 pill status, TANPA re-render seluruh card
  // (biar tidak "berkedip"/reload berlebihan kalau user lagi buka halaman ini).
  if (window.electronAPI?.onSystemDetectionStatus) {
    window.electronAPI.onSystemDetectionStatus((data) => {
      if (_sysdetData) {
        if (data.steam)   _sysdetData.steam.status   = data.steam.status;
        if (data.discord) _sysdetData.discord.status = data.discord.status;
      }
      patchSysdetStatusPills(data);
    });
  }
}

async function loadSystemDetection() {
  if (_sysdetLoading) return; // cegah request dobel kalau user spam klik Refresh
  if (!window.electronAPI?.getSystemDetection) return; // browser context tanpa Electron — skip diam-diam

  _sysdetLoading = true;
  const btn = document.getElementById('btnSysdetRefresh');
  btn?.classList.add('spinning');
  const subEl = document.getElementById('sysdetLastChecked');
  if (subEl && !_sysdetData) subEl.textContent = 'Mendeteksi Steam & Discord...';

  try {
    const data = await window.electronAPI.getSystemDetection();
    _sysdetData = data;
    renderSystemDetection();
  } catch (e) {
    if (subEl) subEl.textContent = 'Gagal memuat data: ' + e.message;
  } finally {
    _sysdetLoading = false;
    btn?.classList.remove('spinning');
  }
}

function openSysdetFolder(folderPath) {
  if (!folderPath) { showHistoriToast('Folder belum terdeteksi.'); return; }
  window.electronAPI?.openFolder(folderPath).then(res => {
    if (!res?.success) showHistoriToast(res?.error || 'Gagal membuka folder.');
  });
}

function patchSysdetStatusPills(data) {
  if (data.steam) {
    const el = document.getElementById('sysdetSteamStatus');
    if (el) {
      el.textContent = data.steam.status === 'running' ? 'Running' : 'Closed';
      el.className = 'sysdet-status-pill ' + (data.steam.status === 'running' ? 'running' : 'closed');
    }
  }
  if (data.discord) {
    const el = document.getElementById('sysdetDiscordStatus');
    if (el) {
      el.textContent = data.discord.status === 'running' ? 'Running' : 'Closed';
      el.className = 'sysdet-status-pill ' + (data.discord.status === 'running' ? 'running' : 'closed');
    }
  }
}

function formatSysdetBytes(bytes) {
  if (!bytes && bytes !== 0) return '';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0, n = bytes;
  while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
  return `${n.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}

function renderSystemDetection() {
  const d = _sysdetData;
  if (!d) return;
  const { steam, discord } = d;

  document.getElementById('sysdetLastChecked').textContent =
    'Terakhir dicek: ' + new Date(d.checkedAt).toLocaleTimeString('id-ID');

  // ── Steam ──
  patchSysdetStatusPills({ steam, discord });
  document.getElementById('sysdetSteamAccount').textContent =
    steam.accountName ? steam.accountName + (steam.isConfirmedActive ? '' : ' (terakhir login)') : (steam.installed ? 'Tidak ada akun tersimpan' : '—');
  document.getElementById('sysdetSteamId').textContent = steam.steamId || '—';
  document.getElementById('sysdetSteamLocation').textContent = steam.location || 'Steam tidak terdeteksi';
  document.getElementById('sysdetSteamLibraryCount').textContent = steam.libraryCount ? `${steam.libraryCount} folder` : '—';
  document.getElementById('sysdetSteamGameCount').textContent = steam.installedGameCount != null ? `${steam.installedGameCount} game` : '—';

  const libListEl = document.getElementById('sysdetLibraryList');
  if (steam.libraries?.length) {
    libListEl.innerHTML = steam.libraries.map(lib => `
      <div class="sysdet-library-item">
        <span class="sysdet-library-path" title="${escapeHtml(lib.path)}">${escapeHtml(lib.path)}</span>
        <span class="sysdet-library-count">${lib.gameCount} game</span>
        <button class="sysdet-library-open" data-lib-open="${escapeHtml(lib.path)}" title="Buka folder ini"><svg class="icon icon-18"><use href="#ic-folder"></use></svg></button>
      </div>`).join('');
    libListEl.querySelectorAll('[data-lib-open]').forEach(btn => {
      btn.addEventListener('click', () => openSysdetFolder(btn.dataset.libOpen));
    });
  } else {
    libListEl.innerHTML = '';
  }

  document.getElementById('btnOpenSteamFolder').disabled = !steam.location;
  document.getElementById('btnOpenLibraryFolder').disabled = !steam.libraries?.length;

  // ── Discord ── Info akun dari sesi login (server), BUKAN dari file lokal Discord.
  const dUsername = currentUser?.discordUsername || null;
  const dDisplayName = currentUser?.displayName || currentUser?.username || null;
  const dUserId = currentUser?.discordId || null;
  const dRole = currentUser?.role || null;
  const ROLE_LABEL = { public: '<svg class="icon icon-16"><use href="#ic-globe"></use></svg> Public', gold: '<svg class="icon icon-16"><use href="#ic-trophy"></use></svg> Gold', platinum: '<svg class="icon icon-16"><use href="#ic-gem"></use></svg> Platinum', admin: '<svg class="icon icon-16"><use href="#ic-crown"></use></svg> Admin' };

  document.getElementById('sysdetDiscordUsername').textContent = dUsername ? '@' + dUsername : (dDisplayName ? '—' : 'Belum login');
  document.getElementById('sysdetDiscordDisplayName').textContent = dDisplayName || '—';
  document.getElementById('sysdetDiscordId').textContent = dUserId || '—';
  document.getElementById('sysdetDiscordRole').innerHTML = dRole ? (ROLE_LABEL[dRole] || dRole) : '—';

  const avatarEl = document.getElementById('sysdetDiscordAvatar');
  const avatarFallbackEl = document.getElementById('sysdetDiscordAvatarFallback');
  if (currentUser?.avatarUrl) {
    avatarEl.src = currentUser.avatarUrl;
    avatarEl.style.display = '';
    avatarFallbackEl.style.display = 'none';
  } else {
    avatarEl.style.display = 'none';
    avatarFallbackEl.style.display = '';
  }
}

// ══════════════════════════════════════════════════════════════════════════
// UPGRADE PAKET — beli/perpanjang Gold/Platinum via KlikQRIS (QRIS), status
// realtime lewat WS 'transaction:update' (+ polling tiap 5 detik sebagai
// fallback kalau WS lagi putus), dan Riwayat Transaksi.
// ══════════════════════════════════════════════════════════════════════════
let _lastPackagesData = null;
let _openTx = null;               // transaksi yang sedang ditampilkan di halaman Detail Pembayaran
let _prevPageBeforeUpg = 'store';
let _selectedUpgTier = null;
let _selectedUpgMethod = null;
let _upgCountdownTimer = null;
let _upgPollTimer = null;

const UPG_TIER_LABEL = { public: 'Public', gold: 'Gold', platinum: 'Platinum' };
const UPG_STATUS_LABEL = {
  pending: 'Menunggu Pembayaran',
  completed: 'Pembayaran Berhasil',
  failed: 'Pembayaran Gagal',
  cancelled: 'Dibatalkan',
  expired: 'Kedaluwarsa'
};

function rupiah(n) { return 'Rp' + Number(n || 0).toLocaleString('id-ID'); }

function wireUpgradePaket() {
  const confirmBtn = document.getElementById('upgMethodConfirmBtn');
  if (confirmBtn) confirmBtn.addEventListener('click', startUpgPurchase);

  const copyBtn = document.getElementById('upgPayCopyBtn');
  if (copyBtn) copyBtn.addEventListener('click', () => {
    const num = document.getElementById('upgPayVaNumber')?.textContent || '';
    if (!num || num === '-') return;
    navigator.clipboard?.writeText(num.replace(/\s+/g, ''));
    copyBtn.textContent = 'Tersalin!';
    setTimeout(() => { copyBtn.textContent = 'Salin Nomor'; }, 1500);
  });

  const backBtn = document.getElementById('purchaseDetailBackBtn');
  if (backBtn) backBtn.addEventListener('click', () => {
    stopUpgTimers();
    showPage(_prevPageBeforeUpg);
  });

  const cancelBtn = document.getElementById('upgPayCancelBtn');
  if (cancelBtn) cancelBtn.addEventListener('click', cancelCurrentPurchase);
}

async function cancelCurrentPurchase() {
  if (!_openTx || _openTx.status !== 'pending') return;
  if (!confirm('Batalkan transaksi ini? Kamu bisa buat transaksi baru kapan saja kalau berubah pikiran.')) return;
  const btn = document.getElementById('upgPayCancelBtn');
  btn.disabled = true;
  btn.textContent = 'Membatalkan...';
  try {
    const res = await api(`/api/packages/purchase/${encodeURIComponent(_openTx.orderId)}/cancel`, { method: 'POST' });
    handleTransactionUpdate(res.transaction);
  } catch (e) {
    alert(e.message || 'Gagal membatalkan transaksi.');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Batalkan Transaksi';
  }
}

// ── Halaman Upgrade Paket (3 kartu + tabel perbandingan) ──
async function loadPackages() {
  try {
    const data = await api('/api/packages');
    _lastPackagesData = data;
    renderPackages(data);
    renderCompareTable(data);
  } catch (e) {
    const wrap = document.getElementById('upgPackageCards');
    if (wrap) wrap.innerHTML = `<div class="upg-error">${escapeHtml(e.message)}</div>`;
  }
}

function upgLimitText(limit) {
  return (limit === null || limit === undefined) ? 'Unlimited' : `${limit}x/hari`;
}

function renderPackages(data) {
  const wrap = document.getElementById('upgPackageCards');
  if (!wrap || !data) return;
  const { packages, current } = data;
  const isActiveTier = (tier) => current.role === tier && (tier === 'public' || (current.activeUntil && new Date(current.activeUntil) > new Date()));

  const publicCard = `
    <div class="upg-card upg-card--public ${isActiveTier('public') ? 'upg-card--active' : ''}">
      <div class="upg-card-head">
        <div class="upg-card-name"><svg class="icon icon-18"><use href="#ic-globe"></use></svg> Public</div>
        ${isActiveTier('public') ? '<div class="upg-badge upg-badge--active">Paket Aktif</div>' : ''}
      </div>
      <div class="upg-card-price">Gratis</div>
      ${packages.public.description ? `<div class="upg-card-desc">${escapeHtml(packages.public.description)}</div>` : ''}
      <ul class="upg-card-benefits">
        ${packages.public.benefits.map(b => `<li><svg class="icon icon-14"><use href="#ic-check"></use></svg> ${escapeHtml(b)}</li>`).join('')}
        <li><svg class="icon icon-14"><use href="#ic-gamepad-2"></use></svg> Limit Game: ${upgLimitText(packages.public.limits.game)}</li>
        <li><svg class="icon icon-14"><use href="#ic-shield-check"></use></svg> Limit Bypass: ${upgLimitText(packages.public.limits.bypass)}</li>
      </ul>
    </div>`;

  const paidCard = (tier, icon) => {
    const p = packages[tier];
    const active = isActiveTier(tier);
    const disabled = !p.active;
    return `
    <div class="upg-card upg-card--${tier} ${active ? 'upg-card--active' : ''} ${disabled ? 'upg-card--disabled' : ''}">
      ${p.badge ? `<div class="upg-card-ribbon">${escapeHtml(p.badge)}</div>` : ''}
      <div class="upg-card-head">
        <div class="upg-card-name"><svg class="icon icon-18"><use href="#${icon}"></use></svg> ${UPG_TIER_LABEL[tier]}</div>
        ${active ? '<div class="upg-badge upg-badge--active">Paket Aktif</div>' : ''}
      </div>
      <div class="upg-card-price">${rupiah(p.price)}<span>/${p.durationLabel}</span></div>
      ${p.description ? `<div class="upg-card-desc">${escapeHtml(p.description)}</div>` : ''}
      <ul class="upg-card-benefits">
        ${p.benefits.map(b => `<li><svg class="icon icon-14"><use href="#ic-check"></use></svg> ${escapeHtml(b)}</li>`).join('')}
        <li><svg class="icon icon-14"><use href="#ic-gamepad-2"></use></svg> Limit Game: ${upgLimitText(p.limits.game)}</li>
        <li><svg class="icon icon-14"><use href="#ic-shield-check"></use></svg> Limit Bypass: ${upgLimitText(p.limits.bypass)}</li>
      </ul>
      <button class="btn-primary upg-card-btn" ${disabled ? 'disabled' : ''} onclick="openUpgMethodModal('${tier}')">
        ${disabled ? 'Tidak Tersedia' : (active ? 'Perpanjang Sekarang' : 'Upgrade Sekarang')}
      </button>
    </div>`;
  };

  wrap.innerHTML = publicCard + paidCard('gold', 'ic-trophy') + paidCard('platinum', 'ic-gem');
}

function renderCompareTable(data) {
  const table = document.getElementById('upgCompareTable');
  if (!table || !data) return;
  const { packages } = data;
  const benefitSet = [];
  ['public', 'gold', 'platinum'].forEach(t => (packages[t].benefits || []).forEach(b => { if (!benefitSet.includes(b)) benefitSet.push(b); }));

  const hasBenefit = (tier, b) => (packages[tier].benefits || []).includes(b);
  const cell = (ok) => ok
    ? '<td class="upg-cell-yes"><svg class="icon icon-16"><use href="#ic-check"></use></svg></td>'
    : '<td class="upg-cell-no"><svg class="icon icon-16"><use href="#ic-minus"></use></svg></td>';

  let rows = '';
  rows += `<tr class="upg-row-header"><td>Fitur</td><td>Public</td><td>Gold</td><td>Platinum</td></tr>`;
  rows += `<tr><td>Deskripsi</td><td>${escapeHtml(packages.public.description || '-')}</td><td>${escapeHtml(packages.gold.description || '-')}</td><td>${escapeHtml(packages.platinum.description || '-')}</td></tr>`;
  rows += `<tr><td>Harga</td><td>Gratis</td><td>${rupiah(packages.gold.price)}</td><td>${rupiah(packages.platinum.price)}</td></tr>`;
  rows += `<tr><td>Masa Aktif</td><td>-</td><td>${escapeHtml(packages.gold.durationLabel)}</td><td>${escapeHtml(packages.platinum.durationLabel)}</td></tr>`;
  rows += `<tr><td>Limit Download Game</td><td>${upgLimitText(packages.public.limits.game)}</td><td>${upgLimitText(packages.gold.limits.game)}</td><td>${upgLimitText(packages.platinum.limits.game)}</td></tr>`;
  rows += `<tr><td>Limit Download Bypass</td><td>${upgLimitText(packages.public.limits.bypass)}</td><td>${upgLimitText(packages.gold.limits.bypass)}</td><td>${upgLimitText(packages.platinum.limits.bypass)}</td></tr>`;
  benefitSet.forEach(b => {
    rows += `<tr><td>${escapeHtml(b)}</td>${cell(hasBenefit('public', b))}${cell(hasBenefit('gold', b))}${cell(hasBenefit('platinum', b))}</tr>`;
  });
  table.innerHTML = rows;
}

// ── Modal pilih metode pembayaran ──
function openUpgMethodModal(tier) {
  if (!_lastPackagesData) return;
  _selectedUpgTier = tier;
  _selectedUpgMethod = null;
  document.getElementById('upgMethodModalTitle').textContent = `Pilih Metode Pembayaran — ${UPG_TIER_LABEL[tier]}`;
  document.getElementById('upgMethodConfirmBtn').disabled = true;
  renderMethodList(_lastPackagesData.paymentMethods || []);
  document.getElementById('upgMethodModalBackdrop').style.display = 'flex';
}
function closeUpgMethodModal() {
  document.getElementById('upgMethodModalBackdrop').style.display = 'none';
}
window.openUpgMethodModal = openUpgMethodModal;
window.closeUpgMethodModal = closeUpgMethodModal;

function renderMethodList(methods) {
  const wrap = document.getElementById('upgMethodList');
  if (!wrap) return;
  if (!methods.length) {
    wrap.innerHTML = '<div class="upg-error">Payment gateway sedang tidak tersedia. Coba lagi nanti.</div>';
    return;
  }
  wrap.innerHTML = methods.map(m => `
    <button type="button" class="upg-method-item" data-method="${m.key}">
      <span>${escapeHtml(m.label)}</span>
      <svg class="icon icon-16 upg-method-check"><use href="#ic-check"></use></svg>
    </button>
  `).join('');
  wrap.querySelectorAll('.upg-method-item').forEach(btn => {
    btn.addEventListener('click', () => {
      wrap.querySelectorAll('.upg-method-item').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      _selectedUpgMethod = btn.dataset.method;
      document.getElementById('upgMethodConfirmBtn').disabled = false;
    });
  });
}

async function startUpgPurchase() {
  if (!_selectedUpgTier || !_selectedUpgMethod) return;
  const btn = document.getElementById('upgMethodConfirmBtn');
  btn.disabled = true;
  btn.textContent = 'Memproses...';
  try {
    const res = await api('/api/packages/purchase', {
      method: 'POST',
      body: JSON.stringify({ tier: _selectedUpgTier, method: _selectedUpgMethod })
    });
    closeUpgMethodModal();
    _prevPageBeforeUpg = 'store';
    openPurchaseDetail(res.transaction);
  } catch (e) {
    alert(e.message || 'Gagal membuat transaksi.');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Lanjutkan Pembayaran';
  }
}

// ── Halaman Detail Pembayaran (QR/VA + status realtime) ──
function openPurchaseDetail(tx, fromPage) {
  _openTx = tx;
  if (fromPage) _prevPageBeforeUpg = fromPage;
  renderPurchaseDetail(tx);
  showPage('purchaseDetail');
  stopUpgTimers();
  if (tx.status === 'pending') {
    _upgCountdownTimer = setInterval(updateUpgCountdown, 1000);
    _upgPollTimer = setInterval(pollPurchaseStatus, 5000);
    updateUpgCountdown();
  }
}

function stopUpgTimers() {
  if (_upgCountdownTimer) clearInterval(_upgCountdownTimer);
  if (_upgPollTimer) clearInterval(_upgPollTimer);
  _upgCountdownTimer = null;
  _upgPollTimer = null;
}

function methodLabel(key) {
  const found = (_lastPackagesData?.paymentMethods || []).find(m => m.key === key);
  return found ? found.label : String(key || '-').toUpperCase();
}

function renderPurchaseDetail(tx) {
  document.getElementById('upgPayTitle').textContent = `Upgrade Paket ${UPG_TIER_LABEL[tx.tier] || tx.tier}`;
  document.getElementById('upgPayAmount').textContent = rupiah(tx.totalPayment || tx.amount);
  document.getElementById('upgPayInvoice').textContent = tx.orderId;
  document.getElementById('upgPayMethod').textContent = methodLabel(tx.paymentMethod);

  const badge = document.getElementById('upgPayStatusBadge');
  badge.textContent = UPG_STATUS_LABEL[tx.status] || tx.status;
  badge.className = 'upg-pay-status upg-pay-status--' + tx.status;

  const qrWrap = document.getElementById('upgPayQrWrap');
  const vaWrap = document.getElementById('upgPayVaWrap');
  const resultWrap = document.getElementById('upgPayResult');
  const cancelBtn = document.getElementById('upgPayCancelBtn');
  if (cancelBtn) cancelBtn.style.display = tx.status === 'pending' ? '' : 'none';

  if (tx.status === 'pending' && tx.paymentNumber) {
    if (tx.paymentMethod === 'qris') {
      qrWrap.style.display = '';
      vaWrap.style.display = 'none';
      // KlikQRIS balikin qrDataUrl (gambar QRIS asli dari KlikQRIS) — WAJIB
      // dipakai APA ADANYA, TIDAK BOLEH generate ulang QR sendiri dari teks
      // link/nomor (hasilnya bukan QRIS valid, cuma QR isi teks URL biasa —
      // makanya kalau qrDataUrl kosong, tampilkan pesan error, JANGAN bikin
      // QR palsu yang keliatan valid padahal tidak bisa dipakai bayar).
      const qrImgEl = document.getElementById('upgPayQrImg');
      const qrErrEl = document.getElementById('upgPayQrError');
      if (tx.qrDataUrl) {
        qrImgEl.style.display = '';
        qrImgEl.src = tx.qrDataUrl;
        if (qrErrEl) qrErrEl.style.display = 'none';
      } else {
        qrImgEl.style.display = 'none';
        if (qrErrEl) qrErrEl.style.display = '';
      }
    } else {
      qrWrap.style.display = 'none';
      vaWrap.style.display = '';
      document.getElementById('upgPayVaLabel').textContent = methodLabel(tx.paymentMethod);
      document.getElementById('upgPayVaNumber').textContent = tx.paymentNumber;
    }
    resultWrap.style.display = 'none';
  } else {
    qrWrap.style.display = 'none';
    vaWrap.style.display = 'none';
    resultWrap.style.display = '';
    if (tx.status === 'completed') {
      resultWrap.className = 'upg-pay-result upg-pay-result--success';
      resultWrap.innerHTML = `<svg class="icon icon-18"><use href="#ic-circle-check-big"></use></svg> Pembayaran berhasil! Paket ${UPG_TIER_LABEL[tx.tier]} kamu sudah aktif.`;
    } else if (tx.status === 'expired') {
      resultWrap.className = 'upg-pay-result upg-pay-result--muted';
      resultWrap.innerHTML = `<svg class="icon icon-18"><use href="#ic-timer"></use></svg> Waktu pembayaran habis. Silakan buat transaksi baru.`;
    } else {
      resultWrap.className = 'upg-pay-result upg-pay-result--danger';
      resultWrap.innerHTML = `<svg class="icon icon-18"><use href="#ic-circle-x"></use></svg> Transaksi ${UPG_STATUS_LABEL[tx.status] || tx.status}.`;
    }
  }
}

function updateUpgCountdown() {
  if (!_openTx || _openTx.status !== 'pending') return;
  const remainMs = new Date(_openTx.expiresAt).getTime() - Date.now();
  const el = document.getElementById('upgPayCountdown');
  if (remainMs <= 0) {
    if (el) el.textContent = '00:00';
    return;
  }
  const mm = String(Math.floor(remainMs / 60000)).padStart(2, '0');
  const ss = String(Math.floor((remainMs % 60000) / 1000)).padStart(2, '0');
  if (el) el.textContent = `${mm}:${ss}`;
}

// Fallback polling — dipanggil tiap 5 detik selagi status masih pending, jaga-jaga
// koneksi WS lagi putus. handleTransactionUpdate() yang render ulang UI-nya.
async function pollPurchaseStatus() {
  if (!_openTx || _openTx.status !== 'pending') { stopUpgTimers(); return; }
  try {
    const res = await api(`/api/packages/purchase/${encodeURIComponent(_openTx.orderId)}`);
    handleTransactionUpdate(res.transaction);
  } catch (e) { /* diam-diam, coba lagi 5 detik berikutnya */ }
}

// Dipicu WS event 'transaction:update' (realtime) ATAU hasil polling fallback —
// update tampilan Detail Pembayaran (kalau transaksi ini yang sedang dibuka) dan
// Riwayat Transaksi (kalau halamannya sedang dibuka).
function handleTransactionUpdate(tx) {
  if (!tx) return;
  if (_openTx && _openTx.orderId === tx.orderId) {
    _openTx = tx;
    renderPurchaseDetail(tx);
    if (tx.status !== 'pending') stopUpgTimers();
  }
  if (document.getElementById('pageTransactions')?.style.display !== 'none') {
    loadTransactions();
  }
}

// ── Riwayat Transaksi ──
let _lastTransactions = [];
// ══════════════════════════════════════════════════════════════════════════
// REQUEST GAME — browse katalog HubCap (diperkaya metadata Steam) dari server,
// search + filter genre + infinite scroll, halaman detail, tombol Request
// dengan status (Pending/Approved/Rejected/Tersedia), realtime lewat WS
// 'gameRequest:update' (push langsung ke user yang bersangkutan begitu admin
// approve/reject — lihat notifyUser di server.js).
// ══════════════════════════════════════════════════════════════════════════
let _reqGamePage = 1;
let _reqGameTotalPages = 1;
let _reqGameLoading = false;
let _reqGameSearch = '';
let _reqGameSearchDebounce = null;
let _reqGameCurrentDetail = null; // appId yang lagi dibuka di halaman detail
let _reqGamePageItems = []; // item-item di HALAMAN YANG SEDANG TAMPIL saja (bukan akumulasi semua halaman)
// Fallback SVG data-URI (tanpa network) — dipakai kalau SEMUA kandidat gambar
// (item.images) gagal dimuat, supaya kartu TIDAK PERNAH tampil kosong/blank.
const REQ_GAME_FALLBACK_IMG = 'data:image/svg+xml;utf8,' + encodeURIComponent(
  `<svg xmlns="http://www.w3.org/2000/svg" width="460" height="215" viewBox="0 0 460 215"><rect width="460" height="215" fill="#3a2a63"/><g fill="#8577a3" font-family="sans-serif" text-anchor="middle"><text x="230" y="112" font-size="15">Gambar tidak tersedia</text></g></svg>`
);
// Cache hasil /api/requests/browse per kombinasi search+HALAMAN — kalau user
// balik ke halaman yang sudah pernah di-load, langsung pakai cache (tanpa
// network) supaya terasa instan. TTL 3 menit cukup buat 1 sesi browsing.
const _reqGamePageCache = new Map(); // "search|page" -> { data, ts }
const REQ_GAME_CACHE_TTL_MS = 3 * 60 * 1000;

const REQ_GAME_STATUS_LABEL = {
  available: { text: '✅ Sudah Tersedia', cls: 'ok' },
  pending:   { text: '⏳ Menunggu Persetujuan', cls: 'pending' },
  approved:  { text: '✅ Disetujui — cek halaman Games', cls: 'ok' },
  rejected:  { text: '❌ Ditolak', cls: 'rejected' }
};

function reqGameToast(msg) {
  let el = document.querySelector('.histori-toast');
  if (!el) {
    el = document.createElement('div');
    el.className = 'histori-toast';
    document.body.appendChild(el);
  }
  el.textContent = msg;
  el.classList.add('show');
  scheduleToastAutoHide(el, 'show');
}

let _reqGameLimitInfo = null; // { enabled, role, limit, used, remaining, allowed, resetAt } — dari /api/requests/limit-info

function fmtResetTimeWIB(iso) {
  if (!iso) return '-';
  return new Date(iso).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit', day: '2-digit', month: 'short' }) + ' WIB';
}

async function fetchRequestGameLimitInfo() {
  try {
    _reqGameLimitInfo = await api('/api/requests/limit-info');
  } catch (e) {
    _reqGameLimitInfo = null;
  }
  renderRequestGameLimitBanner();
}

// Banner info di atas grid — beda-beda tergantung status user:
//  - fitur nonaktif total (admin matikan)
//  - Public / paket tanpa jatah (limit 0)      -> ajak upgrade paket
//  - limit harian habis                         -> sisa 0 + jam reset
//  - masih ada jatah                            -> sisa X, reset jam Y (info halus)
function renderRequestGameLimitBanner() {
  const el = document.getElementById('reqGameLimitBanner');
  if (!el) return;
  const info = _reqGameLimitInfo;
  if (!info) { el.style.display = 'none'; return; }

  if (!info.enabled) {
    el.className = 'req-game-limit-banner req-game-limit-banner--off';
    el.innerHTML = `<span>🚧</span> Fitur Request Game sedang dinonaktifkan sementara oleh Admin.`;
    el.style.display = '';
    return;
  }
  if (!info.allowed) {
    el.className = 'req-game-limit-banner req-game-limit-banner--upgrade';
    el.innerHTML = `<span>🔒</span> Request Game hanya tersedia untuk paket tertentu. Upgrade paket kamu untuk bisa mengajukan request. <button class="req-game-limit-banner-btn" onclick="showPage('store')">Upgrade Paket</button>`;
    el.style.display = '';
    return;
  }
  if (info.remaining <= 0) {
    el.className = 'req-game-limit-banner req-game-limit-banner--empty';
    el.innerHTML = `<span>⏳</span> Limit request harian kamu (${info.limit}x) sudah habis. Reset pada ${fmtResetTimeWIB(info.resetAt)}.`;
    el.style.display = '';
    return;
  }
  el.className = 'req-game-limit-banner req-game-limit-banner--ok';
  el.innerHTML = `<span>🎯</span> Sisa jatah request kamu hari ini: <strong>${info.remaining}/${info.limit}</strong> — reset ${fmtResetTimeWIB(info.resetAt)}.`;
  el.style.display = '';
}

function initRequestGamePage() {
  const grid = document.getElementById('reqGameGrid');
  // Reset state tiap kali halaman dibuka supaya tidak nyampur sama sesi browsing sebelumnya.
  _reqGamePage = 1; _reqGameTotalPages = 1; _reqGamePageItems = [];
  document.getElementById('reqGameSearchInput').value = '';
  _reqGameSearch = '';
  grid.innerHTML = '';
  document.getElementById('reqGamePagination').style.display = 'none';
  document.getElementById('reqGameStatsBar').style.display = 'none';

  // SEMUA role (termasuk Public) tetap bisa lihat daftar & buka Detail Game —
  // yang dibatasi cuma AKSI "Request Game"-nya (lihat renderRequestGameActionBox
  // & renderRequestGameLimitBanner, dikontrol oleh /api/requests/limit-info).
  fetchRequestGameLimitInfo();
  loadRequestGamePage(1);
}

document.getElementById('reqGameSearchInput')?.addEventListener('input', (e) => {
  clearTimeout(_reqGameSearchDebounce);
  _reqGameSearchDebounce = setTimeout(() => {
    _reqGameSearch = e.target.value.trim();
    loadRequestGamePage(1); // search baru selalu mulai dari halaman 1
  }, 400);
});

// Muat 1 halaman (page-based, BUKAN infinite scroll) — backend yang melakukan
// pagination sesungguhnya (lihat /api/requests/browse: page & limit=100),
// bukan fetch semua lalu dipotong di sini. Search/filter/kategori yang sedang
// aktif otomatis ikut terbawa (ada di cache key & query params).
// Fungsi utama muat 1 halaman (page-based, BUKAN infinite scroll) — backend
// yang melakukan pagination sesungguhnya (lihat /api/requests/browse: page &
// limit=50), bukan fetch semua lalu dipotong di sini. Search/filter/kategori
// yang sedang aktif otomatis ikut terbawa (ada di cache key & query params).
//
// `silent` — dipakai untuk prefetch halaman berikutnya di background: tidak
// menyentuh skeleton/grid yang sedang tampil sama sekali, cuma mengisi cache
// supaya kalau user benar-benar klik Next, datanya sudah siap (instan, tanpa
// network) — lihat prefetchNextRequestGamePage().
async function loadRequestGamePage(page, { silent = false } = {}) {
  if (!silent) {
    if (_reqGameLoading) return;
    _reqGameLoading = true;
  }
  const grid = document.getElementById('reqGameGrid');
  const cacheKey = `${_reqGameSearch.toLowerCase()}|${page}`;
  const cached = _reqGamePageCache.get(cacheKey);
  const isFresh = cached && (Date.now() - cached.ts) < REQ_GAME_CACHE_TTL_MS;

  // Skeleton loading cuma kalau belum ada cache untuk kombinasi ini — kalau
  // sudah ada (mis. balik ke halaman sebelumnya, atau sudah di-prefetch di
  // background), langsung tampil instan tanpa skeleton/network sama sekali.
  if (!silent) {
    if (!isFresh) renderRequestGameSkeletons(grid);
    else grid.classList.add('rg-page-loading');
  }

  try {
    let data;
    if (isFresh) {
      data = cached.data; // langsung pakai, tanpa network — terasa instan
    } else {
      const params = new URLSearchParams({ page: String(page) });
      if (_reqGameSearch) params.set('search', _reqGameSearch);
      data = await api(`/api/requests/browse?${params.toString()}`);
      _reqGamePageCache.set(cacheKey, { data, ts: Date.now() });
    }

    if (silent) {
      // Prefetch diam-diam — cukup simpan ke cache (sudah dilakukan di atas),
      // tidak menyentuh UI yang sedang tampil sama sekali.
      return;
    }

    _reqGamePage = data.currentPage || page;
    _reqGameTotalPages = Math.max(1, data.totalPages || 1);
    _reqGamePageItems = data.items || [];
    renderRequestGameGrid(_reqGamePageItems);
    renderRequestGameStatsBar(data.totalData, _reqGamePage, _reqGameTotalPages);
    renderRequestGamePagination();

    // Posisi scroll otomatis kembali ke atas tiap kali berpindah halaman.
    const mainEl = document.querySelector('.main');
    if (mainEl) mainEl.scrollTop = 0;

    // Prefetch halaman berikutnya di background (diam-diam, tanpa loading UI)
    // supaya klik Next berikutnya terasa instan — hanya kalau memang masih ada
    // halaman selanjutnya & belum ada di cache.
    prefetchNextRequestGamePage();
  } catch (e) {
    if (silent) return; // prefetch gagal -> diam saja, bukan hal kritis
    grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:50px 20px;color:var(--text-faint);font-size:13px;">Gagal memuat: ${escapeHtml(e.message)}</div>`;
    document.getElementById('reqGamePagination').style.display = 'none';
    document.getElementById('reqGameStatsBar').style.display = 'none';
    reqGameToast('Gagal memuat: ' + e.message);
  } finally {
    if (!silent) {
      _reqGameLoading = false;
      grid.classList.remove('rg-page-loading');
    }
  }
}

// Format ribuan ala "12.548" (locale Indonesia, titik sebagai pemisah ribuan)
// — dipakai buat info Total Game Tersedia.
function fmtRequestGameCount(n) {
  return Number(n || 0).toLocaleString('id-ID');
}

// "12,548 Games • Page 3 of 251" — di atas grid, selalu sinkron dengan
// halaman yang sedang tampil (bukan sekadar dihitung ulang manual di frontend).
function renderRequestGameStatsBar(totalData, currentPage, totalPages) {
  const el = document.getElementById('reqGameStatsBar');
  if (!el) return;
  if (!totalData) { el.style.display = 'none'; return; }
  el.innerHTML = `<strong>${fmtRequestGameCount(totalData)}</strong> Games Tersedia • Page <strong>${currentPage}</strong> of <strong>${fmtRequestGameCount(totalPages)}</strong>`;
  el.style.display = '';
}

// Ambil halaman berikutnya diam-diam di background (tidak memblokir apapun di
// UI) supaya perpindahan halaman berikutnya terasa instan. Tidak dikirim kalau
// sudah di halaman terakhir atau sudah ada di cache & masih fresh.
function prefetchNextRequestGamePage() {
  const nextPage = _reqGamePage + 1;
  if (nextPage > _reqGameTotalPages) return;
  const cacheKey = `${_reqGameSearch.toLowerCase()}|${nextPage}`;
  const cached = _reqGamePageCache.get(cacheKey);
  if (cached && (Date.now() - cached.ts) < REQ_GAME_CACHE_TTL_MS) return; // sudah ada, tidak perlu diulang
  loadRequestGamePage(nextPage, { silent: true }).catch(() => {});
}

// Kartu placeholder pulsing selagi halaman dimuat — memberi kesan loading yang
// lebih responsif dibanding cuma teks/spinner kosong. Ditampilkan tiap kali
// pindah halaman TANPA cache (skeleton, bukan grid lama yang dibiarkan kosong).
function renderRequestGameSkeletons(gridEl) {
  gridEl.innerHTML = Array.from({ length: 12 }).map(() => `
    <div class="game-card gr-skeleton" aria-hidden="true">
      <div class="game-art gr-skeleton-shimmer"></div>
      <div class="game-info">
        <div class="gr-skeleton-line gr-skeleton-shimmer" style="width:80%;height:14px;"></div>
        <div class="gr-skeleton-line gr-skeleton-shimmer" style="width:50%;height:11px;margin-top:8px;"></div>
      </div>
    </div>`).join('');
}

// Coba tiap kandidat URL gambar SATU PER SATU (data-idx disimpan di elemen
// <img> itu sendiri) — baru kalau SEMUA kandidat gagal dimuat, tampilkan
// fallback placeholder. Pola PERSIS SAMA dengan lgImageFallback() di Library
// Game Admin Web (lihat public/admin.js) — sesuai permintaan supaya Request
// Game App memakai sistem yang sama dengan Library Game Admin.
function reqGameImageFallback(img) {
  let candidates = [];
  try { candidates = JSON.parse(img.dataset.candidates || '[]'); } catch (e) { candidates = []; }
  const nextIdx = (parseInt(img.dataset.idx, 10) || 0) + 1;
  if (nextIdx < candidates.length) {
    img.dataset.idx = String(nextIdx);
    img.src = candidates[nextIdx];
  } else {
    img.onerror = null;
    img.src = REQ_GAME_FALLBACK_IMG;
    img.classList.add('rg-img-fallback');
  }
}
window.reqGameImageFallback = reqGameImageFallback;

function reqGameCardStatusHtml(item) {
  // Rejected BUKAN status terminal (user boleh request ulang) — tampilkan
  // sebagai tombol yang bisa diklik, bukan badge statis kayak pending/approved/available.
  if (item.requestStatus === 'rejected') {
    return `<button class="btn-primary req-game-btn" onclick="event.stopPropagation();openRequestGameDetail('${item.appId}')">🔁 Request Lagi</button>`;
  }
  const meta = REQ_GAME_STATUS_LABEL[item.requestStatus];
  if (!meta) return `<button class="btn-primary req-game-btn" onclick="openRequestGameDetail('${item.appId}')">Lihat & Request</button>`;
  return `<div class="req-game-status req-game-status--${meta.cls}">${meta.text}</div>`;
}

// Render (GANTI TOTAL, bukan append) isi grid untuk 1 halaman — pagination
// artinya tiap halaman berdiri sendiri, bukan ditumpuk seperti infinite scroll.
function renderRequestGameGrid(items) {
  const grid = document.getElementById('reqGameGrid');
  if (!items.length) {
    grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:50px 20px;color:var(--text-faint);font-size:13px;">Tidak ada game yang cocok ditemukan.</div>`;
    return;
  }
  grid.innerHTML = items.map(item => {
    const candidates = (item.images && item.images.length ? item.images : [item.headerImage]).filter(Boolean);
    const candidatesJson = escapeHtml(JSON.stringify(candidates));
    return `
    <div class="game-card" data-appid="${item.appId}" onclick="openRequestGameDetail('${item.appId}')">
      <div class="game-art"><img src="${escapeHtml(candidates[0] || REQ_GAME_FALLBACK_IMG)}" alt="" loading="lazy" decoding="async"
        data-candidates='${candidatesJson}' data-idx="0" onerror="reqGameImageFallback(this)"></div>
      <div class="game-info">
        <h4 title="${escapeHtml(item.name)}">${escapeHtml(item.name)}</h4>
        <div class="game-meta">
          ${reqGameCardStatusHtml(item)}
        </div>
      </div>
    </div>`;
  }).join('');
}

// Bikin daftar nomor halaman yang ditampilkan (windowed + elipsis) — supaya
// tetap ringkas walau totalPages besar. Format: "1 2 3 4 5 6 7 ... 250" —
// selalu tampilkan jendela 7 nomor berdekatan (di sekitar halaman aktif, atau
// 7 nomor pertama/terakhir kalau posisinya dekat ujung), plus halaman 1 &
// halaman terakhir kalau belum termasuk di jendela itu.
function buildRequestGamePageNumbers(current, total) {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);

  let start = current - 3;
  let end = current + 3;
  if (start < 1) { start = 1; end = 7; }
  if (end > total) { end = total; start = total - 6; }

  const pages = [];
  for (let p = start; p <= end; p++) pages.push(p);

  const withEdges = [];
  if (pages[0] > 1) {
    withEdges.push(1);
    if (pages[0] > 2) withEdges.push('…');
  }
  withEdges.push(...pages);
  if (pages[pages.length - 1] < total) {
    if (pages[pages.length - 1] < total - 1) withEdges.push('…');
    withEdges.push(total);
  }
  return withEdges;
}

function renderRequestGamePagination() {
  const wrap = document.getElementById('reqGamePagination');
  const numsWrap = document.getElementById('reqGamePageNumbers');
  const prevBtn = document.getElementById('reqGamePrevBtn');
  const nextBtn = document.getElementById('reqGameNextBtn');
  if (!wrap || !numsWrap || !prevBtn || !nextBtn) return;

  if (_reqGameTotalPages <= 1) { wrap.style.display = 'none'; return; }
  wrap.style.display = '';
  prevBtn.disabled = _reqGamePage <= 1;
  nextBtn.disabled = _reqGamePage >= _reqGameTotalPages;

  const pages = buildRequestGamePageNumbers(_reqGamePage, _reqGameTotalPages);
  numsWrap.innerHTML = pages.map(p => p === '…'
    ? `<button class="rg-page-num ellipsis" disabled>…</button>`
    : `<button class="rg-page-num ${p === _reqGamePage ? 'active' : ''}" onclick="goToRequestGamePage(${p})">${p}</button>`
  ).join('');
}

function goToRequestGamePage(page) {
  if (page === _reqGamePage || page < 1 || page > _reqGameTotalPages || _reqGameLoading) return;
  loadRequestGamePage(page);
}
window.goToRequestGamePage = goToRequestGamePage;

document.getElementById('reqGamePrevBtn')?.addEventListener('click', () => goToRequestGamePage(_reqGamePage - 1));
document.getElementById('reqGameNextBtn')?.addEventListener('click', () => goToRequestGamePage(_reqGamePage + 1));

// ══════════════════════════════════════════════════════════════════════════
// DETAIL REQUEST GAME — layout & komponen SAMA PERSIS seperti halaman Detail
// Install Game (openDetailPage/applySteamDetails/renderOnlineBanner di atas):
// cover, info grid (Release/Metacritic/Developer/Publisher), tags/genre,
// System Requirements, screenshot, & action bar sticky di bawah. Bedanya cuma
// tombol aksi ("Request Game" bukan "Install") & banner status request.
// ══════════════════════════════════════════════════════════════════════════
async function openRequestGameDetail(appId) {
  showPage('requestGameDetail');
  const mainEl = document.querySelector('.main');
  if (mainEl) mainEl.scrollTop = 0;
  _reqGameCurrentDetail = appId;

  // ── Skeleton dulu (pola sama seperti openDetailPage Install Game) ──
  document.getElementById('reqDetailTitle').textContent = 'Memuat...';
  document.getElementById('reqDetailDescription').textContent = '';
  document.getElementById('reqDetailGenres').innerHTML = '';
  document.getElementById('reqDetailScreenshotsWrap').style.display = 'none';
  document.getElementById('reqDetailReqsWrap').style.display = 'none';
  document.getElementById('reqDetailCover').style.backgroundImage = '';
  document.getElementById('reqDetailStatusBanner').style.display = 'none';
  document.getElementById('reqDetailSteamIdRow').style.display = 'block';
  document.getElementById('reqDibAppId').textContent = appId;

  const setInfoBox = (id, val, isSkel) => {
    const el = document.getElementById(id);
    el.textContent = val;
    el.classList.toggle('detail-skel', !!isSkel);
  };
  setInfoBox('reqDibRelease', '', true);
  setInfoBox('reqDibMetacritic', '', true);
  setInfoBox('reqDibDeveloper', '', true);
  setInfoBox('reqDibPublisher', '', true);

  try {
    const d = await api(`/api/requests/detail/${encodeURIComponent(appId)}`);
    if (_reqGameCurrentDetail !== appId) return; // user keburu pindah ke game lain

    document.getElementById('reqDetailTitle').textContent = d.name || '-';
    document.getElementById('reqDetailDescription').textContent = d.fullDescription || d.description || 'Tidak ada deskripsi.';

    setInfoBox('reqDibRelease', d.releaseDate || (d.comingSoon ? 'Coming Soon' : 'Tidak diketahui'), false);
    setInfoBox('reqDibMetacritic', d.metacritic != null ? `${d.metacritic} (Meta)` : 'Tidak ada skor', false);
    setInfoBox('reqDibDeveloper', d.developer || 'Tidak diketahui', false);
    setInfoBox('reqDibPublisher', d.publisher || 'Tidak diketahui', false);

    // Cover — coba SEMUA kandidat gambar yang tersedia dari Steam secara
    // berurutan (bukan cuma 1-2 seperti sebelumnya), pola yang sama seperti
    // fallback chain di grid Request Game (reqGameImageFallback) — supaya
    // detail page sama tangguhnya dengan grid dalam menampilkan gambar.
    const coverEl = document.getElementById('reqDetailCover');
    const coverCandidates = [d.headerImage, d.libraryImageUrl, d.heroImageUrl, d.capsuleImageUrl].filter(Boolean);
    if (coverCandidates.length) {
      let ci = 0;
      const tryNextCover = () => {
        if (ci >= coverCandidates.length) { coverEl.style.backgroundImage = `url('${REQ_GAME_FALLBACK_IMG}')`; return; }
        const url = coverCandidates[ci++];
        const probe = new Image();
        probe.onload = () => { coverEl.style.backgroundImage = `url('${url}')`; };
        probe.onerror = tryNextCover;
        probe.src = url;
      };
      coverEl.style.backgroundImage = `url('${coverCandidates[0]}')`; // tampil instan dulu, diganti kalau ternyata gagal
      tryNextCover();
    } else {
      coverEl.style.backgroundImage = `url('${REQ_GAME_FALLBACK_IMG}')`;
    }

    // Tags — gabungan categories (mode single/multiplayer dsb, kalau ada) + genre,
    // sama seperti applySteamDetails() Install Game.
    const tagsHtml = [
      `<span class="detail-tag plain"><svg class="icon icon-16"><use href="#ic-gamepad-2"></use></svg> Game</span>`,
      ...(d.categories || []).map(c => `<span class="detail-tag">${escapeHtml(c)}</span>`),
      ...(d.genres || []).map(g => `<span class="detail-tag plain">${escapeHtml(g)}</span>`)
    ].join('');
    document.getElementById('reqDetailGenres').innerHTML = tagsHtml;

    // System Requirements — sama persis seperti Install Game (Minimum/Recommended).
    const reqsWrap = document.getElementById('reqDetailReqsWrap');
    const hasReqs = (d.requirementsMin?.length || d.requirementsRec?.length);
    if (hasReqs) {
      reqsWrap.style.display = 'block';
      const renderReqs = list => (list || []).map(r =>
        `<div class="drb-row">${r.label ? `<b>${escapeHtml(r.label)}:</b> ` : ''}${escapeHtml(r.value)}</div>`
      ).join('') || '<div class="drb-row">Tidak ada data.</div>';
      document.getElementById('reqDetailReqsMin').innerHTML = renderReqs(d.requirementsMin);
      document.getElementById('reqDetailReqsRec').innerHTML = renderReqs(d.requirementsRec);
    } else {
      reqsWrap.style.display = 'none';
    }

    // Screenshots — komponen tambahan (Install Game tidak punya, tapi diminta
    // eksplisit untuk Detail Request Game) — lazy load + gambar hilang otomatis
    // disembunyikan kalau linknya mati, tidak pernah nampilkan ikon broken image.
    const shotsWrap = document.getElementById('reqDetailScreenshotsWrap');
    if ((d.screenshots || []).length) {
      shotsWrap.style.display = 'block';
      document.getElementById('reqDetailScreenshots').innerHTML = d.screenshots.map(s =>
        `<img src="${s}" alt="" loading="lazy" decoding="async" onerror="this.style.display='none'">`
      ).join('');
    } else {
      shotsWrap.style.display = 'none';
    }

    renderRequestGameActionBox(d.requestStatus, d.rejectReason, appId);
    if (!_reqGameLimitInfo) fetchRequestGameLimitInfo().then(() => {
      if (_reqGameCurrentDetail === appId) renderRequestGameActionBox(d.requestStatus, d.rejectReason, appId);
    });
  } catch (e) {
    document.getElementById('reqDetailTitle').textContent = 'Gagal memuat';
    document.getElementById('reqDetailDescription').textContent = e.message;
    document.getElementById('btnReqGameSubmit').style.display = 'none';
  }
}
window.openRequestGameDetail = openRequestGameDetail;

// Action bar sticky di bawah (sama seperti detail-action-bar Install Game) —
// tombolnya berubah tergantung status request & status akun user:
//   - Status permanen game ini (Pending/Approved/Rejected/Tersedia) menang duluan.
//   - Belum login                          -> "Login untuk Request"
//   - Fitur dinonaktifkan admin             -> tombol terkunci + banner
//   - Public/paket tanpa jatah              -> "Upgrade Paket"
//   - Limit harian habis                    -> tombol terkunci + banner + jam reset
//   - Normal                                -> "Request Game" aktif
function renderRequestGameActionBox(status, rejectReason, appId) {
  const btn = document.getElementById('btnReqGameSubmit');
  const banner = document.getElementById('reqDetailStatusBanner');
  const bannerIcon = document.getElementById('reqDetailStatusBannerIcon');
  const bannerTitle = document.getElementById('reqDetailStatusBannerTitle');
  const bannerText = document.getElementById('reqDetailStatusBannerText');

  const showBanner = (cls, icon, title, text) => {
    banner.style.display = 'flex';
    banner.className = 'detail-online-banner ' + cls;
    bannerIcon.innerHTML = `<svg class="icon icon-24"><use href="#${icon}"></use></svg>`;
    bannerTitle.textContent = title;
    bannerText.textContent = text;
  };
  const setBtn = (text, locked, onclick) => {
    btn.style.display = '';
    btn.disabled = locked;
    btn.className = 'detail-install-btn' + (locked ? ' locked' : '');
    btn.textContent = text;
    btn.onclick = onclick || null;
  };

  // Status PERMANEN (tidak bisa direquest ulang): sudah tersedia di katalog,
  // masih pending review, atau sudah disetujui. Kalau REJECTED, ini BUKAN
  // status permanen — user (siapapun, termasuk yang sama) tetap boleh
  // mengajukan request ulang untuk game ini, jadi TIDAK di-lock di sini,
  // lanjut ke pengecekan role/limit seperti request baru biasa di bawah.
  if (status && status !== 'rejected') {
    const meta = REQ_GAME_STATUS_LABEL[status] || { text: status, cls: 'pending' };
    const isOk = meta.cls === 'ok';
    showBanner(
      isOk ? 'is-online' : 'is-offline',
      isOk ? 'ic-circle-check-big' : 'ic-clock',
      status === 'available' ? 'Sudah Tersedia' : status === 'approved' ? 'Request Disetujui' : 'Menunggu Persetujuan',
      meta.text
    );
    const btnText = status === 'available' ? '✅ Sudah Tersedia' : status === 'approved' ? '✅ Approved' : '⏳ Pending';
    setBtn(btnText, true);
    return;
  }
  // Riwayat penolakan (kalau ada) ditampilkan sebagai INFO saja — dioverride
  // di bawah kalau ternyata ada alasan lain yang lebih mendesak (fitur mati/
  // limit habis/dst), tapi kalau semua aman, banner ini yang tetap tampil.
  const rejectedBannerInfo = status === 'rejected'
    ? () => showBanner('is-offline', 'ic-circle-x', 'Request Sebelumnya Ditolak',
        (rejectReason ? `Alasan: ${rejectReason}. ` : '') + 'Kamu tetap bisa mengajukan request ulang untuk game ini.')
    : null;

  // Belum login sama sekali (jaga-jaga — harusnya jarang kejadian karena
  // halaman ini normalnya cuma bisa dibuka setelah login Discord).
  if (typeof currentUser === 'undefined' || !currentUser) {
    banner.style.display = 'none';
    setBtn('Login untuk Request', false, () => startLogin());
    return;
  }

  const info = _reqGameLimitInfo;
  if (info && !info.enabled) {
    showBanner('is-offline', 'ic-triangle-alert', 'Fitur Dinonaktifkan', 'Fitur Request Game sedang dinonaktifkan sementara oleh Admin.');
    setBtn('Fitur Dinonaktifkan', true);
    return;
  }
  if (info && !info.allowed) {
    banner.style.display = 'none';
    setBtn('Upgrade Paket untuk Request', false, () => showPage('store'));
    return;
  }
  if (info && info.remaining <= 0) {
    showBanner('is-offline', 'ic-clock', 'Limit Harian Habis', `Limit request harian kamu sudah habis. Reset ${fmtResetTimeWIB(info.resetAt)}.`);
    setBtn('Limit Harian Habis', true);
    return;
  }

  banner.style.display = 'none';
  if (rejectedBannerInfo) rejectedBannerInfo();
  setBtn(status === 'rejected' ? 'Request Lagi' : 'Request Game', false, () => submitGameRequest(appId));
}

async function submitGameRequest(appId) {
  const btn = document.getElementById('btnReqGameSubmit');
  btn.disabled = true;
  btn.textContent = 'Mengirim...';
  try {
    await api('/api/requests/games', { method: 'POST', body: JSON.stringify({ appId }) });
    reqGameToast('✅ Request Game berhasil dikirim! Menunggu review Admin.');
    renderRequestGameActionBox('pending', null, appId);
    // Sinkron status di grid halaman yang sedang tampil juga (biar pas balik
    // ke halaman list, kartu ini sudah update tanpa perlu reload).
    const it = _reqGamePageItems.find(x => x.appId === appId);
    if (it) it.requestStatus = 'pending';
  } catch (e) {
    reqGameToast('❌ ' + e.message);
    btn.disabled = false;
    btn.textContent = 'Request Game';
  }
}

document.getElementById('reqGameDetailBackBtn')?.addEventListener('click', () => {
  showPage('requestgame');
  // Grid yang sudah dirender TIDAK di-reset/rebuild total — cukup update kartu
  // App ID yang barusan dibuka di halaman detail (kalau status request-nya
  // berubah, mis. abis klik "Request Game"), biar tidak me-render ulang
  // seluruh daftar tiap kali user bolak-balik List <-> Detail.
  if (_reqGameCurrentDetail) patchRequestGameCardStatus(_reqGameCurrentDetail);
});

// Update status 1 kartu di grid (halaman yang sedang tampil) tanpa menyentuh
// kartu lain — dipakai saat balik dari halaman Detail, dan juga oleh
// handleGameRequestUpdate() (push realtime).
function patchRequestGameCardStatus(appId) {
  const card = document.querySelector(`#reqGameGrid .game-card[data-appid="${CSS.escape(String(appId))}"]`);
  if (!card) return;
  const item = _reqGamePageItems.find(x => x.appId === appId);
  if (!item) return;
  const metaEl = card.querySelector('.game-meta');
  if (metaEl) metaEl.innerHTML = reqGameCardStatusHtml(item);
}

// Realtime: begitu admin approve/reject Request Game milik user ini, dorong
// update ke UI TANPA perlu reload/refresh manual (lihat wsSendToUser di server.js).
function handleGameRequestUpdate(data) {
  const it = _reqGamePageItems.find(x => x.appId === data.appId);
  if (it) it.requestStatus = data.status;
  patchRequestGameCardStatus(data.appId);
  // Buang cache halaman lama — status game ini sudah berubah, supaya kalau user
  // navigasi balik ke halaman manapun yang memuat game ini, datanya segar lagi.
  _reqGamePageCache.clear();

  if (_reqGameCurrentDetail === data.appId) {
    renderRequestGameActionBox(data.status, data.rejectReason, data.appId);
  }

  const label = data.status === 'approved' ? '✅ Request Game kamu DISETUJUI!'
    : data.status === 'rejected' ? '❌ Request Game kamu ditolak.'
    : '🎯 Request Game kamu sedang diproses.';
  reqGameToast(`${label} (${data.name || data.appId})`);
}


async function loadTransactions() {
  try {
    const data = await api('/api/transactions');
    _lastTransactions = data.transactions || [];
    renderTransactions(_lastTransactions);
  } catch (e) {
    const wrap = document.getElementById('upgTxList');
    if (wrap) wrap.innerHTML = `<div class="upg-error">${escapeHtml(e.message)}</div>`;
  }
}

function upgStatusChipClass(status) { return 'upg-chip upg-chip--' + status; }

const GT_STATUS_LABEL = { active: 'Aktif', expired: 'Berakhir' };

function renderTransactions(list) {
  const wrap = document.getElementById('upgTxList');
  const empty = document.getElementById('upgTxEmpty');
  if (!wrap) return;
  if (!list.length) {
    wrap.innerHTML = '';
    if (empty) empty.style.display = '';
    return;
  }
  if (empty) empty.style.display = 'none';
  wrap.innerHTML = list.map(tx => {
    const isSta = tx.kind === 'steam_account';
    const isGt = tx.kind === 'gold_trial';
    const isMkt = tx.kind === 'marketplace';
    const title = isGt ? 'Gold Trial' : (isSta || isMkt) ? tx.productName : (UPG_TIER_LABEL[tx.tier] || tx.tier);
    const methodTxt = isGt ? 'Gratis' : isSta ? staMethodLabel(tx.paymentMethod) : isMkt ? mktMethodLabel(tx.paymentMethod) : methodLabel(tx.paymentMethod);
    const statusLabel = isGt ? (GT_STATUS_LABEL[tx.status] || tx.status) : (isSta || isMkt) ? (MP_STATUS_LABEL[tx.status] || tx.status) : (UPG_STATUS_LABEL[tx.status] || tx.status);
    const statusChipClass = isGt ? `upg-chip upg-chip--${tx.status === 'active' ? 'completed' : 'expired'}` : upgStatusChipClass(tx.status);
    const kindChipLabel = isGt ? 'Gold Trial' : isSta ? 'Steam Account' : isMkt ? 'Marketplace' : 'Paket';
    return `
    <div class="upg-tx-row">
      <div class="upg-tx-row-main">
        <div class="upg-tx-invoice">${escapeHtml(tx.orderId)}<span class="upg-tx-kind-chip">${kindChipLabel}</span></div>
        <div class="upg-tx-sub">${escapeHtml(title)} · ${escapeHtml(methodTxt)} · ${new Date(tx.createdAt).toLocaleString('id-ID')}</div>
      </div>
      <div class="upg-tx-amount">${isGt ? 'Gratis' : rupiah(tx.totalPayment || tx.amount)}</div>
      <div class="${statusChipClass}">${escapeHtml(statusLabel)}</div>
      <button class="btn-secondary upg-tx-detail-btn" onclick="viewTransactionDetail('${tx.orderId}')">Lihat Detail</button>
    </div>
  `;
  }).join('');
}

async function viewTransactionDetail(orderId) {
  try {
    const cached = _lastTransactions.find(t => t.orderId === orderId);
    const tx = cached && cached.status !== 'pending' ? cached : (await api(`/api/transactions/${encodeURIComponent(orderId)}`)).transaction;
    if (tx.kind === 'gold_trial') openGoldTrialDetail(tx);
    else if (tx.kind === 'steam_account') openStaPurchaseDetail(tx, 'transactions');
    // Order Marketplace ditampilkan lewat modal QRIS yang sama dengan alur beli
    // (reuse penuh openMktPayModal) — modal ini sudah menangani semua status
    // (pending/completed/expired/failed) dengan benar termasuk kasus dibuka
    // dari Riwayat Transaksi (bukan cuma dari alur beli baru).
    else if (tx.kind === 'marketplace') openMktPayModal(tx);
    else openPurchaseDetail(tx, 'transactions');
  } catch (e) {
    alert(e.message || 'Gagal memuat detail transaksi.');
  }
}
window.viewTransactionDetail = viewTransactionDetail;

// Detail Gold Trial di Riwayat Transaksi — reuse modal popup yang sama dengan
// tawaran/klaim Gold Trial (lihat renderGoldTrialOfferState() dkk di atas),
// cuma dipakai dalam mode "info doang" (tanpa tombol Klaim/Nanti).
function openGoldTrialDetail(tx) {
  openGoldTrialModal();
  document.getElementById('goldTrialModalTitle').textContent = 'Detail Gold Trial';
  document.getElementById('goldTrialCloseBtn').style.display = '';
  document.getElementById('goldTrialModalBody').innerHTML = `
    <div class="access-required-icon"><svg class="icon icon-32"><use href="#ic-trophy"></use></svg></div>
    <div class="access-required-text">Nama Paket: <b>${escapeHtml(tx.packageName || 'Gold Trial')}</b></div>
    <div class="access-required-need">Durasi Trial: <b>${escapeHtml(tx.durationLabel)}</b></div>
    <div class="access-required-need">Limit Download: <b>${gtLimitText(tx.gameLimit)}</b> Game &middot; <b>${gtLimitText(tx.bypassLimit)}</b> Bypass</div>
    <div class="access-required-need">Tanggal Klaim: <b>${new Date(tx.claimedAt).toLocaleString('id-ID')}</b></div>
    <div class="access-required-need">Tanggal Berakhir: <b>${new Date(tx.expiresAt).toLocaleString('id-ID')}</b></div>
    <div class="access-required-need">Status: <b>${GT_STATUS_LABEL[tx.status] || tx.status}</b></div>
    <button class="btn-primary" id="btnGoldTrialDetailClose" style="width:100%;margin-top:6px;">Tutup</button>
  `;
  document.getElementById('btnGoldTrialDetailClose').addEventListener('click', closeGoldTrialModal);
}


// Status pembayaran generik (dipakai bersama oleh Steam Account Marketplace —
// lihat bagian STEAM ACCOUNT MARKETPLACE di bawah).
const MP_STATUS_LABEL = {
  pending: 'Menunggu Pembayaran',
  completed: 'Pembayaran Berhasil',
  failed: 'Pembayaran Gagal',
  cancelled: 'Dibatalkan',
  expired: 'Kedaluwarsa'
};

// ══════════════════════════════════════════════════════════════════════════
// STEAM ACCOUNT MARKETPLACE — halaman "Steam Accounts" (nav sendiri di bawah
// Bypass), detail produk dengan carousel game (SEMUA info kiri ganti total
// mengikuti game aktif), beli via KlikQRIS (endpoint & state TERPISAH dari
// Marketplace biasa — lihat steamAccountOrderManager.js di backend), dan
// tombol LOGIN AKUN yang menjalankan Steam langsung lewat IPC Electron.
// ══════════════════════════════════════════════════════════════════════════
let _lastStaProducts = [];
let _lastStaPaymentMethods = [];
let _openStaProduct = null;      // produk yang sedang dibuka di halaman detail
let _openStaOrder = null;        // order yang sedang ditampilkan di halaman Detail Pembayaran
let _selectedStaMethod = null;
let _staCountdownTimer = null;
let _staPollTimer = null;
let _staPrevPage = 'steamaccounts';
let _staDetailGames = [];        // detail LENGKAP tiap game (requirements dll), di-prefetch paralel
let _staLoginBusy = false;
let _staLoginStageMessage = '';   // teks tahap saat ini ("Menutup Steam...", dst) dari main process
let _staLoginFailed = false;      // true kalau tahap terakhir 'error' — tombol berubah jadi COBA LAGI
let _staLoginErrorCode = null;    // 'timeout' | 'crashed' | 'spawn_failed' | 'busy' | dll — dari result.code backend

function staMethodLabel(key) {
  const found = (_lastStaPaymentMethods || []).find(m => m.key === key);
  return found ? found.label : String(key || '-').toUpperCase();
}

async function loadSteamAccounts() {
  try {
    const data = await api('/api/steam-accounts');
    _lastStaPaymentMethods = data.paymentMethods || [];
    applyStaProductsUpdate(data.products || []);
  } catch (e) {
    const errBox = document.getElementById('steamAccountsGrid');
    if (errBox) errBox.innerHTML = `<div class="upg-error">${escapeHtml(e.message)}</div>`;
  }
}

function applyStaProductsUpdate(products) {
  _lastStaProducts = products || [];
  renderSteamAccountCards(_lastStaProducts);
  const badge = document.getElementById('steamAccountsNavBadge');
  if (badge) badge.textContent = String(_lastStaProducts.filter(p => p.status === 'available').length);

  // Kalau user lagi buka halaman Detail produk ini, refresh datanya juga
  // secara realtime (status/buyer/Gambar Utama Product bisa berubah kapan saja
  // — termasuk kalau Admin ganti Gambar Utama lewat Admin Web, poin 6 revisi).
  if (_openStaProduct) {
    const fresh = _lastStaProducts.find(p => p.id === _openStaProduct.id);
    if (fresh) {
      _openStaProduct = fresh;
      renderStaMainImage(fresh);
      renderStaBuyCard(fresh);
    } else if (document.getElementById('pageSteamAccountDetail')?.style.display !== 'none') {
      // FIX: produk yang sedang dibuka di Detail sudah DIHAPUS Admin — dulu
      // halaman ini tetap kebuka nampilin data basi (Beli Disini/Login Akun
      // ke produk yang sudah tidak ada). Sekarang langsung ditendang balik
      // ke grid + kasih tahu kenapa (spec: "Detail Product tidak bisa lagi
      // diakses" setelah dihapus).
      _openStaProduct = null;
      alert('Akun Steam ini sudah tidak tersedia (dihapus Admin).');
      showPage('steamaccounts');
    }
  }
}

function staProductImage(p) { return p.imageData || p.imageUrl || ''; }

function renderSteamAccountCards(products) {
  const wrap = document.getElementById('steamAccountsGrid');
  if (!wrap) return;
  if (!products.length) {
    wrap.innerHTML = `
      <div class="dash-empty-placeholder">
        <div class="dash-empty-placeholder__icon"><svg class="icon icon-18"><use href="#ic-package"></use></svg></div>
        <div class="dash-empty-placeholder__title">Belum Ada Steam Account</div>
        <div class="dash-empty-placeholder__text">Akun Steam yang dijual akan muncul di sini begitu Admin menambahkannya.</div>
      </div>`;
    return;
  }
  wrap.innerHTML = products.map((p, i) => {
    const img = staProductImage(p);
    // Akun Steam bersifat UNLIMITED USER — tidak ada lagi status 'sold'.
    // 'available' = bisa dibeli siapa saja (termasuk yang sudah owner, tetap
    // tampil sebagai "Dimiliki" buat dia), 'disabled' = admin tutup penjualan
    // baru (pemilik lama tetap bisa lihat & LOGIN AKUN).
    const statusCls = p.isOwner ? 'owned' : p.status;
    const statusLabel = p.isOwner ? 'Dimiliki' : (p.status === 'available' ? 'Tersedia' : 'Nonaktif');
    const disabled = p.status !== 'available' && !p.isOwner;
    const btnLabel = p.isOwner ? 'Login Disini' : disabled ? 'Nonaktif' : 'Beli Disini';
    return `
    <div class="sta-card ${disabled ? 'sta-card--sold' : ''}" data-idx="${i}">
      <div class="sta-card-banner" style="${img ? `background-image:url('${escapeHtml(img)}');` : ''}">
        <span class="sta-card-status-badge sta-card-status-badge--${statusCls}">${statusLabel}</span>
        <span class="sta-card-games-badge"><svg class="icon icon-12"><use href="#ic-gamepad-2"></use></svg> ${p.gamesCount}</span>
      </div>
      <div class="sta-card-body">
        <div class="sta-card-title">${escapeHtml(p.name)}</div>
        <div class="sta-card-footer">
          <div class="sta-card-price-col">
            <span class="sta-card-price-label">Harga</span>
            <span class="sta-card-price">${rupiah(p.price)}</span>
          </div>
          <button type="button" class="sta-card-view-btn" ${disabled ? 'disabled' : ''}>${btnLabel} <svg class="icon icon-14"><use href="#ic-arrow-right"></use></svg></button>
        </div>
      </div>
    </div>`;
  }).join('');
  wrap.querySelectorAll('.sta-card').forEach(card => {
    card.addEventListener('click', () => openStaDetail(products[+card.dataset.idx]));
  });
}

// ── Halaman detail produk — Gambar Utama Product (statis) + List Game (poin
// 7–9 revisi: Game Slider/banner besar & section "Game di Akun Ini" SUDAH
// DIHAPUS TOTAL, List Game naik ke posisi itu) ──
async function openStaDetail(product) {
  _openStaProduct = product;
  _staDetailGames = (product.games || []).map(g => ({ ...g, _full: null }));
  renderStaMainImage(product); // Gambar Utama Product — SATU-SATUNYA hero di halaman ini sekarang
  renderStaBuyCard(product);
  renderStaGameListStatic(product.games || []); // List Game — PERMANEN & non-interactive, diisi sekali
  showPage('staDetail');

  // Refresh data dasar produk (status/buyer terbaru)
  api(`/api/steam-accounts/${product.id}`).then(data => {
    if (!data?.product || _openStaProduct?.id !== product.id) return;
    if (Array.isArray(data.paymentMethods)) _lastStaPaymentMethods = data.paymentMethods;
    _openStaProduct = data.product;
    renderStaMainImage(data.product);
    renderStaBuyCard(data.product);
  }).catch(() => {});

  // Prefetch detail LENGKAP tiap game secara PARALEL — cuma dipakai buat
  // memastikan gambar List Game selalu versi terbaru/kualitas terbaik dari
  // Steam (bukan buat carousel lagi, itu sudah tidak ada). Render ULANG List
  // Game SEKALI saja setelah semua selesai (bukan per-item) biar tidak ada
  // flicker/re-render berkali-kali.
  await Promise.all(_staDetailGames.map(async (g, idx) => {
    try {
      const res = await api(`/api/steam-accounts/${product.id}/games/${encodeURIComponent(g.appId)}`);
      if (_openStaProduct?.id !== product.id) return;
      _staDetailGames[idx]._full = res.game;
    } catch (e) { /* biarkan pakai data snapshot kalau live-fetch gagal */ }
  }));
  if (_openStaProduct?.id === product.id) renderStaGameListView();
}

// ── LIST GAME — informasi PERMANEN semua game dalam produk ini, dalam bentuk
// CARD bergambar. Isi grid dipanggil SEKALI saat halaman detail dibuka. List
// Game bersifat NON-INTERACTIVE (poin 4/10 revisi) — murni informasi "akun
// ini isinya game apa saja", TIDAK ada klik, tidak ada navigasi/redirect,
// tidak ada selected state. Layout grid (5 baris x 5 kolom = 25 game/halaman,
// pagination next/prev kalau >25) diatur lewat CSS .sta-gamelist-grid. List
// Game TIDAK PERNAH berubah cuma karena data game lain (produk lain) diubah —
// grid ini murni dari _staDetailGames milik produk yang lagi dibuka.
// .sta-gamelist-grid. ──
const STA_GAMELIST_PAGE_SIZE = 25; // 5 kolom x 5 baris — spec poin 4
let _staGameListPage = 1;
let _staGameListQuery = '';
let _staGameListView = 'grid';

function renderStaGameListStatic(games) {
  _staGameListPage = 1;
  _staGameListQuery = '';
  const searchInput = document.getElementById('staGameListSearch');
  if (searchInput) searchInput.value = '';
  renderStaGameListView();
}

// Render ulang grid List Game berdasarkan state search/page/view SAAT INI.
// _staDetailGames sendiri (isi & urutan seluruh game produk) TIDAK PERNAH
// diubah oleh fungsi ini — cuma disaring/dipaginasi utk ditampilkan, jadi
// tetap sinkron dengan spec "List Game tidak boleh berubah walau slide
// carousel di atas berpindah" (search/paginate murni tampilan, TANPA klik).
function renderStaGameListView() {
  const wrap = document.getElementById('staGameListGrid');
  const emptyEl = document.getElementById('staGameListEmpty');
  const countEl = document.getElementById('staGameListCount');
  const pagerEl = document.getElementById('staGameListPagination');
  if (!wrap) return;

  const all = _staDetailGames || [];
  if (countEl) countEl.textContent = `(${all.length} Game)`;

  const q = _staGameListQuery.trim().toLowerCase();
  const filtered = all
    .map((g, origIdx) => ({ g, origIdx }))
    .filter(({ g }) => !q || g.name.toLowerCase().includes(q));

  const totalPages = Math.max(1, Math.ceil(filtered.length / STA_GAMELIST_PAGE_SIZE));
  if (_staGameListPage > totalPages) _staGameListPage = totalPages;
  const start = (_staGameListPage - 1) * STA_GAMELIST_PAGE_SIZE;
  const pageItems = filtered.slice(start, start + STA_GAMELIST_PAGE_SIZE);

  wrap.classList.toggle('sta-gamelist-grid--list', _staGameListView === 'list');
  emptyEl.style.display = pageItems.length ? 'none' : 'flex';

  // Card List Game NON-INTERACTIVE — tanpa data-idx buat klik, tanpa
  // event listener, murni tampilan informasi (poin 4 revisi).
  wrap.innerHTML = pageItems.map(({ g, origIdx }) => {
    const img = g._full?.headerImage || g.headerImage || '';
    return `
    <div class="sta-gamelist-card" title="${escapeHtml(g.name)}">
      <div class="sta-gamelist-card-img"${img ? ` style="background-image:url('${img}')"` : ''}>
        ${img ? '' : '<svg class="icon icon-20"><use href="#ic-gamepad-2"></use></svg>'}
        <span class="sta-gamelist-card-idx">${origIdx + 1}</span>
      </div>
      <span class="sta-gamelist-card-name">${escapeHtml(g.name)}</span>
    </div>
  `; }).join('');

  // Pagination — cuma dirender kalau lebih dari 1 halaman (poin 5: mekanisme
  // akses game berikutnya kalau >50 game).
  if (pagerEl) {
    if (totalPages <= 1) {
      pagerEl.innerHTML = '';
    } else {
      let btns = `<button type="button" class="sta-pager-btn" data-page="${_staGameListPage - 1}" ${_staGameListPage === 1 ? 'disabled' : ''}><svg class="icon icon-14"><use href="#ic-arrow-left"></use></svg></button>`;
      for (let p = 1; p <= totalPages; p++) {
        btns += `<button type="button" class="sta-pager-btn${p === _staGameListPage ? ' is-active' : ''}" data-page="${p}">${p}</button>`;
      }
      btns += `<button type="button" class="sta-pager-btn" data-page="${_staGameListPage + 1}" ${_staGameListPage === totalPages ? 'disabled' : ''}><svg class="icon icon-14"><use href="#ic-arrow-right"></use></svg></button>`;
      pagerEl.innerHTML = btns;
      pagerEl.querySelectorAll('.sta-pager-btn').forEach(b => {
        b.addEventListener('click', () => {
          const p = +b.dataset.page;
          if (p < 1 || p > totalPages || b.disabled) return;
          _staGameListPage = p;
          renderStaGameListView();
        });
      });
    }
  }
}

// ── GAMBAR UTAMA PRODUCT — sumber SAMA dengan Grid Card (staProductImage()),
// dirender di elemen hero paling atas halaman Detail (SATU-SATUNYA hero di
// halaman ini sekarang, poin 7–9 & 12 revisi). Dipanggil saat halaman detail
// dibuka DAN tiap kali data produk direfresh (poin 6/14: realtime kalau
// Admin ganti gambar). ──
function renderStaMainImage(product) {
  const wrap = document.getElementById('staMainImageWrap');
  if (!wrap) return;
  const img = staProductImage(product);
  // FIX BUG "gambar Detail jadi HITAM setelah ganti Gambar Utama" (poin 5
  // revisi): akar masalahnya versi sebelumnya set gambar lewat CSS custom
  // property (--sta-hero-img) yang dikombinasikan dgn fallback gradient di
  // shorthand `background` — begitu update datang lewat WebSocket dan value
  // custom property berubah, browser tidak selalu re-resolve shorthand
  // campuran itu dengan benar (ujungnya elemen kosong/hitam, gradient
  // fallback ikut hilang juga). Sekarang set `background-image` LANGSUNG di
  // elemen — pola yang SAMA PERSIS dengan Grid Card (staProductImage() di
  // renderSteamAccountCards()) yang sudah terbukti selalu benar & sinkron.
  if (!img) { wrap.style.backgroundImage = ''; return; } // -> fallback gradient CSS (.sta-hero), BUKAN kotak hitam kosong

  // Preload dulu sebelum dipasang — kalau gambar korup/URL mati, JANGAN
  // pasang background-image kosong (kelihatan hitam polos karena nutupin
  // gradient fallback dengan "gambar" yang gagal render) — tetap pertahankan
  // gradient fallback bawaan .sta-hero sampai ada gambar valid yang sukses.
  const probe = new Image();
  probe.onload = () => { wrap.style.backgroundImage = `url('${img}')`; };
  probe.onerror = () => { wrap.style.backgroundImage = ''; };
  probe.src = img;
}

// ── Floating purchase/login bar — state-nya SELALU dari data backend
// (product.isOwner, product.hasPendingOrder, product.status) + state lokal
// proses LOGIN AKUN yang sedang berjalan (_staLoginBusy dst), TIDAK PERNAH
// dari asumsi frontend semata. Urutan prioritas: sedang login > sudah owner >
// ada order pending (belum owner) > tersedia > tidak tersedia. ──
function renderStaBuyCard(product) {
  document.getElementById('staDetailTitle').textContent = product.name;

  const statParts = [
    `<span><svg class="icon icon-14"><use href="#ic-gamepad-2"></use></svg> ${product.gamesCount} Games</span>`,
    `<span><svg class="icon icon-14"><use href="#ic-power-off"></use></svg> Offline Play</span>`,
    `<span><svg class="icon icon-14"><use href="#ic-zap"></use></svg> Auto Login</span>`
  ];
  document.getElementById('staDetailStatRow').innerHTML = statParts.join('<span class="mp-detail-meta-dot">•</span>');

  document.getElementById('staImportantInfo').textContent = product.importantInfo || '-';
  renderStaPanduanLogin(product);
  renderStaSidebarInfo(product);

  const priceLabelEl = document.getElementById('staFloatPriceLabel');
  const priceValueEl = document.getElementById('staDetailPrice');
  const statusEl = document.getElementById('staBuyStatus');
  const btn = document.getElementById('staDetailBuyBtn');
  const labelEl = document.getElementById('staDetailBuyLabel');

  if (product.isOwner && _staLoginBusy) {
    // "Saat login sedang berlangsung" — label harga diganti teks proses,
    // status disembunyikan (sudah cukup diwakili teks tahap), tombol jadi
    // penanda proses (bukan tombol aksi).
    if (priceLabelEl) priceLabelEl.textContent = 'STEAM ACCOUNT';
    priceValueEl.textContent = _staLoginFailed ? 'Steam gagal login.' : (_staLoginStageMessage || 'Login sedang diproses...');
    statusEl.innerHTML = '';
    statusEl.className = 'sta-float-bar-status sta-float-bar-status--processing';
    btn.disabled = !_staLoginFailed;
    btn.className = 'sta-float-bar-btn sta-float-bar-btn--processing';
    // State FAILED vs TIMEOUT punya label beda (spec poin 8) — timeout artinya
    // Steam jalan tapi login tidak terkonfirmasi (butuh Steam Guard/verifikasi
    // manual), bukan error keras seperti Steam crash/gagal dijalankan.
    labelEl.textContent = !_staLoginFailed ? 'MEMPROSES...'
      : (_staLoginErrorCode === 'timeout' ? 'COBA LAGI' : 'LOGIN GAGAL — COBA LAGI');
  } else if (product.isOwner) {
    if (priceLabelEl) priceLabelEl.textContent = 'AKUN DIMILIKI';
    priceValueEl.textContent = rupiah(product.price);
    statusEl.innerHTML = '<span class="mp-status-dot"></span> Kamu pemilik akun ini';
    statusEl.className = 'sta-float-bar-status sta-float-bar-status--owned';
    btn.disabled = false;
    btn.className = 'sta-float-bar-btn sta-float-bar-btn--owned';
    labelEl.textContent = _staLoginFailed ? 'COBA LAGI' : 'LOGIN AKUN';
  } else if (product.hasPendingOrder) {
    // Order sebelumnya masih PROCESSING — jangan tawarkan BELI AKUN baru,
    // arahkan user lanjutkan pembayaran yang sudah ada.
    if (priceLabelEl) priceLabelEl.textContent = 'HARGA';
    priceValueEl.textContent = rupiah(product.price);
    statusEl.innerHTML = '<span class="mp-status-dot"></span> Menunggu pembayaran';
    statusEl.className = 'sta-float-bar-status sta-float-bar-status--processing';
    btn.disabled = false;
    btn.className = 'sta-float-bar-btn sta-float-bar-btn--processing';
    labelEl.textContent = 'PEMBAYARAN DIPROSES';
  } else if (product.status === 'available') {
    if (priceLabelEl) priceLabelEl.textContent = 'HARGA';
    priceValueEl.textContent = rupiah(product.price);
    statusEl.innerHTML = '<span class="mp-status-dot"></span> Available';
    statusEl.className = 'sta-float-bar-status';
    btn.disabled = false;
    btn.className = 'sta-float-bar-btn';
    labelEl.textContent = 'BELI AKUN';
  } else {
    // Akun Steam UNLIMITED USER — satu-satunya alasan tombol nonaktif di sini
    // adalah admin men-DISABLE penjualan baru (bukan "sudah terjual").
    if (priceLabelEl) priceLabelEl.textContent = 'HARGA';
    priceValueEl.textContent = rupiah(product.price);
    statusEl.innerHTML = '<span class="mp-status-dot"></span> Tidak Tersedia';
    statusEl.className = 'sta-float-bar-status sta-float-bar-status--sold';
    btn.disabled = true;
    btn.className = 'sta-float-bar-btn';
    labelEl.textContent = 'TIDAK TERSEDIA';
  }

  renderStaSidebarStatus(product);
  renderStaLoginStatusPanel(product);
}

// ── Kartu sidebar "Status Produk" — badge + baris info, diturunkan dari
// field REAL yang sama dgn floating bar (isOwner/hasPendingOrder/status).
// Sengaja TIDAK menampilkan field akun Steam yang tidak tersedia di data
// (level/country/VAC/trade dst) supaya tidak menampilkan data palsu. ──
function renderStaSidebarStatus(product) {
  const badgeEl = document.getElementById('staSideStatusBadge');
  const rowsEl = document.getElementById('staSideStatusRows');
  if (!badgeEl || !rowsEl) return;

  let badgeText = 'TIDAK TERSEDIA', badgeClass = 'sta-badge--muted';
  if (product.isOwner) { badgeText = 'DIMILIKI'; badgeClass = 'sta-badge--owned'; }
  else if (product.hasPendingOrder) { badgeText = 'PENDING'; badgeClass = 'sta-badge--pending'; }
  else if (product.status === 'available') { badgeText = 'AKTIF'; badgeClass = 'sta-badge--active'; }
  badgeEl.textContent = badgeText;
  badgeEl.className = `sta-badge ${badgeClass}`;

  const rows = [
    ['Jumlah Game', `${product.gamesCount} Game`],
    ['Mode Bermain', 'Offline Play'],
    ['Auto Login', 'Aktif'],
  ];
  rowsEl.innerHTML = rows.map(([k, v]) => `<div class="sta-side-row"><span>${escapeHtml(k)}</span><b>${escapeHtml(v)}</b></div>`).join('');
}

// ── Kartu sidebar "Info Produk" — dipanggil sekali saat render (tidak
// berubah tiap status login), isinya field produk yang memang ada. ──
function renderStaSidebarInfo(product) {
  const rowsEl = document.getElementById('staSideInfoRows');
  if (!rowsEl) return;
  const rows = [
    ['ID Produk', `#${product.id}`],
    ['Tipe Akun', 'Steam Account Sharing'],
    ['Harga', rupiah(product.price)],
  ];
  rowsEl.innerHTML = rows.map(([k, v]) => `<div class="sta-side-row"><span>${escapeHtml(k)}</span><b>${escapeHtml(v)}</b></div>`).join('');
}

// ── Kartu sidebar "Panduan Login" — pakai teks caraBermain yang sudah diisi
// Admin (field REAL, sama yg dulu dirender di section Cara Bermain), cuma
// dipecah per baris jadi list bernomor biar gampang dibaca (sesuai foto). ──
function renderStaPanduanLogin(product) {
  const listEl = document.getElementById('staPanduanLogin');
  if (!listEl) return;
  const raw = (product.caraBermain || '').trim();
  if (!raw) {
    listEl.innerHTML = '<li>Belum ada instruksi dari Admin.</li>';
    return;
  }
  const steps = raw.split('\n').map(s => s.replace(/^[-•\d.)\s]+/, '').trim()).filter(Boolean);
  listEl.innerHTML = (steps.length ? steps : [raw]).map(s => `<li>${escapeHtml(s)}</li>`).join('');
}

// ── Kartu sidebar "Status Login Otomatis" — highlight baris yang sesuai
// dengan state REAL proses login (_staLoginBusy/_staLoginFailed/isOwner),
// state yang sama persis dgn yang menggerakkan floating bar. Tidak ada log
// riwayat login palsu — cuma 1 baris aktif sesuai kondisi saat ini. ──
function renderStaLoginStatusPanel(product) {
  const wrap = document.getElementById('staLoginStatusList');
  if (!wrap) return;
  let active = null; // 'success' | 'processing' | 'error' | null (belum pernah login)
  if (product.isOwner && _staLoginBusy) active = _staLoginFailed ? 'error' : 'processing';
  else if (product.isOwner && _staLoginFailed) active = 'error';
  else if (product.isOwner) active = 'success';

  const procMsgEl = document.getElementById('staLoginStatusProcessingMsg');
  if (procMsgEl) procMsgEl.textContent = _staLoginStageMessage || 'Tunggu beberapa saat, jangan tutup aplikasi.';

  wrap.querySelectorAll('.sta-side-status-item').forEach(item => {
    item.classList.toggle('is-active', item.dataset.state === active);
  });
}

// ── Tombol LOGIN AKUN — ambil kredensial (sekali pakai, tidak disimpan di
// App) lalu minta Electron main process jalankan Steam langsung ke akun itu.
// Tahapan progress ("Menyiapkan Steam..." -> "Menutup Steam..." -> "Restart
// Steam..." -> "Login akun..." -> "Steam berhasil login.") datang realtime
// lewat electronAPI.onSteamAccountLoginProgress (lihat wireSteamAccounts),
// bukan cuma satu label "Membuka Steam..." statis. ──
async function staHandleLoginClick() {
  if (!_openStaProduct || _staLoginBusy) return;
  _staLoginBusy = true;
  _staLoginFailed = false;
  _staLoginErrorCode = null;
  _staLoginStageMessage = 'Menyiapkan Steam...';
  renderStaBuyCard(_openStaProduct);
  try {
    const steamPath = await window.electronAPI.getSteamPath();
    if (!steamPath) {
      _staLoginFailed = true;
      alert('Steam tidak terdeteksi di PC ini. Install Steam dulu, lalu coba lagi.');
      return;
    }
    const creds = await api(`/api/steam-accounts/${_openStaProduct.id}/credentials`);
    const result = await window.electronAPI.steamAccountLogin({ steamPath, username: creds.username, password: creds.password });
    if (!result?.success) {
      _staLoginFailed = true;
      _staLoginErrorCode = result?.code || null;
      // Pesan teknis mentah TIDAK ditampilkan ke user — cukup status generik
      // "Steam gagal login." (sudah di-set oleh event 'error' di atas) + tombol
      // COBA LAGI. result.error tetap dicatat ke console utk debugging.
      if (result?.error) console.warn('[Steam Account Login] gagal:', result.error);
    }
  } catch (e) {
    _staLoginFailed = true;
    console.warn('[Steam Account Login] gagal ambil kredensial:', e.message);
  } finally {
    _staLoginBusy = false;
    renderStaBuyCard(_openStaProduct);
  }
}

function wireSteamAccounts() {
  const backBtn = document.getElementById('staDetailBackBtn');
  if (backBtn) backBtn.addEventListener('click', () => showPage('steamaccounts'));

  // Progress realtime tahapan LOGIN AKUN dari Electron main process — lihat
  // main.js ipcMain.handle('steam-account-login'). Diwire SEKALI (listener
  // Electron, bukan per-klik) supaya tidak numpuk listener tiap buka halaman.
  if (window.electronAPI?.onSteamAccountLoginProgress) {
    window.electronAPI.onSteamAccountLoginProgress((data) => {
      if (!data) return;
      _staLoginStageMessage = data.message || '';
      _staLoginFailed = data.stage === 'error';
      if (_openStaProduct) renderStaBuyCard(_openStaProduct);
    });
  }

  // Search List Game — murni filter tampilan di atas _staDetailGames yang
  // sudah ada, tidak fetch data baru.
  let staSearchDebounce;
  document.getElementById('staGameListSearch')?.addEventListener('input', (e) => {
    clearTimeout(staSearchDebounce);
    staSearchDebounce = setTimeout(() => {
      _staGameListQuery = e.target.value || '';
      _staGameListPage = 1;
      renderStaGameListView();
    }, 120);
  });

  // Toggle tampilan grid/list List Game
  document.getElementById('staGameListViewToggle')?.addEventListener('click', (e) => {
    const btn = e.target.closest('.sta-gamelist-viewbtn');
    if (!btn) return;
    _staGameListView = btn.dataset.view;
    document.querySelectorAll('.sta-gamelist-viewbtn').forEach(b => b.classList.toggle('is-active', b === btn));
    renderStaGameListView();
  });

  const buyBtn = document.getElementById('staDetailBuyBtn');
  if (buyBtn) buyBtn.addEventListener('click', async () => {
    if (!_openStaProduct) return;
    if (_openStaProduct.isOwner) { staHandleLoginClick(); return; }
    if (_openStaProduct.hasPendingOrder) {
      // Order sebelumnya masih PROCESSING — langsung buka layar pembayaran
      // yang sudah ada (server akan resume, bukan invoice baru), jangan
      // tampilkan modal pilih metode pembayaran lagi.
      try {
        const existing = await api(`/api/steam-accounts/purchase/pending?productId=${encodeURIComponent(_openStaProduct.id)}`);
        if (existing?.order) { openStaPurchaseDetail(existing.order, 'detail'); return; }
      } catch (e) { /* fallback ke modal biasa di bawah kalau gagal cek pending */ }
    }
    openStaMethodModal();
  });

  const confirmBtn = document.getElementById('staMethodConfirmBtn');
  if (confirmBtn) confirmBtn.addEventListener('click', startStaPurchase);

  const copyBtn = document.getElementById('staPayCopyBtn');
  if (copyBtn) copyBtn.addEventListener('click', () => {
    const num = document.getElementById('staPayVaNumber')?.textContent || '';
    if (!num || num === '-') return;
    navigator.clipboard?.writeText(num.replace(/\s+/g, ''));
    copyBtn.textContent = 'Tersalin!';
    setTimeout(() => { copyBtn.textContent = 'Salin Nomor'; }, 1500);
  });

  const payBackBtn = document.getElementById('staPurchaseDetailBackBtn');
  if (payBackBtn) payBackBtn.addEventListener('click', () => {
    stopStaTimers();
    showPage(_staPrevPage);
  });

  const cancelBtn = document.getElementById('staPayCancelBtn');
  if (cancelBtn) cancelBtn.addEventListener('click', cancelCurrentStaOrder);

  const openDiscordBtn = document.getElementById('staOpenDiscordBtn');
  if (openDiscordBtn) openDiscordBtn.addEventListener('click', () => {
    const url = _openStaOrder?.discordTicket?.url || 'https://discord.com/channels/@me';
    window.open ? window.open(url, '_blank') : (location.href = url);
  });

  const copyChannelBtn = document.getElementById('staCopyChannelBtn');
  if (copyChannelBtn) copyChannelBtn.addEventListener('click', () => {
    const name = _openStaOrder?.discordTicket?.channelName || '';
    if (!name) return;
    navigator.clipboard?.writeText(name);
    copyChannelBtn.textContent = 'Tersalin!';
    setTimeout(() => { copyChannelBtn.textContent = 'Salin Nama Channel'; }, 1500);
  });
}

function openStaMethodModal() {
  if (!_openStaProduct) return;
  if (_openStaProduct.status !== 'available') { alert('Akun ini sudah tidak tersedia.'); return; }
  _selectedStaMethod = null;
  document.getElementById('staMethodModalTitle').textContent = `Pilih Metode Pembayaran — ${_openStaProduct.name}`;
  document.getElementById('staMethodConfirmBtn').disabled = true;
  renderStaMethodList(_lastStaPaymentMethods);
  document.getElementById('staMethodModalBackdrop').style.display = 'flex';
}
function closeStaMethodModal() {
  document.getElementById('staMethodModalBackdrop').style.display = 'none';
}
window.openStaMethodModal = openStaMethodModal;
window.closeStaMethodModal = closeStaMethodModal;

function renderStaMethodList(methods) {
  const wrap = document.getElementById('staMethodList');
  if (!wrap) return;
  if (!methods.length) {
    wrap.innerHTML = '<div class="upg-error">Payment gateway sedang tidak tersedia. Coba lagi nanti.</div>';
    return;
  }
  wrap.innerHTML = methods.map(m => `
    <button type="button" class="upg-method-item" data-method="${m.key}">
      <span>${escapeHtml(m.label)}</span>
      <svg class="icon icon-16 upg-method-check"><use href="#ic-check"></use></svg>
    </button>
  `).join('');
  wrap.querySelectorAll('.upg-method-item').forEach(btn => {
    btn.addEventListener('click', () => {
      wrap.querySelectorAll('.upg-method-item').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      _selectedStaMethod = btn.dataset.method;
      document.getElementById('staMethodConfirmBtn').disabled = false;
    });
  });
}

async function startStaPurchase() {
  if (!_openStaProduct || !_selectedStaMethod) return;
  const btn = document.getElementById('staMethodConfirmBtn');
  btn.disabled = true;
  btn.textContent = 'Memproses...';
  try {
    const res = await api('/api/steam-accounts/purchase', {
      method: 'POST',
      body: JSON.stringify({ productId: _openStaProduct.id, method: _selectedStaMethod })
    });
    closeStaMethodModal();
    _staPrevPage = 'staDetail';
    openStaPurchaseDetail(res.order);
  } catch (e) {
    alert(e.message || 'Gagal membuat pesanan.');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Lanjutkan Pembayaran';
  }
}

function openStaPurchaseDetail(order, fromPage) {
  _openStaOrder = order;
  if (fromPage) _staPrevPage = fromPage;
  renderStaPurchaseDetail(order);
  showPage('staPurchaseDetail');
  stopStaTimers();
  if (order.status === 'pending') {
    _staCountdownTimer = setInterval(updateStaCountdown, 1000);
    _staPollTimer = setInterval(pollStaPurchaseStatus, 5000);
    updateStaCountdown();
  }
}

function stopStaTimers() {
  if (_staCountdownTimer) clearInterval(_staCountdownTimer);
  if (_staPollTimer) clearInterval(_staPollTimer);
  _staCountdownTimer = null;
  _staPollTimer = null;
}

// Baris status pengiriman DM kredensial di bawah "Pembayaran berhasil" (lihat
// _staDmStatusByOrder/handleStaCredentialsDmUpdate). Kosong selagi backend
// masih proses kirim (belum ada event masuk) — tidak ada state "loading"
// eksplisit karena pengirimannya cepat & TIDAK memblokir status pembayaran
// utama (pembayaran tetap dianggap sukses walau DM gagal terkirim).
function renderStaDmStatusHtml(orderId) {
  const dm = _staDmStatusByOrder[orderId];
  if (!dm) return '';
  if (dm.success) {
    return `<div class="sta-dm-status sta-dm-status--success"><svg class="icon icon-16"><use href="#ic-send"></use></svg> Akun sudah dikirimkan ke DM pribadi Discord kamu.</div>`;
  }
  return `<div class="sta-dm-status sta-dm-status--error"><svg class="icon icon-16"><use href="#ic-triangle-alert"></use></svg> Gagal mengirim ke DM: ${escapeHtml(dm.message || 'Alasan tidak diketahui.')} Kamu tetap bisa pakai tombol LOGIN AKUN di halaman produk ini.</div>`;
}

function renderStaPurchaseDetail(order) {
  document.getElementById('staPayTitle').textContent = order.productName;
  document.getElementById('staPayAmount').textContent = rupiah(order.totalPayment || order.amount);
  document.getElementById('staPayInvoice').textContent = order.orderId;
  document.getElementById('staPayMethod').textContent = staMethodLabel(order.paymentMethod);

  const badge = document.getElementById('staPayStatusBadge');
  badge.textContent = MP_STATUS_LABEL[order.status] || order.status;
  badge.className = 'upg-pay-status upg-pay-status--' + order.status;

  const qrWrap = document.getElementById('staPayQrWrap');
  const vaWrap = document.getElementById('staPayVaWrap');
  const resultWrap = document.getElementById('staPayResult');
  const ticketWrap = document.getElementById('staTicketResult');
  const cancelBtn = document.getElementById('staPayCancelBtn');
  if (cancelBtn) cancelBtn.style.display = order.status === 'pending' ? '' : 'none';
  ticketWrap.style.display = 'none';

  if (order.status === 'pending' && order.paymentNumber) {
    if (order.paymentMethod === 'qris') {
      qrWrap.style.display = '';
      vaWrap.style.display = 'none';
      const qrImgEl = document.getElementById('staPayQrImg');
      const qrErrEl = document.getElementById('staPayQrError');
      if (order.qrDataUrl) {
        qrImgEl.style.display = '';
        qrImgEl.src = order.qrDataUrl;
        if (qrErrEl) qrErrEl.style.display = 'none';
      } else {
        qrImgEl.style.display = 'none';
        if (qrErrEl) qrErrEl.style.display = '';
      }
    } else {
      qrWrap.style.display = 'none';
      vaWrap.style.display = '';
      document.getElementById('staPayVaLabel').textContent = staMethodLabel(order.paymentMethod);
      document.getElementById('staPayVaNumber').textContent = order.paymentNumber;
    }
    resultWrap.style.display = 'none';
  } else {
    qrWrap.style.display = 'none';
    vaWrap.style.display = 'none';
    resultWrap.style.display = '';
    if (order.status === 'completed') {
      resultWrap.className = 'upg-pay-result upg-pay-result--success';
      resultWrap.innerHTML = `<svg class="icon icon-18"><use href="#ic-circle-check-big"></use></svg> Pembayaran berhasil! Akun sudah bisa dipakai.`
        + renderStaDmStatusHtml(order.orderId);
      if (order.discordTicket) {
        document.getElementById('staTicketChannelName').textContent = order.discordTicket.channelName;
        ticketWrap.style.display = '';
      }
    } else if (order.status === 'expired') {
      resultWrap.className = 'upg-pay-result upg-pay-result--muted';
      resultWrap.innerHTML = `<svg class="icon icon-18"><use href="#ic-timer"></use></svg> Waktu pembayaran habis. Silakan beli lagi.
        <button class="btn-secondary upg-tx-detail-btn" style="margin-top:10px;" onclick="staRetryPurchase('${order.productId}')">COBA LAGI</button>`;
    } else {
      resultWrap.className = 'upg-pay-result upg-pay-result--danger';
      resultWrap.innerHTML = `<svg class="icon icon-18"><use href="#ic-circle-x"></use></svg> Pembayaran ${order.status === 'failed' ? 'gagal' : (MP_STATUS_LABEL[order.status] || order.status)}.
        <button class="btn-secondary upg-tx-detail-btn" style="margin-top:10px;" onclick="staRetryPurchase('${order.productId}')">COBA LAGI</button>`;
    }
  }
}

// ── "COBA LAGI" pada layar pembayaran FAILED/EXPIRED — balik ke halaman
// detail produk (reuse penuh openStaDetail biar carousel/game list ikut
// terisi benar, bukan cuma render tombol) & langsung buka lagi modal pilih
// metode pembayaran, TIDAK pernah menampilkan error teknis mentah ke user
// (poin 14 spec). ──
async function staRetryPurchase(productId) {
  try {
    const data = await api(`/api/steam-accounts/${productId}`);
    if (!data?.product) throw new Error('Produk tidak ditemukan.');
    await openStaDetail(data.product);
    openStaMethodModal();
  } catch (e) {
    showPage('steamaccounts');
  }
}

function updateStaCountdown() {
  if (!_openStaOrder || _openStaOrder.status !== 'pending') return;
  const remainMs = new Date(_openStaOrder.expiresAt).getTime() - Date.now();
  const el = document.getElementById('staPayCountdown');
  if (remainMs <= 0) { if (el) el.textContent = '00:00'; return; }
  const mm = String(Math.floor(remainMs / 60000)).padStart(2, '0');
  const ss = String(Math.floor((remainMs % 60000) / 1000)).padStart(2, '0');
  if (el) el.textContent = `${mm}:${ss}`;
}

async function pollStaPurchaseStatus() {
  if (!_openStaOrder || _openStaOrder.status !== 'pending') { stopStaTimers(); return; }
  try {
    const res = await api(`/api/steam-accounts/purchase/${encodeURIComponent(_openStaOrder.orderId)}`);
    handleStaOrderUpdate(res.order);
  } catch (e) { /* diam-diam, coba lagi 5 detik berikutnya */ }
}

function handleStaOrderUpdate(order) {
  if (!order) return;
  if (_openStaOrder && _openStaOrder.orderId === order.orderId) {
    _openStaOrder = order;
    renderStaPurchaseDetail(order);
    if (order.status !== 'pending') stopStaTimers();
  }
  if (document.getElementById('pageTransactions')?.style.display !== 'none') {
    loadTransactions();
  }
  // Akun jadi SOLD/owned begitu order completed — refresh grid & buy card
  // biar tombol "BELI AKUN" langsung berubah jadi "LOGIN AKUN" real-time.
  if (order.status === 'completed') loadSteamAccounts();
}

// Status pengiriman DM kredensial per-order — transient (cuma dipakai buat
// tampilan realtime selagi App terbuka, TIDAK di-fetch/di-restore dari
// backend), sesuai flow: Pembayaran berhasil -> Socket.IO -> App menampilkan
// "Akun sudah dikirimkan ke DM pribadi" (atau alasan spesifik kalau gagal).
let _staDmStatusByOrder = {};

function handleStaCredentialsDmUpdate(data) {
  if (!data?.orderId) return;
  _staDmStatusByOrder[data.orderId] = data;
  if (_openStaOrder && _openStaOrder.orderId === data.orderId) {
    renderStaPurchaseDetail(_openStaOrder);
  }
}

async function cancelCurrentStaOrder() {
  if (!_openStaOrder || _openStaOrder.status !== 'pending') return;
  if (!confirm('Batalkan pesanan ini? Kamu bisa beli lagi kapan saja kalau berubah pikiran.')) return;
  const btn = document.getElementById('staPayCancelBtn');
  btn.disabled = true;
  btn.textContent = 'Membatalkan...';
  try {
    const res = await api(`/api/steam-accounts/purchase/${encodeURIComponent(_openStaOrder.orderId)}/cancel`, { method: 'POST' });
    handleStaOrderUpdate(res.order);
  } catch (e) {
    alert(e.message || 'Gagal membatalkan pesanan.');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Batalkan Pesanan';
  }
}

// ══════════════════════════════════════════════════════════════════════════
// MARKETPLACE — "Product On Sale" (Dashboard) + berbaur di "New Games" +
// Detail Product + beli via KlikQRIS (modal QRIS, BUKAN halaman terpisah) +
// state "Tidak Ada Akses" utk Game/Bypass yang di-gate produk Marketplace.
// Pola SENGAJA semirip mungkin dengan blok STEAM ACCOUNTS/UPGRADE PAKET di
// atas (sama-sama KlikQRIS), TAPI beda total soal apa yang didapat user
// setelah lunas: bukan kredensial akun, tapi ENTITLEMENT akses ke Game/Bypass
// existing (lihat marketplaceManager.js/marketplaceOrderManager.js backend).
// ══════════════════════════════════════════════════════════════════════════
let _lastMktProducts = [];
let _lastMktPaymentMethods = [];
let _openMktProduct = null;     // produk yang lagi dibuka di halaman detail
let _openMktOrder = null;       // order yang lagi ditampilkan di modal QRIS
let _selectedMktMethod = null;
let _mktCountdownTimer = null;
let _mktPollTimer = null;
let _mktPrevPage = 'dashboard';
let _mktPayCloseable = true;    // dikunci (tidak bisa ditutup via klik backdrop) selagi memproses

const MKT_BADGE_CLASS = { hot: 'mkt-badge--hot', new: 'mkt-badge--new', sale: 'mkt-badge--sale' };

function mktMethodLabel(key) {
  const found = (_lastMktPaymentMethods || []).find(m => m.key === key);
  return found ? found.label : String(key || '-').toUpperCase();
}

function mktProductImage(p) { return p?.imageData || p?.imageUrl || ''; }

function mktBadgeHtml(badge) {
  if (!badge) return '';
  const key = String(badge).toLowerCase();
  const cls = MKT_BADGE_CLASS[key] || 'mkt-badge--custom';
  return `<span class="mkt-badge ${cls}">${escapeHtml(badge)}</span>`;
}

async function loadMarketplaceProducts() {
  try {
    const data = await api('/api/marketplace/products');
    _lastMktPaymentMethods = data.paymentMethods || [];
    applyMktProductsUpdate(data.products || []);
  } catch (e) {
    // Diam-diam gagal — section "Product On Sale" cukup disembunyikan kalau
    // memang belum ada produk aktif sama sekali (lihat renderMktOnSaleGrid).
  }
}

function applyMktProductsUpdate(products) {
  _lastMktProducts = products || [];
  // Produk Marketplace HANYA tampil di section "Product On Sale" — tidak lagi
  // dibaurkan ke grid "New Games" (New Games murni berisi allGames).
  renderMktOnSaleGrid(_lastMktProducts);

  // Kalau user lagi buka halaman Detail produk ini, refresh datanya juga
  // (harga/badge/status bisa berubah kapan saja dari Admin Web/pembelian).
  if (_openMktProduct) {
    const fresh = _lastMktProducts.find(p => p.id === _openMktProduct.id);
    if (fresh) {
      _openMktProduct = fresh;
      renderMktBuyBar(fresh);
    } else if (document.getElementById('pageMarketplaceDetail')?.style.display !== 'none') {
      _openMktProduct = null;
      alert('Product ini sudah tidak tersedia (dinonaktifkan/dihapus Admin).');
      showPage(_mktPrevPage);
    }
  }
}

// ── Grid "Product On Sale" (Dashboard, DI ATAS "New Games") ──
function renderMktOnSaleGrid(products) {
  if (!els.mktOnSaleGrid || !els.mktOnSaleSection) return;
  if (!products.length) {
    els.mktOnSaleSection.style.display = 'none';
    return;
  }
  els.mktOnSaleSection.style.display = '';
  els.mktOnSaleGrid.innerHTML = products.map((p, i) => renderMktCardHtml(p)).join('');
  els.mktOnSaleGrid.querySelectorAll('.mkt-card[data-id]').forEach(card => {
    card.addEventListener('click', () => openMarketplaceDetail(card.dataset.id));
  });
}

function renderMktCardHtml(p, extraClass = '') {
  const img = mktProductImage(p);
  const imgTag = img ? `<img src="${escapeHtml(img)}" alt="${escapeHtml(p.name)}" loading="lazy">` : '';
  return `
  <div class="mkt-card ${extraClass}" data-id="${p.id}">
    <div class="mkt-card-art">
      ${imgTag}
      <div class="mkt-badge-slot">${mktBadgeHtml(p.badge)}</div>
    </div>
    <div class="mkt-card-info">
      <div class="mkt-card-title" title="${escapeHtml(p.name)}">${escapeHtml(p.name)}</div>
      <div class="mkt-card-desc">${escapeHtml(p.description || '')}</div>
      <div class="mkt-card-footer">
        ${p.isOwner
          ? `<span class="mkt-card-owned-tag"><svg class="icon icon-14"><use href="#ic-circle-check-big"></use></svg> Dimiliki</span>`
          : `<span class="mkt-card-price">${rupiah(p.price)}</span>`}
        <span class="mkt-card-arrow"><svg class="icon icon-16"><use href="#ic-arrow-right"></use></svg></span>
      </div>
    </div>
  </div>`;
}

// ── Halaman Detail Produk Marketplace ──
async function openMarketplaceDetail(productId) {
  const activeLink = els.navLinks.find(a => a.classList.contains('active'));
  _mktPrevPage = activeLink ? activeLink.dataset.page : 'dashboard';

  const cached = _lastMktProducts.find(p => p.id === productId);
  if (cached) {
    _openMktProduct = cached;
    renderMktHero(cached);
    renderMktHeadline(cached);
    renderMktSidebar(cached);
    renderMktBuyBar(cached);
  }
  showPage('marketplaceDetail');
  const mainEl = document.querySelector('.main');
  if (mainEl) mainEl.scrollTop = 0;

  try {
    const data = await api(`/api/marketplace/products/${productId}`);
    if (!data?.product) return;
    _openMktProduct = data.product;
    renderMktHero(data.product);
    renderMktHeadline(data.product);
    renderMktSidebar(data.product);
    renderMktContentSections(data.content || { games: [], bypasses: [] });
    renderMktBuyBar(data.product, data.pendingOrder);
  } catch (e) {
    alert(e.message || 'Gagal memuat detail produk.');
    showPage(_mktPrevPage);
  }
}
window.openMarketplaceDetail = openMarketplaceDetail;

function renderMktHero(p) {
  const wrap = document.getElementById('mktHeroWrap');
  if (!wrap) return;
  const img = mktProductImage(p);
  document.getElementById('mktHeroBadgeSlot').innerHTML = mktBadgeHtml(p.badge);
  if (!img) { wrap.style.backgroundImage = ''; return; }
  const probe = new Image();
  probe.onload = () => { wrap.style.backgroundImage = `url('${img}')`; };
  probe.onerror = () => { wrap.style.backgroundImage = ''; };
  probe.src = img;
}

function renderMktHeadline(p) {
  document.getElementById('mktDetailTitle').textContent = p.name;
  document.getElementById('mktDetailDescription').textContent = p.description?.trim() || '-';
  document.getElementById('mktDetailStatRow').innerHTML =
    `<span><svg class="icon icon-14"><use href="#ic-tag"></use></svg> ${rupiah(p.price)}</span>`;
}

function renderMktSidebar(p) {
  const statusBadge = document.getElementById('mktSideStatusBadge');
  const statusRows = document.getElementById('mktSideStatusRows');
  if (p.isOwner) {
    statusBadge.textContent = 'Dimiliki';
    statusBadge.className = 'mkt-badge-status mkt-badge-status--owned';
    statusRows.innerHTML = `<div class="mkt-side-row"><span>Sumber Akses</span><b>${p.accessSource === 'whitelist' ? 'Whitelist Admin' : 'Pembelian'}</b></div>`;
  } else if (p.hasPendingOrder) {
    statusBadge.textContent = 'Diproses';
    statusBadge.className = 'mkt-badge-status mkt-badge-status--pending';
    statusRows.innerHTML = `<div class="mkt-side-row"><span>Status</span><b>Menunggu pembayaran</b></div>`;
  } else {
    statusBadge.textContent = 'Tersedia';
    statusBadge.className = 'mkt-badge-status mkt-badge-status--available';
    statusRows.innerHTML = `<div class="mkt-side-row"><span>Status</span><b>Belum dibeli</b></div>`;
  }

  const infoRows = document.getElementById('mktSideInfoRows');
  infoRows.innerHTML = `<div class="mkt-side-row"><span>Harga</span><b>${rupiah(p.price)}</b></div>`;
}

// ── Section "Yang Kamu Dapat" — full width DI BAWAH hero. Kategori kosong
// TIDAK dirender ke DOM sama sekali (bukan disembunyikan via CSS), sesuai §4.7. ──
function renderMktContentSections(content) {
  const wrap = document.getElementById('mktContentSection');
  if (!wrap) return;
  const games = content.games || [];
  const bypasses = content.bypasses || [];

  const contentCard = (item) => {
    const img = item.imageUrl || '';
    return `
    <div class="mkt-content-card" title="${escapeHtml(item.name)}">
      <div class="mkt-content-card-img"${img ? ` style="background-image:url('${escapeHtml(img)}')"` : ''}></div>
      <div class="mkt-content-card-name">${escapeHtml(item.name)}</div>
    </div>`;
  };

  let html = `<h3 class="mkt-detail-section-title"><svg class="icon icon-18"><use href="#ic-package"></use></svg> Yang Kamu Dapat</h3>`;

  if (!games.length && !bypasses.length) {
    html += `<div class="mkt-content-empty"><svg class="icon icon-32" style="opacity:.4"><use href="#ic-package"></use></svg> Belum ada konten pada produk ini.</div>`;
    wrap.innerHTML = html;
    return;
  }

  const singleColumn = !(games.length && bypasses.length);
  html += `<div class="mkt-content-columns${singleColumn ? ' mkt-content-columns--single' : ''}">`;

  if (games.length) {
    html += `
    <div class="mkt-content-group mkt-content-group--game">
      <div class="mkt-content-group-title"><svg class="icon icon-16"><use href="#ic-gamepad-2"></use></svg> Akses Game</div>
      <div class="mkt-content-grid">${games.map(contentCard).join('')}</div>
    </div>`;
  }
  if (bypasses.length) {
    html += `
    <div class="mkt-content-group mkt-content-group--bypass">
      <div class="mkt-content-group-title"><svg class="icon icon-16"><use href="#ic-shield-check"></use></svg> Akses Bypass</div>
      <div class="mkt-content-grid">${bypasses.map(contentCard).join('')}</div>
    </div>`;
  }
  html += `</div>`;
  wrap.innerHTML = html;
}

// ── Floating Buy Bar — state SELALU dari data backend (isOwner/hasPendingOrder). ──
function renderMktBuyBar(p, pendingOrder) {
  const priceLabelEl = document.getElementById('mktFloatPriceLabel');
  const priceValueEl = document.getElementById('mktDetailPrice');
  const statusEl = document.getElementById('mktBuyStatus');
  const btn = document.getElementById('mktDetailBuyBtn');
  const labelEl = document.getElementById('mktDetailBuyLabel');
  if (!btn) return;

  if (p.isOwner) {
    if (priceLabelEl) priceLabelEl.textContent = 'PRODUK DIMILIKI';
    priceValueEl.textContent = rupiah(p.price);
    statusEl.innerHTML = '<span class="mp-status-dot"></span> Kamu sudah memiliki akses ini';
    statusEl.className = 'mkt-float-bar-status mkt-float-bar-status--owned';
    btn.disabled = true;
    btn.className = 'mkt-float-bar-btn mkt-float-bar-btn--owned';
    labelEl.textContent = 'SUDAH DIBELI';
    btn.onclick = null;
  } else if (p.hasPendingOrder) {
    if (priceLabelEl) priceLabelEl.textContent = 'HARGA';
    priceValueEl.textContent = rupiah(p.price);
    statusEl.innerHTML = '<span class="mp-status-dot"></span> Menunggu pembayaran';
    statusEl.className = 'mkt-float-bar-status mkt-float-bar-status--processing';
    btn.disabled = false;
    btn.className = 'mkt-float-bar-btn mkt-float-bar-btn--processing';
    labelEl.textContent = 'PEMBAYARAN DIPROSES';
    btn.onclick = () => resumeMktPendingOrder(p.id);
  } else {
    if (priceLabelEl) priceLabelEl.textContent = 'HARGA';
    priceValueEl.textContent = rupiah(p.price);
    statusEl.innerHTML = '<span class="mp-status-dot"></span> Available';
    statusEl.className = 'mkt-float-bar-status';
    btn.disabled = false;
    btn.className = 'mkt-float-bar-btn';
    labelEl.textContent = 'BELI SEKARANG';
    btn.onclick = () => openMktMethodModal();
  }
}

async function resumeMktPendingOrder(productId) {
  try {
    const data = await api(`/api/marketplace/purchase/pending?productId=${encodeURIComponent(productId)}`);
    if (data?.order) openMktPayModal(data.order);
  } catch (e) {
    alert(e.message || 'Gagal memuat status pembayaran.');
  }
}

// ── Modal 1/2: Pilih Metode Pembayaran ──
function openMktMethodModal() {
  if (!_openMktProduct) return;
  _selectedMktMethod = null;
  document.getElementById('mktMethodModalTitle').textContent = `Pilih Metode Pembayaran — ${_openMktProduct.name}`;
  document.getElementById('mktMethodConfirmBtn').disabled = true;
  renderMktMethodList(_lastMktPaymentMethods || []);
  document.getElementById('mktMethodModalBackdrop').style.display = 'flex';
}
function closeMktMethodModal() {
  document.getElementById('mktMethodModalBackdrop').style.display = 'none';
}
window.closeMktMethodModal = closeMktMethodModal;

function renderMktMethodList(methods) {
  const wrap = document.getElementById('mktMethodList');
  if (!wrap) return;
  if (!methods.length) {
    wrap.innerHTML = '<div class="upg-error">Payment gateway sedang tidak tersedia. Coba lagi nanti.</div>';
    return;
  }
  wrap.innerHTML = methods.map(m => `
    <button type="button" class="upg-method-item" data-method="${m.key}">
      <span>${escapeHtml(m.label)}</span>
      <svg class="icon icon-16 upg-method-check"><use href="#ic-check"></use></svg>
    </button>
  `).join('');
  wrap.querySelectorAll('.upg-method-item').forEach(b => {
    b.addEventListener('click', () => {
      wrap.querySelectorAll('.upg-method-item').forEach(x => x.classList.remove('active'));
      b.classList.add('active');
      _selectedMktMethod = b.dataset.method;
      document.getElementById('mktMethodConfirmBtn').disabled = false;
    });
  });
}

async function startMktPurchase() {
  if (!_openMktProduct || !_selectedMktMethod) return;
  const btn = document.getElementById('mktMethodConfirmBtn');
  btn.disabled = true;
  btn.textContent = 'Memproses...';
  try {
    const res = await api('/api/marketplace/purchase', {
      method: 'POST',
      body: JSON.stringify({ productId: _openMktProduct.id, method: _selectedMktMethod })
    });
    closeMktMethodModal();
    openMktPayModal(res.order);
  } catch (e) {
    alert(e.message || 'Gagal membuat pesanan.');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Lanjutkan Pembayaran';
  }
}

// ── Modal 2/2: QRIS + status (di dalam MODAL, bukan halaman terpisah) ──
function openMktPayModal(order) {
  _openMktOrder = order;
  renderMktPayModal(order);
  document.getElementById('mktPayModalBackdrop').style.display = 'flex';
  stopMktTimers();
  if (order.status === 'pending') {
    _mktPayCloseable = true;
    _mktCountdownTimer = setInterval(updateMktCountdown, 1000);
    _mktPollTimer = setInterval(pollMktPurchaseStatus, 5000);
    updateMktCountdown();
  }
}
function closeMktPayModal() {
  if (!_mktPayCloseable) return;
  document.getElementById('mktPayModalBackdrop').style.display = 'none';
  stopMktTimers();
}
window.closeMktPayModal = closeMktPayModal;

function stopMktTimers() {
  if (_mktCountdownTimer) clearInterval(_mktCountdownTimer);
  if (_mktPollTimer) clearInterval(_mktPollTimer);
  _mktCountdownTimer = null;
  _mktPollTimer = null;
}

function renderMktPayModal(order) {
  document.getElementById('mktPayTitle').textContent = order.productName || _openMktProduct?.name || 'Produk';
  document.getElementById('mktPayAmount').textContent = rupiah(order.totalPayment || order.amount);
  document.getElementById('mktPayInvoice').textContent = order.orderId;
  document.getElementById('mktPayMethod').textContent = mktMethodLabel(order.paymentMethod);

  const badge = document.getElementById('mktPayStatusBadge');
  badge.textContent = UPG_STATUS_LABEL[order.status] || order.status;
  badge.className = 'upg-pay-status upg-pay-status--' + order.status;

  const qrWrap = document.getElementById('mktPayQrWrap');
  const resultWrap = document.getElementById('mktPayResult');
  const cancelBtn = document.getElementById('mktPayCancelBtn');
  if (cancelBtn) cancelBtn.style.display = order.status === 'pending' ? '' : 'none';

  if (order.status === 'pending' && order.paymentNumber) {
    qrWrap.style.display = '';
    resultWrap.style.display = 'none';
    const qrImgEl = document.getElementById('mktPayQrImg');
    const qrErrEl = document.getElementById('mktPayQrError');
    if (order.qrDataUrl) {
      qrImgEl.style.display = '';
      qrImgEl.src = order.qrDataUrl;
      if (qrErrEl) qrErrEl.style.display = 'none';
    } else {
      qrImgEl.style.display = 'none';
      if (qrErrEl) qrErrEl.style.display = '';
    }
    _mktPayCloseable = true;
  } else {
    qrWrap.style.display = 'none';
    resultWrap.style.display = '';
    if (order.status === 'completed') {
      resultWrap.className = 'upg-pay-result upg-pay-result--success';
      resultWrap.innerHTML = `<svg class="icon icon-18"><use href="#ic-circle-check-big"></use></svg> Pembayaran berhasil! Akses ke produk ini sudah aktif — cek Game/Bypass terkait, tombol Install sudah bisa dipakai.`;
      _mktPayCloseable = true;
    } else if (order.status === 'expired') {
      resultWrap.className = 'upg-pay-result upg-pay-result--muted';
      resultWrap.innerHTML = `<svg class="icon icon-18"><use href="#ic-timer"></use></svg> Waktu pembayaran habis. Silakan buat pesanan baru.`;
      _mktPayCloseable = true;
    } else {
      resultWrap.className = 'upg-pay-result upg-pay-result--danger';
      resultWrap.innerHTML = `<svg class="icon icon-18"><use href="#ic-circle-x"></use></svg> Pesanan ${UPG_STATUS_LABEL[order.status] || order.status}.`;
      _mktPayCloseable = true;
    }
    stopMktTimers();
  }
}

function updateMktCountdown() {
  if (!_openMktOrder || _openMktOrder.status !== 'pending') return;
  const remainMs = new Date(_openMktOrder.expiresAt).getTime() - Date.now();
  const el = document.getElementById('mktPayCountdown');
  if (remainMs <= 0) { if (el) el.textContent = '00:00'; return; }
  const mm = String(Math.floor(remainMs / 60000)).padStart(2, '0');
  const ss = String(Math.floor((remainMs % 60000) / 1000)).padStart(2, '0');
  if (el) el.textContent = `${mm}:${ss}`;
}

async function pollMktPurchaseStatus() {
  if (!_openMktOrder || _openMktOrder.status !== 'pending') return;
  try {
    const res = await api(`/api/marketplace/purchase/${encodeURIComponent(_openMktOrder.orderId)}`);
    handleMktOrderUpdate(res.order);
  } catch (e) { /* diam-diam, WS/timer berikutnya akan coba lagi */ }
}

function handleMktOrderUpdate(order) {
  if (!order) return;
  const isThisOrderOpen = _openMktOrder && _openMktOrder.orderId === order.orderId;
  if (isThisOrderOpen) {
    _openMktOrder = order;
    renderMktPayModal(order);
  }
  // Order lunas -> refresh detail produk (isOwner) & grid Product On Sale +
  // Game/Bypass terkait supaya tombol Install langsung berubah realtime.
  if (order.status === 'completed') {
    loadMarketplaceProducts();
    loadGames();
    loadBypasses();
  }
  // FIX: halaman Riwayat Transaksi (Transaksi APP) sebelumnya tidak pernah
  // ikut ter-refresh saat status order Marketplace berubah (pending ->
  // completed/expired/dll) — beda dengan Upgrade Paket & Steam Account yang
  // sudah punya refresh serupa (lihat handleTransactionUpdate/handleStaOrderUpdate).
  // Kalau halaman ini sedang dibuka, muat ulang supaya baris & status order
  // Marketplace langsung sinkron tanpa perlu pindah halaman/refresh manual.
  if (document.getElementById('pageTransactions')?.style.display !== 'none') {
    loadTransactions();
  }
}

// ── Event 'marketplace:access:update' — entitlement user berubah REALTIME:
// Admin grant/revoke Whitelist, ATAU order user lain/user ini baru saja lunas
// (entitlement dibuat backend). Payload ini personalized per-koneksi (isOwner/
// accessSource per user), jadi TIDAK dipakai langsung — cukup jadi sinyal
// "ada perubahan akses" lalu refetch REST yang sudah personalized (pola sama
// dengan steamAccounts:products:update di atas). Efeknya: Game/Bypass yang
// di-gate Marketplace (marketplaceProductIds) langsung pindah dari "Tidak Ada
// Akses" ke bisa Install/Download TANPA user perlu refresh/buka ulang App —
// termasuk saat Admin mencabut Whitelist (akses langsung hilang realtime).
function handleMktAccessUpdate(data) {
  loadMarketplaceProducts();
  loadGames();
  loadBypasses();

  // Kalau user lagi buka halaman Detail produk yang aksesnya baru berubah
  // (atau tidak tahu produk mana yang berubah -> refresh saja yang lagi
  // terbuka, aman & murah), sync ulang sidebar status + tombol Beli/Install.
  const isDetailOpen = document.getElementById('pageMarketplaceDetail')?.style.display !== 'none';
  if (isDetailOpen && _openMktProduct) {
    const affectsOpen = !data?.productId || data.productId === _openMktProduct.id;
    if (affectsOpen) {
      api(`/api/marketplace/products/${_openMktProduct.id}`)
        .then((res) => {
          if (!res?.product) return;
          _openMktProduct = res.product;
          renderMktSidebar(res.product);
          renderMktBuyBar(res.product, res.pendingOrder);
        })
        .catch(() => { /* diam-diam, loadMarketplaceProducts() di atas tetap jalan sebagai fallback */ });
    }
  }
}

async function cancelCurrentMktOrder() {
  if (!_openMktOrder || _openMktOrder.status !== 'pending') return;
  if (!confirm('Batalkan pesanan ini? Kamu bisa beli lagi kapan saja kalau berubah pikiran.')) return;
  const btn = document.getElementById('mktPayCancelBtn');
  btn.disabled = true;
  btn.textContent = 'Membatalkan...';
  try {
    const res = await api(`/api/marketplace/purchase/${encodeURIComponent(_openMktOrder.orderId)}/cancel`, { method: 'POST' });
    handleMktOrderUpdate(res.order);
  } catch (e) {
    alert(e.message || 'Gagal membatalkan pesanan.');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Batalkan Pesanan';
  }
}

// ── Modal "Tidak Ada Akses" (§4.8) — dibuka dari tombol locked Marketplace di
// halaman Detail Game/Bypass (lihat applyDetailAccessState di atas). ──
let _mktLockedTargetProductId = null;
function openMktLockedModal(item) {
  const productIds = Array.isArray(item.marketplaceProductIds) ? item.marketplaceProductIds : [];
  const pid = productIds[0] || null;
  _mktLockedTargetProductId = pid;
  const known = pid ? _lastMktProducts.find(p => p.id === pid) : null;
  document.getElementById('mktLockedProductName').textContent = known ? known.name : (pid ? 'Product Marketplace terkait' : '—');
  document.getElementById('mktLockedModalBackdrop').style.display = 'flex';
}
function closeMktLockedModal() {
  document.getElementById('mktLockedModalBackdrop').style.display = 'none';
}
window.closeMktLockedModal = closeMktLockedModal;

function wireMarketplace() {
  const backBtn = document.getElementById('mktDetailBackBtn');
  if (backBtn) backBtn.addEventListener('click', () => showPage(_mktPrevPage));

  const confirmBtn = document.getElementById('mktMethodConfirmBtn');
  if (confirmBtn) confirmBtn.addEventListener('click', startMktPurchase);

  const cancelBtn = document.getElementById('mktPayCancelBtn');
  if (cancelBtn) cancelBtn.addEventListener('click', cancelCurrentMktOrder);

  const lockedViewBtn = document.getElementById('mktLockedViewBtn');
  if (lockedViewBtn) lockedViewBtn.addEventListener('click', () => {
    closeMktLockedModal();
    if (_mktLockedTargetProductId) openMarketplaceDetail(_mktLockedTargetProductId);
  });
}

document.addEventListener('DOMContentLoaded', () => {
  checkMaintenanceMode();
  checkAppUpdate();
  grabElements();
  wireTitlebar();
  wireNavigation();
  wireSearch();
  wireGamesRoleFilter();
  wireGamesTypeFilter();
  wireBypassesRoleFilter();
  wireBypassesTypeFilter();
  wireDashCategoryFilter();
  wireDetailPage();
  wireTutorialCategoryFilter();
  wireTutorialSearch();
  wireTutorialDetailNav();
  wireHistoriTabs();
  wirePackageCard();
  wireNotifBell();
  wireVoucherClaim();
  wireSystemDetection();
  wireEditProfile();
  wireUpgradePaket();
  wireSteamAccounts();
  wireMarketplace();
  wireActiveTools();
  loadActiveToolsConfig();
  wireCloudFix();
  loadCloudFixConfig();
  loadConfig();
  tryAutoLogin();
});
// ══════════════════════════════════════════════════════════════════════════
// MAINTENANCE MODE — cek status dari backend (/api/maintenance-status) setiap
// app dibuka, dan realtime lewat WS (event `maintenance:config`) selama app
// sedang berjalan & user login. TIDAK ADA tombol close/skip/kembali sama
// sekali kalau maintenance aktif & user bukan admin/whitelist — beda dengan
// App Update yang punya varian "boleh dilewati".
// ══════════════════════════════════════════════════════════════════════════
let _maintenancePollTimer = null;
let _maintenanceActive = false; // status TERKINI (dipakai buat tahu kapan harus "kembali normal" tanpa reload)

function getStoredAuthToken() {
  try { return localStorage.getItem('token') || null; } catch (e) { return null; }
}

async function fetchMaintenanceStatus() {
  try {
    const token = getStoredAuthToken();
    const headers = token ? { Authorization: `Bearer ${token}` } : {};
    const res = await fetch(SERVER_URL + '/api/maintenance-status', { headers });
    if (!res.ok) return null;
    return await res.json();
  } catch (e) {
    return null;
  }
}

// Titik masuk utama — dipanggil PALING AWAL saat DOMContentLoaded, bahkan
// sebelum checkAppUpdate(), supaya kalau Maintenance aktif, overlay-nya sudah
// terpasang duluan mengunci layar sebelum user sempat interaksi apapun
// (termasuk sebelum login).
async function checkMaintenanceMode() {
  const cfg = await fetchMaintenanceStatus();
  if (cfg) applyMaintenanceConfig(cfg);

  // Poll berkala — jaga-jaga kalau WS belum konek (user belum login) atau
  // koneksi WS sempat putus, App tetap tahu perubahan status dalam waktu wajar.
  clearInterval(_maintenancePollTimer);
  _maintenancePollTimer = setInterval(async () => {
    const fresh = await fetchMaintenanceStatus();
    if (fresh) applyMaintenanceConfig(fresh);
  }, 2 * 60 * 1000);
}

function applyMaintenanceConfig(cfg) {
  if (!cfg) return;
  const shouldLock = !!cfg.enabled && !cfg.bypass;
  _maintenanceActive = shouldLock;
  if (shouldLock) renderMaintenanceOverlay(cfg);
  else hideMaintenanceOverlay();
}

function hideMaintenanceOverlay() {
  const el = document.getElementById('maintenanceOverlay');
  if (!el) return;
  el.style.display = 'none';
  el.innerHTML = '';
}

function formatEstimatedCompletion(iso) {
  if (!iso) return null;
  const d = new Date(iso);
  if (isNaN(d.getTime())) return null;
  try {
    return d.toLocaleString('id-ID', { dateStyle: 'full', timeStyle: 'short' });
  } catch (e) {
    return d.toString();
  }
}

// TIDAK ADA parameter/opsi "blocking: false" seperti App Update — Maintenance
// Mode SELALU full-lock total tanpa kecuali begitu fungsi ini dipanggil
// (pemanggilnya, applyMaintenanceConfig, sudah memastikan cuma dipanggil kalau
// memang harus mengunci). Tidak ada tombol close/skip/kembali sama sekali.
function renderMaintenanceOverlay(cfg) {
  const el = document.getElementById('maintenanceOverlay');
  if (!el) return;

  const etaLabel = formatEstimatedCompletion(cfg.estimatedCompletion);
  const bannerHtml = cfg.bannerUrl
    ? `<img class="mo-banner" src="${escapeHtml(cfg.bannerUrl)}" alt="Maintenance" onerror="this.remove()">`
    : '';

  el.innerHTML = `
    <div class="mo-card">
      ${bannerHtml}
      <div class="mo-body">
        <div class="mo-icon-wrap">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>
        </div>
        <div class="mo-title">${escapeHtml(cfg.title || 'Sedang Maintenance')}</div>
        ${cfg.description ? `<div class="mo-desc">${escapeHtml(cfg.description)}</div>` : ''}
        ${cfg.message ? `<div class="mo-msg">${escapeHtml(cfg.message)}</div>` : ''}
        ${etaLabel ? `
          <div class="mo-eta">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
            Estimasi selesai: ${escapeHtml(etaLabel)}
          </div>
        ` : ''}
        <div class="mo-spinner"></div>
      </div>
    </div>
  `;
  el.style.display = 'flex';
}

// ══════════════════════════════════════════════════════════════════════════
// AUTO UPDATE / FORCE UPDATE — cek versi terbaru dari GitHub Release
// (lewat backend, /api/app-update) setiap app dibuka, dan realtime lewat WS
// (event `app-update:config`) selama app sedang berjalan & user login.
// ══════════════════════════════════════════════════════════════════════════
let _appUpdateCurrentVersion = null;
let _appUpdateConfigCache = null;
let _appUpdatePollTimer = null;
let _appUpdateDownloading = false;
let _appUpdateLastFailedTarget = null; // versi yang gagal diterapkan otomatis di percobaan sebelumnya

function compareAppVersions(a, b) {
  const norm = (v) => String(v || '0').trim().replace(/^v/i, '').split(/[.\-+]/).map(s => {
    const n = parseInt(s, 10);
    return Number.isFinite(n) ? n : 0;
  });
  const pa = norm(a), pb = norm(b);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const x = pa[i] || 0, y = pb[i] || 0;
    if (x > y) return 1;
    if (x < y) return -1;
  }
  return 0;
}

function formatBytesAU(bytes) {
  if (!bytes || bytes <= 0) return '0 KB';
  const units = ['B', 'KB', 'MB', 'GB'];
  let i = 0, n = bytes;
  while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
  return `${n.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}

function formatEtaAU(sec) {
  if (sec === null || sec === undefined || !isFinite(sec)) return '—';
  if (sec < 60) return `${Math.max(1, Math.round(sec))} detik`;
  const m = Math.floor(sec / 60), s = Math.round(sec % 60);
  return `${m} menit ${s} detik`;
}

async function getCurrentAppVersion() {
  if (_appUpdateCurrentVersion) return _appUpdateCurrentVersion;
  try {
    if (window.electronAPI?.getAppVersion) {
      _appUpdateCurrentVersion = await window.electronAPI.getAppVersion();
    }
  } catch (e) { /* noop */ }
  return _appUpdateCurrentVersion || '0.0.0';
}

async function fetchAppUpdateConfig() {
  try {
    const res = await fetch(SERVER_URL + '/api/app-update');
    if (!res.ok) return null;
    return await res.json();
  } catch (e) {
    return null;
  }
}

// Titik masuk utama — dipanggil paling awal saat DOMContentLoaded, SEBELUM
// bagian app lain di-wire, supaya kalau Force Update aktif, overlay sudah
// terpasang duluan mengunci layar sebelum user sempat interaksi apapun.
async function checkAppUpdate() {
  // Cek dulu hasil auto-update SEBELUMNYA (kalau ada) — supaya kalau ternyata
  // gagal diterapkan otomatis, App kasih pesan yang jelas ke user alih-alih
  // diam-diam masuk ke alur silent yang sama lagi berulang-ulang ("loop").
  // Kalau berhasil, ini juga yang memastikan marker-nya dibersihkan sehingga
  // popup update TIDAK muncul lagi setelah versi baru benar-benar aktif.
  try {
    const pending = await window.electronAPI?.checkPendingUpdateResult?.();
    if (pending?.status === 'failed') {
      _appUpdateLastFailedTarget = pending.targetVersion || null;
    }
  } catch (e) { /* noop */ }

  const cfg = await fetchAppUpdateConfig();
  if (!cfg) return; // server/DB belum siap — jangan blokir app cuma karena network hiccup
  _appUpdateConfigCache = cfg;
  await applyAppUpdateConfig(cfg);

  // Poll berkala (di luar WS, supaya tetap jalan walau user belum login / WS belum
  // konek) — cukup jarang karena perubahan lewat WS realtime saat user sudah login.
  clearInterval(_appUpdatePollTimer);
  _appUpdatePollTimer = setInterval(async () => {
    // Jangan re-render overlay kalau lagi download/install — kalau tidak,
    // progress bar & tombol "Memasang..." bisa ke-reset di tengah proses
    // cuma karena poll ini kebetulan nembak di saat yang sama.
    if (_appUpdateDownloading) return;
    const fresh = await fetchAppUpdateConfig();
    if (fresh) { _appUpdateConfigCache = fresh; applyAppUpdateConfig(fresh); }
  }, 5 * 60 * 1000);
}

async function applyAppUpdateConfig(cfg) {
  if (!cfg) return;
  // Lagi download/install → jangan sentuh overlay sama sekali (dari sumber
  // manapun: polling, WS realtime admin, dst) supaya progress bar/tombol
  // tidak ke-reset di tengah proses yang sedang berjalan.
  if (_appUpdateDownloading) return;
  const currentVersion = await getCurrentAppVersion();
  const isNewer = compareAppVersions(cfg.latestVersion, currentVersion) > 0;

  if (!isNewer) { hideAppUpdateOverlay(); return; }

  const previousAttemptFailed = _appUpdateLastFailedTarget && compareAppVersions(_appUpdateLastFailedTarget, currentVersion) <= 0;

  if (cfg.forceUpdateEnabled) {
    renderAppUpdateOverlay(cfg, currentVersion, { blocking: true, previousAttemptFailed });
  } else if (cfg.autoUpdateEnabled) {
    // Update tersedia tapi tidak dipaksa — tetap tampilkan halaman update
    // (sesuai permintaan: "Jika ada versi baru, tampilkan halaman update"),
    // namun TIDAK blocking — hanya saja tanpa tombol close pun tetap aman
    // dilewati user lewat overlay ini sendiri via tombol "Nanti Saja".
    renderAppUpdateOverlay(cfg, currentVersion, { blocking: false, previousAttemptFailed });
  } else {
    hideAppUpdateOverlay();
  }
}

function hideAppUpdateOverlay() {
  const el = document.getElementById('appUpdateOverlay');
  if (!el) return;
  el.style.display = 'none';
  el.classList.remove('au-blocking');
  el.innerHTML = '';
}

function renderAppUpdateOverlay(cfg, currentVersion, { blocking, previousAttemptFailed }) {
  const el = document.getElementById('appUpdateOverlay');
  if (!el) return;

  const sizeLabel = cfg.fileSizeLabel || (cfg.fileSize ? formatBytesAU(cfg.fileSize) : null);
  const changelogHtml = cfg.changelog
    ? escapeHtmlAU(cfg.changelog)
    : 'Tidak ada catatan perubahan untuk versi ini.';

  const failedNoticeHtml = previousAttemptFailed ? `
      <div class="au-error-box au-show" style="position:static;margin-bottom:14px;">
        <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0;margin-top:1px;"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
        <span>Update otomatis sebelumnya tidak berhasil diterapkan. Kamu bisa coba lagi, atau download &amp; install manual dari tombol di bawah.</span>
      </div>` : '';

  el.innerHTML = `
    <div class="au-card">
      <div class="au-icon-wrap">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 17V3"/><path d="m6 11 6 6 6-6"/><path d="M19 21H5"/></svg>
      </div>
      <div class="au-title">${blocking ? 'Update Wajib Tersedia' : 'Update Tersedia'}</div>
      <div class="au-msg" id="auMsg">${escapeHtmlAU(cfg.forceUpdateMessage || 'Ada versi baru aplikasi. Silakan update untuk melanjutkan.')}</div>
      <div class="au-versions">
        <span>Versi kamu: <span class="au-version-pill">${escapeHtmlAU(currentVersion)}</span></span>
        <span>→</span>
        <span>Terbaru: <span class="au-version-pill au-latest">${escapeHtmlAU(cfg.latestVersion)}</span></span>
      </div>
      ${sizeLabel ? `<div class="au-meta-row"><span>Ukuran file</span><span>${escapeHtmlAU(sizeLabel)}</span></div>` : ''}
      ${failedNoticeHtml}
      <div class="au-changelog">${changelogHtml}</div>

      <div class="au-error-box" id="auErrorBox"></div>

      <div class="au-progress-wrap" id="auProgressWrap">
        <div class="au-progress-bar-track"><div class="au-progress-bar-fill" id="auProgressFill"></div></div>
        <div class="au-progress-stats">
          <span id="auProgressPercent">0%</span>
          <span id="auProgressSpeed">—</span>
          <span id="auProgressEta">—</span>
        </div>
      </div>

      <div class="au-actions">
        ${!blocking ? `<button class="au-btn" id="auSkipBtn" style="background:rgba(255,255,255,0.08);color:var(--text-dim);flex:0 0 auto;padding:12px 18px;">Nanti Saja</button>` : ''}
        ${previousAttemptFailed && cfg.releaseUrl ? `<button class="au-btn" id="auManualBtn" style="background:rgba(255,255,255,0.08);color:var(--text-dim);flex:0 0 auto;padding:12px 18px;">Download Manual</button>` : ''}
        <button class="au-btn au-btn-primary" id="auUpdateBtn">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 17V3"/><path d="m6 11 6 6 6-6"/><path d="M19 21H5"/></svg>
          Update Sekarang
        </button>
      </div>
    </div>
  `;
  el.style.display = 'flex';
  el.classList.toggle('au-blocking', !!blocking);

  document.getElementById('auSkipBtn')?.addEventListener('click', () => {
    if (_appUpdateDownloading) return;
    hideAppUpdateOverlay();
  });
  document.getElementById('auManualBtn')?.addEventListener('click', () => {
    window.electronAPI?.openExternal?.(cfg.releaseUrl);
  });
  document.getElementById('auUpdateBtn')?.addEventListener('click', () => startAppUpdateDownload(cfg, blocking));
}

function escapeHtmlAU(str) {
  const div = document.createElement('div');
  div.textContent = str || '';
  return div.innerHTML;
}

async function startAppUpdateDownload(cfg, blocking) {
  if (_appUpdateDownloading) return;
  if (!window.electronAPI?.downloadAppUpdate) {
    showAppUpdateError('Update otomatis hanya tersedia di aplikasi desktop.');
    return;
  }
  if (!cfg.downloadUrl) {
    showAppUpdateError('Link download update belum diatur oleh admin.');
    return;
  }

  _appUpdateDownloading = true;
  const updateBtn = document.getElementById('auUpdateBtn');
  const skipBtn = document.getElementById('auSkipBtn');
  if (updateBtn) { updateBtn.disabled = true; updateBtn.innerHTML = 'Mendownload...'; }
  if (skipBtn) skipBtn.style.display = 'none';
  hideAppUpdateError();

  const progressWrap = document.getElementById('auProgressWrap');
  progressWrap?.classList.add('au-active');

  const onProgress = (data) => {
    const fill = document.getElementById('auProgressFill');
    const percentEl = document.getElementById('auProgressPercent');
    const speedEl = document.getElementById('auProgressSpeed');
    const etaEl = document.getElementById('auProgressEta');
    const percent = data.percent ?? (data.total ? Math.round((data.downloaded / data.total) * 100) : 0);
    if (fill) fill.style.width = `${percent}%`;
    if (percentEl) percentEl.textContent = `${percent}% (${formatBytesAU(data.downloaded)}${data.total ? ' / ' + formatBytesAU(data.total) : ''})`;
    if (speedEl) speedEl.textContent = `${formatBytesAU(data.speedBps || 0)}/s`;
    if (etaEl) etaEl.textContent = data.etaSec != null ? `Sisa ${formatEtaAU(data.etaSec)}` : '';
  };
  window.electronAPI.removeAppUpdateProgressListeners?.();
  window.electronAPI.onAppUpdateProgress?.(onProgress);

  try {
    const result = await window.electronAPI.downloadAppUpdate({ url: cfg.downloadUrl, fileSize: cfg.fileSize || 0 });
    if (!result?.success) {
      throw new Error(result?.error || 'Download update gagal.');
    }

    if (updateBtn) updateBtn.innerHTML = 'Memasang & menutup aplikasi...';
    const installResult = await window.electronAPI.installAppUpdate({ installerPath: result.installerPath, targetVersion: cfg.latestVersion });
    if (!installResult?.success) {
      throw new Error(installResult?.error || 'Gagal menjalankan installer.');
    }
    // App akan menutup diri sendiri dari sisi main process (setelah installer
    // ter-spawn) lalu installer yang otomatis membuka lagi app versi baru.
  } catch (e) {
    _appUpdateDownloading = false;
    if (updateBtn) { updateBtn.disabled = false; updateBtn.innerHTML = 'Coba Lagi'; }
    if (skipBtn && !blocking) skipBtn.style.display = '';
    progressWrap?.classList.remove('au-active');
    showAppUpdateError(e.message || 'Update gagal. Silakan coba lagi.');
  }
}

function showAppUpdateError(msg) {
  const box = document.getElementById('auErrorBox');
  if (!box) return;
  box.innerHTML = `<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0;margin-top:1px;"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg><span>${escapeHtmlAU(msg)}</span>`;
  box.classList.add('au-show');
}

function hideAppUpdateError() {
  const box = document.getElementById('auErrorBox');
  if (!box) return;
  box.classList.remove('au-show');
  box.innerHTML = '';
}

// ══════════════════════════════════════════════════════════════════════════
// ACTIVE TOOLS (halaman Settings) — download ZIP dari GitHub (link diatur
// Admin Web), tutup Steam, extract ke folder Steam, lalu validasi status.
// Config diambil dari GET /api/app-update-nya sendiri: /api/active-tools
// (publik) setiap app dibuka, dan realtime lewat WS (event
// `active-tools:config`) selama app berjalan.
// ══════════════════════════════════════════════════════════════════════════
let _activeToolsConfig = null;     // { enabled, zipUrl, version, description }
let _activeToolsActive = false;    // hasil validasi status file terakhir
let _activeToolsBusy = false;      // sedang proses install/reinstall

function getActiveToolsFiles() {
  try { return JSON.parse(localStorage.getItem('activeToolsFiles') || '[]'); } catch (e) { return []; }
}
function saveActiveToolsFiles(files) {
  try { localStorage.setItem('activeToolsFiles', JSON.stringify(files || [])); } catch (e) {}
}

async function fetchActiveToolsConfig() {
  try {
    const res = await fetch(SERVER_URL + '/api/active-tools');
    if (!res.ok) return null;
    return await res.json();
  } catch (e) {
    return null;
  }
}

async function loadActiveToolsConfig() {
  const cfg = await fetchActiveToolsConfig();
  if (!cfg) return;
  applyActiveToolsConfig(cfg);
}

function applyActiveToolsConfig(cfg) {
  _activeToolsConfig = cfg;
  renderActiveToolsCard();
  // Kalau fiturnya baru saja diaktifkan/dinonaktifkan admin, atau versi tools
  // berubah, evaluasi ulang status file di disk (kalau app lagi terbuka).
  refreshActiveToolsStatus();
}

function wireActiveTools() {
  document.getElementById('btnActiveTools')?.addEventListener('click', () => runActiveToolsInstall(false));
  document.getElementById('btnActiveToolsReinstall')?.addEventListener('click', () => {
    if (_activeToolsBusy) return;
    if (!confirm('Install ulang Active Tools? File yang sudah ada di folder Steam akan ditimpa ulang.')) return;
    runActiveToolsInstall(true);
  });
  document.getElementById('btnOpenSteamAfterTools')?.addEventListener('click', async () => {
    const steamPath = await window.electronAPI?.getSteamPath?.();
    if (!steamPath) { showHistoriToast('Steam tidak ditemukan di PC ini.'); return; }
    const res = await window.electronAPI.launchSteam(steamPath);
    if (!res?.success) showHistoriToast(res?.error || 'Gagal membuka Steam.');
  });
}

function setActiveToolsButtonsDisabled(disabled) {
  document.getElementById('btnActiveTools')?.toggleAttribute('disabled', disabled);
  document.getElementById('btnActiveToolsReinstall')?.toggleAttribute('disabled', disabled);
}

// Dipanggil otomatis tiap app dibuka & tiap halaman Settings dibuka — TANPA
// perlu user menekan tombol apapun. Kalau user menghapus file tools secara
// manual, panggilan ini yang mendeteksi & mengembalikan status ke "Belum Aktif".
// (Metode PowerShell tidak extract file apapun yang bisa dicek App, jadi
// statusnya dicek dengan cara berbeda — lihat cabang di bawah.)
async function refreshActiveToolsStatus() {
  if (!_activeToolsConfig?.enabled) { _activeToolsActive = false; renderActiveToolsCard(); return; }

  if (_activeToolsConfig.activationMethod === 'powershell') {
    // Tidak ada file yang bisa divalidasi App (command-nya bebas apa saja) — status
    // "Aktif" di sini murni menandakan "command pernah berhasil dijalankan sekali di
    // PC ini", best-effort, sama semangatnya dengan status Link (bukan verifikasi
    // mendalam ke sistem/registry Steam).
    _activeToolsActive = localStorage.getItem('activeToolsPsActivated') === '1';
    renderActiveToolsCard();
    return;
  }

  if (!window.electronAPI?.getSteamPath || !window.electronAPI?.activeToolsCheckStatus) return;

  const files = getActiveToolsFiles();
  if (!files.length) { _activeToolsActive = false; renderActiveToolsCard(); return; }

  try {
    const steamPath = await window.electronAPI.getSteamPath();
    if (!steamPath) { _activeToolsActive = false; renderActiveToolsCard(); return; }
    const status = await window.electronAPI.activeToolsCheckStatus({ steamPath, extractedFiles: files });
    _activeToolsActive = !!status?.active;
  } catch (e) {
    _activeToolsActive = false;
  }
  renderActiveToolsCard();
}

function renderActiveToolsCard() {
  const card = document.getElementById('activeToolsCard');
  if (!card) return;

  if (!_activeToolsConfig?.enabled) { card.style.display = 'none'; return; }
  card.style.display = '';

  const pill = document.getElementById('atStatusPill');
  const versionLabel = document.getElementById('atVersionLabel');
  const methodBadge = document.getElementById('atMethodBadge');
  const descNote = document.getElementById('atDescNote');
  const btnActivate = document.getElementById('btnActiveTools');
  const btnReinstall = document.getElementById('btnActiveToolsReinstall');
  const btnOpenSteam = document.getElementById('btnOpenSteamAfterTools');
  const isPowerShell = _activeToolsConfig.activationMethod === 'powershell';

  if (pill) {
    pill.textContent = _activeToolsActive ? 'Aktif' : 'Belum Aktif';
    pill.className = 'sysdet-status-pill ' + (_activeToolsActive ? 'running' : 'closed');
  }
  if (versionLabel) {
    versionLabel.textContent = isPowerShell ? '' : (_activeToolsConfig.version ? `Versi Tools: ${_activeToolsConfig.version}` : 'Versi Tools: —');
    versionLabel.style.display = isPowerShell ? 'none' : '';
  }
  if (methodBadge) {
    methodBadge.style.display = '';
    methodBadge.innerHTML = isPowerShell
      ? '⚡ Activation Method: <strong>PowerShell</strong>'
      : '🟢 Activation Method: <strong>Link</strong>';
  }
  if (descNote) {
    descNote.innerHTML = `<svg class="icon icon-18"><use href="#ic-info"></use></svg> ${escapeHtml(_activeToolsConfig.description || '')}`;
  }
  if (btnActivate) btnActivate.style.display = _activeToolsActive ? 'none' : '';
  if (btnReinstall) btnReinstall.style.display = '';
  // Metode PowerShell: script sudah ngurus Steam sendiri (buka/tutup/restart) kalau
  // memang perlu, jadi App tidak berasumsi apapun soal state Steam di sini — tombol
  // "Buka Steam" tetap disediakan sebagai kemudahan opsional, bukan langkah wajib.
  if (btnOpenSteam) btnOpenSteam.style.display = (_activeToolsActive && !isPowerShell) ? '' : 'none';
}

// Lapor ke server tiap kali user SELESAI memakai Active Tools/Cloud FIX (berhasil
// ataupun gagal), supaya tercatat di Logs → Riwayat Aktivitas Sistem Admin Web
// (realtime, lihat logActivity()/broadcastAdmin('activity',...) di server.js).
// SENGAJA best-effort & tidak pernah throw — dipanggil di blok `finally`, jadi
// gagal lapor (mis. lagi offline) TIDAK PERNAH mengganggu/membatalkan proses
// install Active Tools/Cloud FIX yang sudah selesai duluan.
async function logToolUsage(feature, status, message) {
  try {
    await api('/api/tools/log-use', {
      method: 'POST',
      body: JSON.stringify({ feature, status, message: message || null })
    });
  } catch (e) {
    console.warn('[ToolUsageLog] Gagal lapor penggunaan ' + feature + ':', e.message);
  }
}

async function runActiveToolsInstall(isReinstall) {
  if (_activeToolsBusy) return;
  const cfg = _activeToolsConfig;
  if (!cfg?.enabled) { showHistoriToast('Fitur Active Tools belum diaktifkan admin.'); return; }

  // Dispatcher metode — SISTEM LAMA (Link) berjalan PERSIS seperti sebelumnya lewat
  // runActiveToolsLinkInstall(); metode BARU (PowerShell) lewat runActiveToolsPowerShell().
  if (cfg.activationMethod === 'powershell') {
    return runActiveToolsPowerShell();
  }
  return runActiveToolsLinkInstall(isReinstall);
}

// ── SISTEM LAMA (Link) — TIDAK DIUBAH sama sekali dari sebelumnya, cuma
// dipindah namanya dari runActiveToolsInstall() supaya bisa dijadikan salah
// satu cabang dispatcher di atas. ──
async function runActiveToolsLinkInstall(isReinstall) {
  if (!window.electronAPI?.activeToolsInstall) { showHistoriToast('Fitur ini hanya tersedia di aplikasi desktop.'); return; }
  const cfg = _activeToolsConfig;
  if (!cfg.zipUrl) { showHistoriToast('Admin belum mengatur link download Active Tools.'); return; }

  _activeToolsBusy = true;
  setActiveToolsButtonsDisabled(true);
  ensureProgressListener();
  dlModalShow(
    'Active Tools',
    isReinstall ? 'Install ulang Active Tools...' : 'Mengaktifkan Active Tools...',
    '<svg class="icon icon-16"><use href="#ic-wrench"></use></svg>'
  );
  _dlRetryHandler = () => runActiveToolsLinkInstall(isReinstall);
  dlSetStage('Mendeteksi Steam...', 0);

  try {
    const steamPath = await window.electronAPI.getSteamPath();
    if (!steamPath) throw new Error('Steam tidak ditemukan di PC ini. Pastikan Steam sudah terinstall dan pernah dijalankan.');

    dlSetStage('Mengunduh & menutup Steam...', 1);
    const result = await window.electronAPI.activeToolsInstall({ steamPath, zipUrl: cfg.zipUrl });
    if (result?.cancelled) { dlModalHide(); return; }
    if (!result?.success) throw new Error(result?.error || 'Gagal mengaktifkan Active Tools.');

    dlSetStage('Memvalidasi file...', 3);
    saveActiveToolsFiles(result.extractedFiles);

    const statusRes = await window.electronAPI.activeToolsCheckStatus({ steamPath, extractedFiles: result.extractedFiles });
    _activeToolsActive = !!statusRes?.active;

    if (!_activeToolsActive) {
      throw new Error('File sudah diextract tapi validasi tidak menemukan sebagian file. Coba Install Ulang.');
    }

    dlSetSuccess('Active Tools berhasil diaktifkan!', 'Game sekarang dapat terdeteksi di Steam Library.');
    renderActiveToolsCard();
    logToolUsage('active_tools', 'success');
    scheduleResumePendingInstall();
  } catch (e) {
    dlSetStage('Gagal', 3, true);
    dlSetError(e.message || 'Terjadi kesalahan saat mengaktifkan Active Tools.');
    renderActiveToolsCard();
    logToolUsage('active_tools', 'failed', e.message);
  } finally {
    _activeToolsBusy = false;
    setActiveToolsButtonsDisabled(false);
  }
}

// ── SISTEM BARU (PowerShell) — App CUMA menjalankan command yang diisi admin
// apa adanya, TIDAK exit/kill/restart Steam sama sekali (script diasumsikan
// sudah mengurus itu sendiri kalau memang perlu). Progress-nya ditampilkan
// realtime dari output PowerShell (stdout/stderr) yang di-stream main.js. ──
let _atPsListenerBound = false;
async function runActiveToolsPowerShell() {
  if (!window.electronAPI?.activeToolsRunPowerShell) { showHistoriToast('Fitur ini hanya tersedia di aplikasi desktop.'); return; }
  const cfg = _activeToolsConfig;
  if (!cfg.powershellCommand) { showHistoriToast('Admin belum mengatur PowerShell Command untuk Active Tools.'); return; }

  _activeToolsBusy = true;
  setActiveToolsButtonsDisabled(true);
  dlModalShow('Active Tools', 'Menjalankan PowerShell command...', '<svg class="icon icon-16"><use href="#ic-wrench"></use></svg>');
  _dlRetryHandler = () => runActiveToolsPowerShell();
  dlSetStage('Menyiapkan PowerShell...', 0);

  // Listener output realtime — dipasang sekali saja, tiap baris output yang
  // di-stream main.js langsung ditampilkan sebagai stage text supaya user tetap
  // lihat progressnya berjalan (bukan cuma layar "Mohon tunggu" diam saja).
  if (!_atPsListenerBound && window.electronAPI.onActiveToolsPsProgress) {
    _atPsListenerBound = true;
    window.electronAPI.onActiveToolsPsProgress(({ line }) => {
      if (line) dlSetStage(line.slice(0, 140), 1);
    });
  }

  try {
    const result = await window.electronAPI.activeToolsRunPowerShell({ command: cfg.powershellCommand });
    if (!result?.success) throw new Error(result?.error || 'PowerShell command gagal dijalankan.');

    _activeToolsActive = true;
    try { localStorage.setItem('activeToolsPsActivated', '1'); } catch (e) {}

    dlSetSuccess('Active Tools berhasil diaktifkan!', 'PowerShell command selesai dijalankan.');
    renderActiveToolsCard();
    logToolUsage('active_tools', 'success', 'method=powershell');
    scheduleResumePendingInstall();
  } catch (e) {
    dlSetStage('Gagal', 3, true);
    dlSetError(e.message || 'Terjadi kesalahan saat menjalankan PowerShell command.');
    renderActiveToolsCard();
    logToolUsage('active_tools', 'failed', `method=powershell; ${e.message || ''}`);
  } finally {
    _activeToolsBusy = false;
    setActiveToolsButtonsDisabled(false);
  }
}

// Gate dipanggil di awal handleInstall() — return true kalau boleh lanjut
// download/install, false kalau harus diblokir (dan sudah menampilkan dialog).
//
// itemType/itemId/itemName (kalau ada) DISIMPAN sebagai _pendingInstallAfterActiveTools
// supaya begitu user mengaktifkan Active Tools lewat modal ini, download yang
// tadi tertahan bisa OTOMATIS dilanjutkan (lihat scheduleResumePendingInstall())
// — user tidak perlu diarahkan ke Settings atau menekan Download lagi secara manual.
let _pendingInstallAfterActiveTools = null;

function ensureActiveToolsActiveOrPrompt(itemType, itemId, itemName) {
  // Kalau fiturnya sendiri belum diaktifkan admin, tidak ada yang perlu diblokir.
  if (!_activeToolsConfig?.enabled) return true;
  if (_activeToolsActive) return true;

  _pendingInstallAfterActiveTools = (itemType && itemId) ? [itemType, itemId, itemName] : null;
  showActiveToolsRequiredModal();
  return false;
}

function showActiveToolsRequiredModal() {
  const overlay = document.getElementById('activeToolsRequiredOverlay');
  if (!overlay) return;
  overlay.style.display = 'flex';
  overlay.innerHTML = `
    <div class="pcm-modal">
      <div class="pcm-icon pcm-icon--warn"><svg class="icon icon-16"><use href="#ic-triangle-alert"></use></svg></div>
      <div class="pcm-title">Active Tools Belum Aktif</div>
      <div class="pcm-desc">Aktifkan Active Tools dulu supaya game dapat terdeteksi di Steam Library. Prosesnya cuma sebentar — begitu selesai, download akan otomatis dilanjutkan.</div>
      <div class="pcm-actions">
        <button class="pcm-btn pcm-btn--primary" id="atrGoBtn"><svg class="icon icon-18"><use href="#ic-zap"></use></svg> Active Tools</button>
      </div>
      <button class="pcm-close" id="atrCloseBtn">Tutup</button>
    </div>`;

  // Klik "Active Tools" LANGSUNG menjalankan proses aktivasi yang sudah ada
  // (runActiveToolsInstall — reuse 100%, tidak ada sistem baru) — TIDAK lagi
  // membuka halaman Settings sama sekali.
  document.getElementById('atrGoBtn')?.addEventListener('click', () => {
    hideActiveToolsRequiredModal();
    runActiveToolsInstall(false);
  });
  document.getElementById('atrCloseBtn')?.addEventListener('click', () => {
    // User menolak mengaktifkan sekarang — batalkan rencana resume supaya
    // aktivasi Active Tools lain (mis. dari Settings, tanpa hubungan dengan
    // download ini) tidak tiba-tiba "menyambar" ke download yang sudah dibatalkan user.
    _pendingInstallAfterActiveTools = null;
    hideActiveToolsRequiredModal();
  });
}

function hideActiveToolsRequiredModal() {
  const overlay = document.getElementById('activeToolsRequiredOverlay');
  if (overlay) overlay.style.display = 'none';
}

// Dipanggil dari KEDUA jalur aktivasi (Link & PowerShell) tepat setelah sukses
// — supaya "lanjutkan download yang tertahan" bekerja SAMA PERSIS baik saat
// dipicu dari klik pertama di modal ini MAUPUN dari klik "Coba Lagi" setelah
// percobaan sebelumnya gagal (retry memanggil runActiveToolsLinkInstall/
// runActiveToolsPowerShell secara langsung, bukan lewat modal ini lagi).
function scheduleResumePendingInstall() {
  const resumeArgs = _pendingInstallAfterActiveTools;
  if (!resumeArgs) return;
  _pendingInstallAfterActiveTools = null;
  // Beri jeda singkat supaya pesan "Active Tools berhasil diaktifkan!" sempat
  // terbaca user sebelum modal berganti otomatis ke progress download game —
  // bukan infinite loading, bukan juga transisi yang kelewat instan/membingungkan.
  setTimeout(() => {
    dlModalHide();
    setTimeout(() => handleInstall(...resumeArgs), 180);
  }, 1100);
}

// ══════════════════════════════════════════════════════════════════════════
// CLOUD FIX (halaman Settings) — SEKARANG MEKANISMENYA SAMA PERSIS dengan
// Active Tools di atas: config publik via GET /api/cloud-fix, realtime lewat
// WS event `cloud-fix:config`, App men-download ZIP yang diatur admin lalu
// meng-extract-nya SENDIRI langsung ke folder Steam (lewat IPC main process),
// BUKAN cuma membuka link eksternal seperti versi sebelumnya.
// ══════════════════════════════════════════════════════════════════════════
let _cloudFixConfig = null;   // { enabled, zipUrl, version, description }
let _cloudFixActive = false;  // hasil validasi status file terakhir
let _cloudFixBusy = false;    // sedang proses install/reinstall

function getCloudFixFiles() {
  try { return JSON.parse(localStorage.getItem('cloudFixFiles') || '[]'); } catch (e) { return []; }
}
function saveCloudFixFiles(files) {
  try { localStorage.setItem('cloudFixFiles', JSON.stringify(files || [])); } catch (e) {}
}

async function fetchCloudFixConfig() {
  try {
    const res = await fetch(SERVER_URL + '/api/cloud-fix');
    if (!res.ok) return null;
    return await res.json();
  } catch (e) {
    return null;
  }
}

async function loadCloudFixConfig() {
  const cfg = await fetchCloudFixConfig();
  if (!cfg) return;
  applyCloudFixConfig(cfg);
}

function applyCloudFixConfig(cfg) {
  _cloudFixConfig = cfg;
  renderCloudFixCard();
  // Kalau fiturnya baru saja diaktifkan/dinonaktifkan admin, atau versinya
  // berubah, evaluasi ulang status file di disk (kalau app lagi terbuka).
  refreshCloudFixStatus();
}

function wireCloudFix() {
  document.getElementById('btnCloudFix')?.addEventListener('click', () => runCloudFixInstall(false));
  document.getElementById('btnCloudFixReinstall')?.addEventListener('click', () => {
    if (_cloudFixBusy) return;
    if (!confirm('Jalankan ulang Cloud FIX? File yang sudah ada di folder Steam akan ditimpa ulang.')) return;
    runCloudFixInstall(true);
  });
  document.getElementById('btnOpenSteamAfterCloudFix')?.addEventListener('click', async () => {
    const steamPath = await window.electronAPI?.getSteamPath?.();
    if (!steamPath) { showHistoriToast('Steam tidak ditemukan di PC ini.'); return; }
    const res = await window.electronAPI.launchSteam(steamPath);
    if (!res?.success) showHistoriToast(res?.error || 'Gagal membuka Steam.');
  });
}

function setCloudFixButtonsDisabled(disabled) {
  document.getElementById('btnCloudFix')?.toggleAttribute('disabled', disabled);
  document.getElementById('btnCloudFixReinstall')?.toggleAttribute('disabled', disabled);
}

// Dipanggil otomatis tiap app dibuka & tiap halaman Settings dibuka — TANPA
// perlu user menekan tombol apapun, sama seperti Active Tools.
async function refreshCloudFixStatus() {
  if (!window.electronAPI?.getSteamPath || !window.electronAPI?.cloudFixCheckStatus) return;
  if (!_cloudFixConfig?.enabled) { _cloudFixActive = false; renderCloudFixCard(); return; }

  const files = getCloudFixFiles();
  if (!files.length) { _cloudFixActive = false; renderCloudFixCard(); return; }

  try {
    const steamPath = await window.electronAPI.getSteamPath();
    if (!steamPath) { _cloudFixActive = false; renderCloudFixCard(); return; }
    const status = await window.electronAPI.cloudFixCheckStatus({ steamPath, extractedFiles: files });
    _cloudFixActive = !!status?.active;
  } catch (e) {
    _cloudFixActive = false;
  }
  renderCloudFixCard();
}

function renderCloudFixCard() {
  const card = document.getElementById('cloudFixCard');
  if (!card) return;

  if (!_cloudFixConfig?.enabled) { card.style.display = 'none'; return; }
  card.style.display = '';

  const pill = document.getElementById('cfStatusPill');
  const versionLabel = document.getElementById('cfVersionLabel');
  const descNote = document.getElementById('cfDescNote');
  const btnActivate = document.getElementById('btnCloudFix');
  const btnReinstall = document.getElementById('btnCloudFixReinstall');
  const btnOpenSteam = document.getElementById('btnOpenSteamAfterCloudFix');

  if (pill) {
    pill.textContent = _cloudFixActive ? 'Aktif' : 'Belum Aktif';
    pill.className = 'sysdet-status-pill ' + (_cloudFixActive ? 'running' : 'closed');
  }
  if (versionLabel) {
    versionLabel.textContent = _cloudFixConfig.version ? `Versi: ${_cloudFixConfig.version}` : 'Versi: —';
  }
  if (descNote) {
    descNote.innerHTML = `<svg class="icon icon-18"><use href="#ic-info"></use></svg> ${escapeHtml(_cloudFixConfig.description || '')}`;
  }
  if (btnActivate) btnActivate.style.display = _cloudFixActive ? 'none' : '';
  if (btnReinstall) btnReinstall.style.display = '';
  if (btnOpenSteam) btnOpenSteam.style.display = _cloudFixActive ? '' : 'none';
}

async function runCloudFixInstall(isReinstall) {
  if (_cloudFixBusy) return;
  if (!window.electronAPI?.cloudFixInstall) { showHistoriToast('Fitur ini hanya tersedia di aplikasi desktop.'); return; }
  const cfg = _cloudFixConfig;
  if (!cfg?.enabled) { showHistoriToast('Fitur Cloud FIX belum diaktifkan admin.'); return; }
  if (!cfg.zipUrl) { showHistoriToast('Admin belum mengatur link download Cloud FIX.'); return; }

  _cloudFixBusy = true;
  setCloudFixButtonsDisabled(true);
  ensureProgressListener();
  dlModalShow(
    'Cloud FIX',
    isReinstall ? 'Menjalankan ulang Cloud FIX...' : 'Menjalankan Cloud FIX...',
    '<svg class="icon icon-16"><use href="#ic-cloud"></use></svg>'
  );
  _dlRetryHandler = () => runCloudFixInstall(isReinstall);
  dlSetStage('Mendeteksi Steam...', 0);

  try {
    const steamPath = await window.electronAPI.getSteamPath();
    if (!steamPath) throw new Error('Steam tidak ditemukan di PC ini. Pastikan Steam sudah terinstall dan pernah dijalankan.');

    dlSetStage('Mengunduh & menutup Steam...', 1);
    const result = await window.electronAPI.cloudFixInstall({ steamPath, zipUrl: cfg.zipUrl });
    if (result?.cancelled) { dlModalHide(); return; }
    if (!result?.success) throw new Error(result?.error || 'Gagal menjalankan Cloud FIX.');

    dlSetStage('Memvalidasi file...', 3);
    saveCloudFixFiles(result.extractedFiles);

    const statusRes = await window.electronAPI.cloudFixCheckStatus({ steamPath, extractedFiles: result.extractedFiles });
    _cloudFixActive = !!statusRes?.active;

    if (!_cloudFixActive) {
      throw new Error('File sudah diextract tapi validasi tidak menemukan sebagian file. Coba Install Ulang.');
    }

    dlSetSuccess('Cloud FIX berhasil dijalankan!', 'Masalah Cloud Status Steam seharusnya sudah teratasi.');
    renderCloudFixCard();
    logToolUsage('cloud_fix', 'success');
  } catch (e) {
    dlSetStage('Gagal', 3, true);
    dlSetError(e.message || 'Terjadi kesalahan saat menjalankan Cloud FIX.');
    renderCloudFixCard();
    logToolUsage('cloud_fix', 'failed', e.message);
  } finally {
    _cloudFixBusy = false;
    setCloudFixButtonsDisabled(false);
  }
}